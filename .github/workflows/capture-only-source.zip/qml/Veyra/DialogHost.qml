// Dialog routing and scrim. Each dialog owns its own editable content.
import QtQuick
import QtQuick.Controls
import QtQuick.Layouts

Item {
    id: host
    // Compatibility type used by the professional and node views.
    component VTextField: DialogTextField {}
    anchors.fill: parent
    z: 100

    // Active dialog: network/capture/ps5/moonlight/xbox/screen/subtitle/audio/save/manage.
    property string dialog: ""
    // The game scene the layout editor opens on (StudioPage.requestLayout).
    property string layoutScene: ""
    property bool onboardingActive: false
    readonly property alias captureSettings: captureDialog
    readonly property bool captureGuideOpen: captureGuide.visible
    onDialogChanged: {
        if (dialog !== "capture") {
            legacyCapturePicker.close()
            captureGuide.close()
        }
    }

    function open(key) {
        if (["stream", "record", "compare", "layout", "micfilters", "frameinput", "screen",
             "network", "ps5", "moonlight", "xbox"].indexOf(key) !== -1) return
        if (key === "save") saveDialog.resetForOpen()
        if (key === "manage") {
            manageDialog.mode = veyra.nodeMode === 1 ? "node" : "list"
            manageDialog.feedback = ""
        }
        veyra.logUi("ui-dialog", "open " + key + " (was " + (host.dialog || "none") + ")")
        host.dialog = key
    }
    function close() { host.dialog = "" }
    // PushFPS: the read-text key pressed with its dialog open reads the picture as it is now.
    function readTextAgain() { readTextDialog.start() }

    signal startPs5()
    signal startMoonlight()
    signal startXbox()
    signal startScreen()
    signal startScreenCrop()
    // PushFPS redesign: the Appearance panel asks for Settings -> Appearance.
    signal requestAppearanceSettings()

    CaptureGuideDialog { id: captureGuide }

    CaptureLegacyPicker {
        id: legacyCapturePicker
        formats: visible ? veyra.captureFormats : []
        selectedKey: veyra.captureFormatKey
        onSelected: key => { if (!veyra.captureQueryBusy) veyra.captureFormatKey = key }
    }
    Connections {
        target: veyra
        function onCaptureChanged() { if (veyra.captureQueryBusy) legacyCapturePicker.close() }
    }

    // Scrim (M16): the design dims the page behind the dialog, opacity .2s linear.
    // The native video window cannot be dimmed from QML; only the dialog panel is cut
    // out of it (videoCover below), so the picture beside the dialog stays undimmed.
    Rectangle {
        anchors.fill: parent
        color: Qt.rgba(0, 0, 0, 0.55)
        opacity: host.dialog !== "" && !host.onboardingActive ? 1 : 0
        visible: opacity > 0
        Behavior on opacity { NumberAnimation { duration: Theme.d(200) } }
        TapHandler { onTapped: host.close() }
    }
    // For the motion probe: the open dialog's scale.
    property real motionScale: 1

    // --- shared chrome ----------------------------------------------------

    NetworkSourceDialog {
        id: networkDialog
        dialogHost: host
    }

    // --- 采集卡 -----------------------------------------------------------
    // The 1.4.4 capture panel, in the new design: device details and formats are
    // queried asynchronously, only an explicitly chosen audio input is opened,
    // and the choice is remembered for "继续上次采集". Resolution, frame rate and
    // pixel format are three views of that one saved format key.
    CaptureSourceDialog {
        id: captureDialog
        dialogHost: host
        onboardingActive: host.onboardingActive
        legacyPicker: legacyCapturePicker
        onGuideRequested: captureGuide.open()
    }

    // --- PS5 串流 ---------------------------------------------------------
    // The 1.4.4 Remote Play panel: saved pairings are encrypted in the user's
    // %LOCALAPPDATA%\Veyra\remoteplay and shared with 1.4.4.
    Ps5SourceDialog {
        id: ps5Dialog
        dialogHost: host    }

    // --- PC 串流（Sunshine / GameStream） ----------------------------------
    // Hosts, pairing, the host's apps and the stream-core settings. The effect chain is not here: once
    // connected, the picture goes through the software's own pages like any other source.
    PcSourceDialog {
        id: mlDialog
        dialogHost: host
    }

    // --- Xbox 串流（非官方） ---------------------------------------------------
    // Sign in with the Xbox (Microsoft) account on Microsoft's own page via a device code, pick a console,
    // start. The software never sees the password; only a refresh token is kept, encrypted for this user.
    XboxSourceDialog {
        id: xbDialog
        dialogHost: host    }

    // --- 屏幕捕获 ---------------------------------------------------------
    ScreenSourceDialog {
        id: screenDialog
        dialogHost: host
    }

    // --- 字幕设置 ---------------------------------------------------------
    SubtitleSettingsDialog {
        id: subtitleDialog
        dialogHost: host
    }
    LiveTranslationDialog {
        dialogHost: host
    }

    // --- 音频设置 ---------------------------------------------------------
    AudioSettingsDialog {
        dialogHost: host
    }

    // --- 另存为预设 -------------------------------------------------------
    // The design lists every part that will be saved before asking for a name, so
    // the user can see what they are about to store.
    SavePresetDialog {
        id: saveDialog
        dialogHost: host
    }

    // --- 管理预设 ---------------------------------------------------------
    ManagePresetsDialog {
        id: manageDialog
        dialogHost: host
    }

    // --- PushFPS: Optimise for my PC, game presets ----------------------------
    PushOptimizeDialog {
        id: optimizeDialog
        dialogHost: host
    }
    PushGamePresetsDialog {
        id: gamePresetsDialog
        dialogHost: host
    }
    PushHudDialog {
        id: hudDialog
        dialogHost: host
    }
    PushLatencyGuideDialog {
        id: latencyGuideDialog
        dialogHost: host
    }
    PushCrashDialog {
        id: crashDialog
        dialogHost: host
    }
    PushDiagnoseDialog {
        id: diagnoseDialog
        dialogHost: host
    }
    // PushFPS redesign: the palette button's panel (key "appearance").
    PushAppearanceDialog {
        id: appearanceDialog
        dialogHost: host
        onRequestSettings: host.requestAppearanceSettings()
    }
    // PushFPS: read the text on the picture (key "readtext").
    PushReadTextDialog {
        id: readTextDialog
        dialogHost: host
    }
    PushCardTestDialog {
        id: cardTestDialog
        dialogHost: host
    }
    PushStreamDialog {
        id: streamDialog
        dialogHost: host
    }
    PushCompareDialog {
        id: compareDialog
        dialogHost: host
    }
    PushRecordDialog {
        id: recordDialog
        dialogHost: host
    }
    PushMicFiltersDialog {
        id: micFiltersDialog
        dialogHost: host
    }
    PushFrameInputDialog {
        id: frameInputDialog
        dialogHost: host
    }
    PushQualityTestDialog {
        id: qualityTestDialog
        dialogHost: host
    }
    PushLatencyTestDialog {
        id: latencyTestDialog
        dialogHost: host
    }
    PushLayoutDialog {
        id: layoutDialog
        dialogHost: host
        sceneId: host.layoutScene
    }
    PushCropDialog {
        id: cropDialog
        dialogHost: host
    }

    // --- small building blocks the design's dialogs use --------------------

}
