#include "veyra/engine/PushResponse.h"
#include "veyra/pushflow/PushFlowPredict.h"
#include "veyra/engine/EngineController.h"
#include "veyra/sink/AudioGain.h"
#include "veyra/engine/BufferingGate.h"
#include "veyra/engine/PlaybackRate.h"
#include "veyra/engine/PreviewFrameReadiness.h"
#include "veyra/engine/FgCompatibilityProbe.h"
#include "veyra/engine/VideoPresenter.h"
#include "veyra/engine/LiveRecorder.h"
#include "veyra/engine/HdrDisplayState.h"
#include "veyra/engine/VideoExportJob.h"
#include "veyra/engine/LivePresentationTiming.h"
#include "veyra/engine/PresentationScheduler.h"
#include "veyra/engine/DeadlineWait.h"
#include "veyra/engine/EnhancementDelayEstimate.h"
#include "veyra/engine/LiveGpuScheduler.h"
#include "veyra/engine/LivePresentationResetPolicy.h"
#include "veyra/engine/TimingWindow.h"
#include "veyra/engine/FrameFlowWindow.h"
#include "veyra/engine/ProviderSubmissionCounter.h"
#include "veyra/engine/AutoNrController.h"
#include "veyra/engine/AutoNrReuseController.h"
#include "veyra/engine/LiveFgAdmission.h"
#include "veyra/engine/FgRecoveryBudget.h"
#include "veyra/engine/VfgQueueBudget.h"
#include "veyra/engine/VfgOverloadEstimate.h"
#include "veyra/engine/LivePairLatency.h"
#include "veyra/engine/RealtimePreviewScheduling.h"
#include "veyra/engine/CaptureHalfRate.h"
#include "veyra/engine/ContentDedup.h"
#include "veyra/engine/CapturePreviewClock.h"
#include "veyra/engine/DisplayFgBudget.h"
#include "veyra/engine/PushAdaptiveFg.h"
#include "veyra/engine/PushPacingRepair.h"
#include "veyra/source/MediaFileSource.h"
#include "veyra/source/CaptureCardSource.h"
#include "veyra/source/DeckLinkCapture.h"
#include "veyra/source/ScreenCaptureSource.h"
#include "veyra/source/FrameInputSource.h"
#include "veyra/xbox/DisconnectPolicy.h"
#ifdef VEYRA_ENABLE_REMOTEPLAY
#include "veyra/source/RemotePlaySessionSource.h"
#endif
#include "veyra/pipeline/CaptureUploadFrame.h"
#include "veyra/pipeline/EnhanceGraph.h"
#include "veyra/pipeline/ResetCoordinator.h"
#include "veyra/gfx/XessMfgUnlock.h"
#include "veyra/ngx/AmpereMfgUnlock.h"
#include "veyra/ngx/DlssgTransfusion.h"
#include "veyra/ngx/NgxCoreCache.h"
#include "veyra/diagnostics/ResetCause.h"
#include "veyra/diagnostics/CpuStallTrace.h"
#include "veyra/sink/WasapiAudioSink.h"
#include "veyra/sink/ImageExportSink.h"
#include "veyra/gfx/D3D12DeviceContext.h"
#include "veyra/gfx/CommandSlotRing.h"
#include "veyra/gfx/PresentationHooks.h"
#include "veyra/RuntimePaths.h"
#include "veyra/engine/GraphDescription.h"
#include "veyra/engine/RecentGraphCache.h"
#include "veyra/engine/PreviewGpuSession.h"
#include "veyra/engine/EffectChain.h"
#include "veyra/engine/PosterFrame.h"
#include <avrt.h>
#include <chrono>
#include <filesystem>
#include <format>
#include <limits>
#include <cmath>
#include <deque>
#include <algorithm>
extern "C" {
#include <libavutil/frame.h>
#include <libavutil/pixfmt.h>
}
namespace veyra::engine {
using Clock=std::chrono::steady_clock;
namespace {
double elapsedMs(Clock::time_point from){return std::chrono::duration<double,std::milli>(Clock::now()-from).count();}
int64_t monotonic100ns(){return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count()/100;}
struct OnExit {std::function<void()> action;~OnExit(){action();}};
void logFrameFlow(const diagnostics::FrameFlowMetrics& m,const char* state){
    const auto& c=m.counters;const auto& id=m.latest;
    if(c.xessSdkPresented)veyra::log::info("provider-flow",std::format("state={} session={} revision={} sdkPresented={} sdkGenerated={} sdkSubmitFps={:.2f} measurement=provider-report-not-scanout",state,id.sessionId,id.frame.settingsRevision,c.xessSdkPresented,c.xessSdkGenerated,m.xessSdkSubmitFps));
    const auto& r=m.reset; const auto ms=[&](diagnostics::ResetStage s){return r.stageMs[size_t(s)].value_or(-1.0);};
    veyra::log::info("frame-flow",std::format("state={} session={} revision={} epoch={} source={} batch={} readyFence={} consumerFence={} captureReceived={} mailboxOverwritten={} sourceAccepted={} sourceSkippedBeforeGraph={} realSubmitted={} fgCandidate={} fgSkippedBeforeEval={} fgEvaluated={} fgWarmup={} fgSkippedForReset={} fgReduced={} fgReadyValid={} fgInvalid={} realPresented={} generatedPresented={} generatedExpiredAfterEval={} cancelledBeforePresent={} commandSlots={} commandHighWater={} presentationHighWater={} slotWaitCount={} slotWaitMs={:.3f} generatedFps={:.2f} presentSubmitFps={:.2f} resetRevision={} resetEpoch={} resetReason={} resetOutcome={} resetDrainMs={:.3f} resetDestroyMs={:.3f} resetCreateMs={:.3f} resetWarmupMs={:.3f} resetFirstValidMs={:.3f} resetTotalMs={:.3f}",state,id.sessionId,id.frame.settingsRevision,id.frame.epoch,id.frame.sourceFrameId,id.batchId,id.readyFence,id.consumerFence,c.captureReceived,c.mailboxOverwritten,c.sourceAccepted,c.sourceSkippedBeforeGraph,c.realSubmitted,c.fgCandidate,c.fgSkippedBeforeEval,c.fgEvaluated,c.fgWarmup,c.fgSkippedForReset,c.fgReduced,c.fgReadyValid,c.fgInvalid,c.realPresented,c.generatedPresented,c.generatedExpiredAfterEval,c.cancelledBeforePresent,c.commandSlotsInFlight,c.commandSlotHighWater,c.presentationBatchHighWater,m.slotReuseWaitCount,m.slotReuseWaitMs.value_or(0),m.validGeneratedFps,m.presentSubmitFps,r.settingsRevision,r.epoch,unsigned(r.reason),unsigned(r.outcome),ms(diagnostics::ResetStage::Drain),ms(diagnostics::ResetStage::Destroy),ms(diagnostics::ResetStage::Create),ms(diagnostics::ResetStage::Warmup),ms(diagnostics::ResetStage::FirstValid),r.totalMs.value_or(-1.0)));
}
}
EngineController::EngineController(){
    watchdog_=std::make_unique<EngineWatchdog>([this](uint64_t stalledMs){noteEngineHang(stalledMs);});
    worker_=std::thread(&EngineController::dispatch,this);
}
EngineController::~EngineController(){
#ifdef VEYRA_ENABLE_REMOTEPLAY
    // The PS5 手柄控制 thread starts closing its session now; joined below.
    controlThread_.request_stop();
#endif
    {std::lock_guard lock(mutex_);shutdown_=true;pending_={};stop_=true;}wake_.notify_one();
    if(!worker_.joinable()){watchdog_.reset();return;}
    // Field logs(15): an owner thread blocked inside a driver call never returns,
    // and closing the app waited for it forever (the process had to be killed).
    // Wait a bounded time, then end the process instead of hanging on exit.
    const auto started=Clock::now();
    {std::unique_lock lock(mutex_);
        while(!dispatchDone_.wait_for(lock,std::chrono::milliseconds(100),[&]{return dispatchExited_;})){
            const double waited=elapsedMs(started);
            if(waited<(watchdog_->hung()?3000.0:20000.0))continue;
            veyra::log::error("engine-hang",std::format("shutdown: owner thread still blocked after {:.0f} ms; ending the process instead of waiting",waited));
            Logger::instance().flush();
            TerminateProcess(GetCurrentProcess(),0);
        }
    }
    worker_.join();
#ifdef VEYRA_ENABLE_REMOTEPLAY
    if(controlThread_.joinable()){
        const auto closing=Clock::now();
        {std::unique_lock lock(controlMutex_);
            while(!controlIdle_.wait_for(lock,std::chrono::milliseconds(100),[&]{return controlExited_;})){
                if(elapsedMs(closing)<8000.0)continue;
                veyra::log::error("engine-hang","shutdown: PS5 controller-only session still closing after 8 s; ending the process instead of waiting");
                Logger::instance().flush();
                TerminateProcess(GetCurrentProcess(),0);
            }
        }
        controlThread_.join();
    }
#endif
    // The watchdog callback reads snapshot_ and hangPreviousStatus_. Detach it
    // while all controller members are still alive, before reverse destruction
    // reaches hangPreviousStatus_ (declared after watchdog_).
    watchdog_.reset();
}
void EngineController::dispatch(){
    for(;;){std::function<void()> task;{std::unique_lock lock(mutex_);wake_.wait(lock,[&]{return shutdown_||bool(pending_);});if(shutdown_)break;task=std::move(pending_);pending_={};busy_=true;stop_=false;}
        try{task();}catch(const std::exception&){status(L"任务异常，已停止；请查看诊断",true);}
        {std::lock_guard lock(mutex_);busy_=false;snapshot_.running=false;if(snapshot_.transport==TransportState::Stopping)snapshot_.transport=TransportState::Empty;}
    }
    prewarmed_.reset();
    {std::lock_guard lock(mutex_);dispatchExited_=true;}dispatchDone_.notify_all();
}
// Watchdog thread. try_lock: an owner stuck while holding mutex_ must not take
// the watchdog down with it.
void EngineController::noteEngineHang(uint64_t stalledMs){
    std::unique_lock lock(mutex_,std::try_to_lock);if(!lock.owns_lock())return;
    if(stalledMs){if(snapshot_.status!=kEngineHangStatus){hangPreviousStatus_=snapshot_.status;snapshot_.status=kEngineHangStatus;}}
    else if(snapshot_.status==kEngineHangStatus)snapshot_.status=hangPreviousStatus_;
}
void EngineController::post(std::function<void()> task){ {std::lock_guard lock(mutex_);stop_=true;pending_=std::move(task);}wake_.notify_one(); }
bool EngineController::idle()const{std::lock_guard lock(mutex_);return !busy_&&!pending_;}
bool EngineController::prewarmEnhancement(EnhancementSettings settings,unsigned width,unsigned height){
    if(!prewarmEnabled_||!PreviewGpuSession::requestAllowed(settings))return false;
    {
        std::lock_guard lock(mutex_);if(shutdown_||busy_||pending_)return false;
        pending_=[this,settings,width,height]{
            if(!prewarmEnabled_)return;
            CoInitializeEx(nullptr,COINIT_MULTITHREADED);
            auto candidate=std::make_unique<PreviewGpuSession>();prewarmed_.reset();
            log::info("prewarm","event=begin owner=engine-dispatcher");
            const bool ready=candidate->prepare(settings,width,height);
            bool keep=false;{std::lock_guard lock(mutex_);keep=ready&&prewarmEnabled_&&!shutdown_&&(!stop_||bool(pending_));}
            if(keep)prewarmed_=std::move(candidate);
            else log::info("prewarm","event=discard reason=not-ready-disabled-or-cancelled");
            candidate.reset();CoUninitialize();
        };
    }
    wake_.notify_one();return true;
}
void EngineController::setEnhancementPrewarmEnabled(bool enabled){
    prewarmEnabled_=enabled;
    if(!enabled){std::lock_guard lock(mutex_);if(!busy_&&!pending_)pending_=[this]{prewarmed_.reset();log::info("prewarm","event=disabled released=true");};}
    wake_.notify_one();
}
bool EngineController::setPlaybackRate(double rate){
    if(!validPlaybackRate(rate))return false;
    std::lock_guard lock(mutex_);
    if(!snapshot_.running||snapshot_.capture||snapshot_.image)return false;
    if(requestedPlaybackRate_==rate)return true;
    requestedPlaybackRate_=rate;snapshot_.playbackRate=rate;
    if(seekSeconds_<0){snapshot_.seekTarget=snapshot_.position;++snapshot_.seekRequested;seekSeconds_=snapshot_.position;}
    veyra::log::info("playback-rate",std::format("requested {:.2f}x at {:.3f}s",rate,snapshot_.position));
    return true;
}
void EngineController::setFullscreenMemoryProtection(bool enabled){
    fullscreenMemoryProtection_=enabled;
    if(!enabled){std::lock_guard lock(mutex_);snapshot_.vramFullscreenUnsafe=false;}
}
void EngineController::open(HWND video,const std::wstring& path,PlayerOptions opts){
#ifdef VEYRA_CAPTURE_ONLY
    if (!path.starts_with(L"capture:") && !path.starts_with(L"capture2:")) {
        log::warn("capture-only", "Only physical capture-card sources are supported.");
        return;
    }
#endif

    response::observer().clear();   // PushFlow 2's Response: what it saw belongs to the source before
    const bool captureReplay=opts.captureReplayForTest;
    // Diagnostics-only PlayerOptions fields never enter EnhancementSettings;
    // keep them across the snapshot round-trip below.
    const bool captureCpuUnpack=opts.captureCpuUnpack;
    const bool softwareDecode=opts.softwareDecode;const bool hardwareDecodeOnly=opts.hardwareDecodeOnly;
    const media::NetworkSettings network=opts.network; // #48: buffering / reconnect choices
    // Per-open state that EnhancementSettings does not carry, so the snapshot round-trip
    // below would drop it: the DASH audio address is the difference between a Bilibili
    // video that has sound and one that is silent.
    const std::wstring audioPath=opts.audioPath;
#ifdef VEYRA_ENABLE_REMOTEPLAY
    // PS5 手柄控制 belongs to a capture card source; any other source ends it.
    if(!path.starts_with(L"capture:")&&!path.starts_with(L"capture2:"))stopRemoteControl();
#endif
    {std::lock_guard lock(mutex_);snapshot_={};requestedPlaybackRate_=1;activeFlow_.reset();previewView_={};fgMultiFrameMaxCap_=0;xessMaxInterpolatedFramesCap_=0;fsrMaxGeneratedFramesCap_=0;snapshot_.sessionId=++sessionId_;snapshot_.transport=TransportState::Opening;savePath_.clear();desired_=opts.snapshot();desiredNodeOrder_=opts.nodeOrder;desired_.revision=++nextRevision_;snapshot_.desired=desired_;opts=PlayerOptions::from(desired_,desiredNodeOrder_,&opts);}
    opts.captureReplayForTest=captureReplay;
    opts.captureCpuUnpack=captureCpuUnpack;
    opts.softwareDecode=softwareDecode;opts.hardwareDecodeOnly=hardwareDecodeOnly;
    opts.network=network;
    opts.audioPath=audioPath;
    post([this,video,path,opts]{paused_=false;seekSeconds_=-1;run(video,path,opts);});
}
#ifdef VEYRA_ENABLE_REMOTEPLAY
void EngineController::openRemotePlay(HWND window,source::RemotePlayConnectDesc desc,PlayerOptions opts){
    stopRemoteControl();
    auto request=std::make_shared<source::RemotePlayConnectDesc>(std::move(desc));
    {std::lock_guard lock(mutex_);snapshot_={};requestedPlaybackRate_=1;activeFlow_.reset();previewView_={};fgMultiFrameMaxCap_=0;xessMaxInterpolatedFramesCap_=0;fsrMaxGeneratedFramesCap_=0;snapshot_.sessionId=++sessionId_;snapshot_.transport=TransportState::Opening;snapshot_.remotePlay=true;snapshot_.capture=true;savePath_.clear();desired_=opts.snapshot();desiredNodeOrder_=opts.nodeOrder;desired_.revision=++nextRevision_;snapshot_.desired=desired_;opts=PlayerOptions::from(desired_,desiredNodeOrder_,&opts);}
    post([this,window,request,opts]{paused_=false;seekSeconds_=-1;waitRemoteControlIdle();run(window,L"remoteplay:",opts,request);});
}
// A PS5 stream (activeRemote_) takes precedence; otherwise PS5 手柄控制.
remoteplay::ControllerFeedback EngineController::remotePlayFeedback(){std::lock_guard lock(mutex_);if(activeRemote_)return activeRemote_->takeFeedback();return controlRemote_?controlRemote_->takeFeedback():remoteplay::ControllerFeedback{};}
void EngineController::remotePlayController(const remoteplay::ControllerState& state){std::lock_guard lock(mutex_);if(activeRemote_)activeRemote_->controller(state);else if(controlRemote_)controlRemote_->controller(state);}
void EngineController::remotePlayLoginPin(std::string pin){std::lock_guard lock(mutex_);if(activeRemote_)activeRemote_->loginPin(std::move(pin));else if(controlRemote_)controlRemote_->loginPin(std::move(pin));}
void EngineController::startRemoteControl(source::RemotePlayConnectDesc desc){
    desc.controlOnly=true;desc.request.viewOnly=false;
    auto request=std::make_shared<source::RemotePlayConnectDesc>(std::move(desc));
    {std::lock_guard lock(controlMutex_);controlPending_=std::move(request);
        if(!controlThread_.joinable())controlThread_=std::jthread([this](std::stop_token stop){controlLoop(stop);});}
    controlWake_.notify_all();
}
void EngineController::stopRemoteControl(){
    {std::lock_guard lock(controlMutex_);if(!controlThread_.joinable())return;
        controlPending_=std::shared_ptr<source::RemotePlayConnectDesc>{};}
    controlWake_.notify_all();
}
void EngineController::controlLoop(std::stop_token stop){
    for(;;){
        std::shared_ptr<source::RemotePlayConnectDesc> request;
        {std::unique_lock lock(controlMutex_);
            if(!controlWake_.wait(lock,stop,[&]{return controlPending_.has_value();}))break;
            request=std::move(*controlPending_);controlPending_.reset();controlBusy_=true;controlStarting_=bool(request);}
        // One Remote Play slot per console: the old session ends before a new one starts.
        std::shared_ptr<source::RemotePlaySessionSource> old;
        {std::lock_guard lock(mutex_);old=std::move(controlRemote_);}
        if(old){const auto closing=Clock::now();old->close();veyra::log::info("remoteplay-control",std::format("controller-only session closed in {:.0f} ms",elapsedMs(closing)));}
        if(request&&!stop.stop_requested()){
            auto session=std::make_shared<source::RemotePlaySessionSource>();
            const bool ok=session->connect(std::move(*request));
            veyra::log::info("remoteplay-control",std::format("controller-only session start ok={} alive={}",ok,session->alive()));
            // Kept even when the start failed: its status carries the reason.
            std::lock_guard lock(mutex_);controlRemote_=std::move(session);
        }
        {std::lock_guard lock(controlMutex_);controlBusy_=controlStarting_=false;}
        controlIdle_.notify_all();
    }
    std::shared_ptr<source::RemotePlaySessionSource> last;
    {std::lock_guard lock(mutex_);last=std::move(controlRemote_);}
    if(last)last->close();
    {std::lock_guard lock(controlMutex_);controlBusy_=controlStarting_=false;controlPending_.reset();controlExited_=true;}
    controlIdle_.notify_all();
}
// A PS5 stream needs the console's only Remote Play slot: wait until the
// controller-only session has closed (bounded, and cut short by Stop).
void EngineController::waitRemoteControlIdle(){
    const auto deadline=Clock::now()+std::chrono::seconds(10);
    std::unique_lock lock(controlMutex_);
    while((controlBusy_||controlPending_.has_value())&&!stop_.load()){
        if(Clock::now()>=deadline){veyra::log::warn("remoteplay-control","controller-only session still closing after 10 s; starting the PS5 stream anyway");return;}
        controlIdle_.wait_for(lock,std::chrono::milliseconds(100));
    }
}
EngineController::RemoteControlStatus EngineController::remoteControlStatus()const{
    RemoteControlStatus out;
    std::shared_ptr<source::RemotePlaySessionSource> session;
    {std::lock_guard lock(mutex_);session=controlRemote_;}
    {std::lock_guard lock(controlMutex_);out.starting=controlStarting_||(controlPending_.has_value()&&*controlPending_);}
    out.requested=out.starting||bool(session);
    if(!session)return out;
    out.alive=session->alive();out.failed=session->failed();
    const auto s=session->sessionSnapshot();
    out.connected=s.state==remoteplay::SessionState::WaitingFirstFrame||s.state==remoteplay::SessionState::Streaming;
    out.pinRequired=s.state==remoteplay::SessionState::LoginPinRequired;
    const auto recovery=session->recoveryStatus();out.recovering=recovery.active;out.message=recovery.message;
    const auto rates=session->rates();out.keepaliveReady=rates.ready;out.keepaliveFps=rates.receivedFps;
    return out;
}
bool EngineController::remoteControlRequested()const{
    {std::lock_guard lock(mutex_);if(controlRemote_)return true;}
    std::lock_guard lock(controlMutex_);return controlStarting_||(controlPending_.has_value()&&*controlPending_);
}
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
// Input goes straight to the session: the shared pointer is copied under the lock, the send is not.
#define VEYRA_MOONLIGHT_INPUT(call) std::shared_ptr<source::MoonlightSessionSource> m;{std::lock_guard lock(mutex_);m=activeMoonlight_;}if(m)m->call
void EngineController::moonlightController(const remoteplay::ControllerState& state){VEYRA_MOONLIGHT_INPUT(controller(state));}
remoteplay::ControllerFeedback EngineController::moonlightFeedback(){std::shared_ptr<source::MoonlightSessionSource> m;{std::lock_guard lock(mutex_);m=activeMoonlight_;}return m?m->takeFeedback():remoteplay::ControllerFeedback{};}
void EngineController::moonlightKey(uint32_t vk,uint32_t scan,bool extended,bool down){VEYRA_MOONLIGHT_INPUT(keyboard(vk,scan,extended,down));}
void EngineController::moonlightMouseMove(int dx,int dy){VEYRA_MOONLIGHT_INPUT(mouseMove(dx,dy));}
void EngineController::moonlightMouseButton(int button,bool down){VEYRA_MOONLIGHT_INPUT(mouseButton(button,down));}
void EngineController::moonlightScroll(int delta,bool horizontal){VEYRA_MOONLIGHT_INPUT(scroll(delta,horizontal));}
void EngineController::moonlightReleaseInput(){VEYRA_MOONLIGHT_INPUT(releaseInput());}
#undef VEYRA_MOONLIGHT_INPUT
#endif
#ifdef VEYRA_ENABLE_XBOX
void EngineController::xboxController(const remoteplay::ControllerState& state){std::shared_ptr<source::XboxSessionSource> x;{std::lock_guard lock(mutex_);x=activeXbox_;}if(x)x->controller(state);}
remoteplay::ControllerFeedback EngineController::xboxFeedback(){std::shared_ptr<source::XboxSessionSource> x;{std::lock_guard lock(mutex_);x=activeXbox_;}return x?x->takeFeedback():remoteplay::ControllerFeedback{};}
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
void EngineController::openMoonlight(HWND window,source::MoonlightConnectDesc desc,PlayerOptions opts){
#ifdef VEYRA_ENABLE_REMOTEPLAY
    stopRemoteControl();
#endif
    auto request=std::make_shared<source::MoonlightConnectDesc>(std::move(desc));
    {std::lock_guard lock(mutex_);snapshot_={};requestedPlaybackRate_=1;activeFlow_.reset();previewView_={};fgMultiFrameMaxCap_=0;xessMaxInterpolatedFramesCap_=0;fsrMaxGeneratedFramesCap_=0;snapshot_.sessionId=++sessionId_;snapshot_.transport=TransportState::Opening;snapshot_.moonlightActive=true;snapshot_.capture=true;savePath_.clear();desired_=opts.snapshot();desiredNodeOrder_=opts.nodeOrder;desired_.revision=++nextRevision_;snapshot_.desired=desired_;opts=PlayerOptions::from(desired_,desiredNodeOrder_,&opts);}
    post([this,window,request,opts]{paused_=false;seekSeconds_=-1;run(window,L"moonlight:",opts,{},request);});
}
#endif
#ifdef VEYRA_ENABLE_XBOX
void EngineController::openXbox(HWND window,source::XboxConnectDesc desc,PlayerOptions opts){
#ifdef VEYRA_ENABLE_REMOTEPLAY
    stopRemoteControl();
#endif
    auto request=std::make_shared<source::XboxConnectDesc>(std::move(desc));
    {std::lock_guard lock(mutex_);snapshot_={};requestedPlaybackRate_=1;activeFlow_.reset();previewView_={};fgMultiFrameMaxCap_=0;xessMaxInterpolatedFramesCap_=0;fsrMaxGeneratedFramesCap_=0;snapshot_.sessionId=++sessionId_;snapshot_.transport=TransportState::Opening;snapshot_.xboxActive=true;snapshot_.capture=true;savePath_.clear();desired_=opts.snapshot();desiredNodeOrder_=opts.nodeOrder;desired_.revision=++nextRevision_;snapshot_.desired=desired_;opts=PlayerOptions::from(desired_,desiredNodeOrder_,&opts);}
    post([this,window,request,opts]{paused_=false;seekSeconds_=-1;run(window,L"xbox:",opts,{},{},request);});
}
#endif
void EngineController::stop(){
    {std::lock_guard lock(mutex_);stop_=true;pending_={};snapshot_.transport=busy_?TransportState::Stopping:TransportState::Empty;
     if(!busy_)pending_=[this]{prewarmed_.reset();};}
    wake_.notify_one();
}
void EngineController::pause(bool p){paused_=p;std::lock_guard lock(mutex_);if(snapshot_.running)snapshot_.transport=p?TransportState::Paused:TransportState::Playing;}
void EngineController::setVolume(float gain,bool mute){if(!std::isfinite(gain))return;volume_=sink::clampAudioGain(gain);muted_=mute;}
void EngineController::setCaptureAudioMonitoring(bool enabled){
    if(captureAudioMonitoring_.exchange(enabled)!=enabled)
        log::info("capture-audio-monitor",std::format("enabled={} recordingBeforeGain=1 inputUnchanged=1",enabled));
}
bool EngineController::selectAudioTrack(uint64_t session,int streamIndex){
    std::lock_guard lock(mutex_);
    if(session!=snapshot_.sessionId||!snapshot_.running||snapshot_.failed||snapshot_.capture||snapshot_.image)return false;
    if(std::none_of(snapshot_.audioTracks.begin(),snapshot_.audioTracks.end(),[&](const auto& t){return t.streamIndex==streamIndex;}))return false;
    pendingAudioSession_=session;pendingAudioTrack_=streamIndex;return true;
}
bool EngineController::requestSettings(EnhancementSettings s,std::optional<ChainRuntimeOrder> order,uint64_t* acceptedRevision){
    if(!s.validate().empty()){veyra::log::warn("settings","invalid whole settings transaction rejected");status(L"整套设置无效，未应用任何字段",false);return false;}
    if(order){
        // Fail before changing desired state. This is a shape admission check,
        // not a GPU test; actual dimensions are compiled again at graph creation.
        StageRequest r;r.width=64;r.height=64;r.nr=s.nr;r.sr=s.sr;
        r.fg=s.multiplier>1;r.fgMultiplier=s.multiplier;r.nodeOrder=&*order;
        pipeline::EnhanceGraphDesc desc;describeStages(r,s,desc);
        if(const auto error=desc.validateFixedExecutionPlan();!error.empty()){
            veyra::log::warn("settings",std::format("node order rejected before commit: {}",error));
            status(L"当前执行器尚不支持此节点顺序，原配置保持不变",false);return false;
        }
    }
    std::lock_guard lock(mutex_);if(snapshot_.image)s.multiplier=1;
    // Capability gate: refuse a multiplier the active GPU/runtime cannot honour
    // instead of letting the graph fail and silently turning frame generation
    // off. The previous value is preserved and the reason is surfaced.
    if(s.multiplier>1&&s.frameGenerationBackend==FrameGenerationBackend::Dlss&&fgMultiFrameMaxCap_>0&&
       int(s.multiplier)-1>fgMultiFrameMaxCap_){
        snapshot_.status=std::format(L"此显卡最多支持 {}X 帧生成；请求未应用",fgMultiFrameMaxCap_+1);
        snapshot_.failed=false;
        veyra::log::info("settings",std::format("multiplier gate: requested={} maxGeneratedFrames={} applied=unchanged",s.multiplier,fgMultiFrameMaxCap_));
        return false;
    }
    // XeSS's current ceiling describes this context, not the next one: 2X
    // intentionally runs without the MFG unlock. Validate a higher request in
    // XessPresenter after applying the unlock; rebuild failure rolls it back.
    // The AMD 3.1.x frame-generation provider delivers exactly one generated
    // frame per presented frame; the probe (tools/fsr_probe) measured this on
    // every requested count, so anything above 2X is refused instead of
    // silently presenting 2X under a 4X label.
    if(s.multiplier>2&&twoXFrameGeneration(s.frameGenerationBackend)){
        snapshot_.status=L"AMD FSR 帧生成上限为 2X；请求未应用";
        snapshot_.failed=false;
        veyra::log::info("settings",std::format("fsr multiplier gate: requested={} maxGeneratedFrames=1 applied=unchanged",s.multiplier));
        return false;
    }
    // Revision partitions GPU history and measurements. Saved bypassed-effect
    // parameters and audio-only edits must not invalidate in-flight video.
    s.revision=desired_.revision;if(s==desired_&&order==desiredNodeOrder_){if(acceptedRevision)*acceptedRevision=desired_.revision;return true;}
    if(!s.sameVideoConfiguration(desired_)||order!=desiredNodeOrder_)s.revision=++nextRevision_;
    desiredNodeOrder_=order;desired_=s;snapshot_.desired=s;snapshot_.applying=snapshot_.applied!=desired_;
    if(acceptedRevision)*acceptedRevision=s.revision;return true;
}
void EngineController::refreshGraph(){
    std::lock_guard lock(mutex_);
    desired_.revision=++nextRevision_;snapshot_.desired=desired_;snapshot_.applying=snapshot_.applied!=desired_;
}
void EngineController::saveFrame(const std::wstring& path){std::lock_guard lock(mutex_);savePath_=path;snapshot_.savedFramePath.clear();}
bool EngineController::requestRecording(const RecordingSettings& options,std::wstring& error){return recorder_->start(options,error);}
void EngineController::stopRecording(){recorder_->stop();}
RecordingStatus EngineController::recordingSnapshot()const{return recorder_->status();}
bool EngineController::requestSecondRecording(const RecordingSettings& options,std::wstring& error){return secondRecorder_->start(options,error);}
void EngineController::stopSecondRecording(){secondRecorder_->stop();}
RecordingStatus EngineController::secondRecordingSnapshot()const{return secondRecorder_->status();}
bool EngineController::setVirtualCamera(bool enabled,uint32_t fps,std::wstring& error){
    if(!enabled){virtualCamera_->stop();return true;}return virtualCamera_->start(fps,error);
}
bool EngineController::uninstallVirtualCamera(std::wstring& error){return virtualCamera_->uninstall(error);}
bool EngineController::installVirtualCamera(std::wstring& error){return virtualCamera_->installForAllUsers(error);}
VirtualCameraStatus EngineController::virtualCameraSnapshot()const{return virtualCamera_->status();}
bool EngineController::setReplay(bool enabled,const RecordingSettings& options,std::wstring& error){
    error.clear();
    if(!enabled){replay_->stop();return true;}
    return replay_->start(options,error);
}
bool EngineController::saveReplay(const std::wstring& directory,std::wstring& error){return replay_->saveReplay(directory,error);}
RecordingStatus EngineController::replaySnapshot()const{return replay_->status();}
bool EngineController::requestStreaming(const RecordingSettings& options,std::wstring& error){return stream_->start(options,error);}
void EngineController::stopStreaming(){stream_->stop();}
RecordingStatus EngineController::streamingSnapshot()const{return stream_->status();}
void EngineController::startExport(const std::wstring& input,const std::wstring& output,PlayerOptions opts,bool hevc){
    if(opts.nodeOrder){
        veyra::log::warn("node-order","export has no runtime node-order transport; request rejected before posting");
        status(L"节点链尚未接入导出执行器，请切换列表模式后导出",false);return;
    }
#ifdef VEYRA_ENABLE_REMOTEPLAY
    stopRemoteControl(); // the export replaces the capture run it belonged to
#endif
    const auto frozen=opts.snapshot();const int audioStream=opts.audioStreamIndex;
    post([this,input,output,frozen,audioStream,hevc]{prewarmed_.reset();CoInitializeEx(nullptr,COINIT_MULTITHREADED);auto options=PlayerOptions::from(frozen);options.audioStreamIndex=audioStream;bool ok=exportVideo(input,output,options,hevc,stop_,[this](double p,const std::wstring& s){std::lock_guard lock(mutex_);snapshot_.status=s;snapshot_.position=p;snapshot_.duration=1;snapshot_.running=true;});{std::lock_guard lock(mutex_);snapshot_.running=false;snapshot_.failed=!ok&&!stop_;}CoUninitialize();});
}
void EngineController::requestPresentation(PresentationSettings settings){
    if(!settings.valid())return;
    std::lock_guard lock(mutex_);if(presentation_==settings)return;
    presentation_=settings;++presentationRevision_;
}
PlayerSnapshot EngineController::snapshot()const{
    // The flow window has its own mutex and percentile work; take it after
    // releasing the engine mutex so UI polling does not hold the owner thread
    // (sweep 2026-09-22 B3). Consecutive UI callers within 50 ms share one
    // flow snapshot.
    PlayerSnapshot copy;std::shared_ptr<FrameFlowWindow> flowWindow;
    // The session pointers are copied under the lock: teardown resets them on the
    // engine thread while the UI polls.
#ifdef VEYRA_ENABLE_REMOTEPLAY
    std::shared_ptr<source::RemotePlaySessionSource> activeRemote;
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
    std::shared_ptr<source::MoonlightSessionSource> activeMoonlight;
#endif
#ifdef VEYRA_ENABLE_XBOX
    std::shared_ptr<source::XboxSessionSource> activeXbox;
#endif
    {std::lock_guard lock(mutex_);copy=snapshot_;copy.presentation=presentation_;flowWindow=activeFlow_;
#ifdef VEYRA_ENABLE_REMOTEPLAY
        activeRemote=activeRemote_;
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
        activeMoonlight=activeMoonlight_;
#endif
#ifdef VEYRA_ENABLE_XBOX
        activeXbox=activeXbox_;
#endif
    }
    copy.volume=volume_;copy.muted=muted_;
    const bool playing=copy.running&&!copy.image&&copy.transport==TransportState::Playing;
    if(flowWindow){
        static std::mutex cacheMutex;static diagnostics::FrameFlowMetrics cached;static const FrameFlowWindow* cachedFor=nullptr;static int64_t cachedAt=0;
        const auto now=monotonic100ns();
        std::lock_guard lock(cacheMutex);
        if(cachedFor!=flowWindow.get()||now-cachedAt>500000){cached=flowWindow->snapshot(now);cachedFor=flowWindow.get();cachedAt=now;}
        copy.metrics.flow=cached;
    }
    copy.fgBudgetLimited=playing&&copy.metrics.flow.lastFgRejected100ns>0&&monotonic100ns()-copy.metrics.flow.lastFgRejected100ns<10000000;
#ifdef VEYRA_ENABLE_REMOTEPLAY
    if(copy.remotePlay&&activeRemote){
        const auto s=activeRemote->sessionSnapshot();copy.remoteStream=s;copy.remotePlayState=int(s.state);
        const auto recovery=activeRemote->recoveryStatus();copy.remoteRecovering=recovery.active;copy.remoteReconnectAttempts=recovery.attempts;copy.remoteRecoveryMessage=recovery.message;
        copy.remoteReceivedFps=s.receivedFps;copy.remoteDecodedFps=s.decodedFps;copy.remoteRatesReady=s.ratesReady;
        copy.remoteReceived=s.video.accessUnits;copy.remoteDecoded=s.decodedFrames;copy.remoteIngressDropped=s.video.dropped;
        copy.remotePlaySkipped=activeRemote->skipped();copy.captureAudio=activeRemote->audioState();copy.audioAvailable=copy.captureAudio.available;
    }
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
    if(copy.moonlightActive&&activeMoonlight){
        copy.moonlight=activeMoonlight->stats();
        copy.captureAudio=activeMoonlight->audioState();copy.audioAvailable=copy.captureAudio.available;
    }
#endif
#ifdef VEYRA_ENABLE_XBOX
    if(copy.xboxActive&&activeXbox){
        copy.xbox=activeXbox->stats();
        copy.captureAudio=activeXbox->audioState();copy.audioAvailable=copy.captureAudio.available;
    }
#endif
    auto& flow=copy.metrics.flow;
    if(!playing){flow.sourceCompletedFps=flow.outputCompletedFps=flow.validGeneratedFps=flow.presentSubmitFps=flow.xessSdkSubmitFps=0;flow.presentLow1Fps.reset();}
    copy.fps=flow.sourceCompletedFps;copy.submissionFps=flow.presentSubmitFps;copy.submissionLow1Fps=flow.presentLow1Fps;
    return copy;
}
void EngineController::status(const std::wstring& s,bool failed){std::lock_guard lock(mutex_);snapshot_.status=s;snapshot_.failed=failed;if(failed)snapshot_.transport=TransportState::Failed;}
namespace {
// MMCSS registration keeps the graph owner and capture callback threads ahead
// of ordinary UI/background work; failure is logged once and ignored.
struct MmcssScope {
    HANDLE handle=nullptr;
    explicit MmcssScope(const wchar_t* task){DWORD index=0;handle=AvSetMmThreadCharacteristicsW(task,&index);
        static std::atomic<bool> reported{false};
        if(!handle&&!reported.exchange(true))veyra::log::warn("scheduler",std::format("MMCSS unavailable error={} (continuing at normal priority)",GetLastError()));}
    ~MmcssScope(){if(handle)AvRevertMmThreadCharacteristics(handle);}
};
}
void EngineController::run(HWND window,std::wstring path,PlayerOptions options,std::shared_ptr<source::RemotePlayConnectDesc> remoteRequest,std::shared_ptr<source::MoonlightConnectDesc> moonlightRequest,std::shared_ptr<source::XboxConnectDesc> xboxRequest){
    CoInitializeEx(nullptr,COINIT_MULTITHREADED);
    MmcssScope mmcss(L"Pro Audio");
    status(L"正在初始化GPU与本地运行时…");
    // A recording belongs to the session (and device) it started in.
    if(recorder_->active())recorder_->sessionEnded(L"已切换播放内容，录制已保存");
    if(secondRecorder_->active())secondRecorder_->sessionEnded({});
    replay_->sessionEnded({});
    stream_->sessionEnded({});
    virtualCamera_->sessionEnded();
    auto extension=std::filesystem::path(path).extension().wstring();for(auto& c:extension)c=towlower(c);
    const bool ordinaryFile=!remoteRequest&&!moonlightRequest&&!xboxRequest&&
        !path.starts_with(L"capture:")&&!path.starts_with(L"capture2:")&&!path.starts_with(L"screen:")&&!path.starts_with(L"frameinput:")&&
        extension!=L".png"&&extension!=L".jpg"&&extension!=L".jpeg";
    if(!prewarmEnabled_||!ordinaryFile)prewarmed_.reset();
    // A prewarmed session belongs to the adapter that was preferred when it
    // started; a different compute GPU choice opens a new one.
    if(prewarmed_&&prewarmed_->context.initialized()&&gfx::preferredAdapterLuid()&&prewarmed_->context.adapter().luid!=gfx::preferredAdapterLuid())prewarmed_.reset();
    auto gpu=prewarmed_?std::move(prewarmed_):std::make_unique<PreviewGpuSession>();
    auto& ctx=gpu->context;auto& ring=gpu->ring;source::MediaFileSource source;
    // A GPU hang is reported before Windows resets the GPU (field logs: 13 s later). DRED can
    // only name the stopped command list after the removal, so teardown checks once more.
    bool gpuFailureAwaitingRemoval=false;
    sink::AudioPipeline audioPipe;sink::AudioRenderer audio;VideoPresenter presenter;
    presenter.setCapture(&captures_);presenter.setDisplayStates(&displayStates_);
    auto& coreCache=gpu->core;auto& recentGraphCache=gpu->recent;auto& graph=gpu->graph;
    auto& graphBytes=gpu->graphBytes;auto cacheBudgetPolledAt=Clock::now();
    const bool recentCacheAllowed=!GetEnvironmentVariableW(L"VEYRA_TEST_DISABLE_RECENT_GRAPH_CACHE",nullptr,0);
    AVFrame* imageFrame=nullptr;AVFrame* cachedFrame=nullptr;pipeline::FramePacket cachedPacket;
   source::CaptureCardSource captureSource;const bool physicalCapture=path.starts_with(L"capture:")||path.starts_with(L"capture2:");
    source::ScreenCaptureSource screenSource;const bool isScreen=path.starts_with(L"screen:");
    // PushFPS Frame Input API: another application's frames over shared memory, live like a card.
    source::FrameInputSource frameInputSource;const bool isFrameInput=path.starts_with(L"frameinput:");
    // Set when a live parameter change arrives while paused (or on a still
    // image): the cached source frame must be re-rendered before the next
    // present, otherwise the new colour tables never reach the GPU.
    bool refreshPausedFrame_=false;
#ifdef VEYRA_ENABLE_REMOTEPLAY
    auto remote=remoteRequest?std::make_shared<source::RemotePlaySessionSource>():nullptr;
    const bool isRemote=bool(remote);
    {std::lock_guard lock(mutex_);activeRemote_=remote;}
#else
    (void)remoteRequest;const bool isRemote=false;
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
    auto moon=moonlightRequest?std::make_shared<source::MoonlightSessionSource>():nullptr;
    const bool isMoonlight=bool(moon);
    {std::lock_guard lock(mutex_);activeMoonlight_=moon;}
#else
    (void)moonlightRequest;const bool isMoonlight=false;
#endif
#ifdef VEYRA_ENABLE_XBOX
    auto xb=xboxRequest?std::make_shared<source::XboxSessionSource>():nullptr;
    xbox::ReconnectBudget xboxReconnectBudget;
    const bool isXbox=bool(xb);
    {std::lock_guard lock(mutex_);activeXbox_=xb;}
#else
    (void)xboxRequest;const bool isXbox=false;
#endif
    // PS5, Moonlight and Xbox are all decoded network streams with the same live scheduling.
    const bool isStream=isRemote||isMoonlight||isXbox;
    const bool isCapture=physicalCapture||options.captureReplayForTest||isStream||isScreen||isFrameInput;
    // File replay has no hardware arrival clock; retain its continuous PTS anchor.
    // VEYRA_TEST_REPLAY_AS_CARD=1 delivers it like a capture card instead (see below).
    const bool testReplayAsCard=options.captureReplayForTest&&GetEnvironmentVariableW(L"VEYRA_TEST_REPLAY_AS_CARD",nullptr,0)>0;
    const bool cardTiming=physicalCapture||testReplayAsCard;
    const bool pairAnchoredLive=physicalCapture||isStream||isScreen||isFrameInput||testReplayAsCard;
    source::IFrameSource* activeSource=physicalCapture?static_cast<source::IFrameSource*>(&captureSource):&source;
    if(isScreen)activeSource=&screenSource;
    if(isFrameInput)activeSource=&frameInputSource;
#ifdef VEYRA_ENABLE_REMOTEPLAY
    if(remote)activeSource=remote.get();
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
    if(moon)activeSource=moon.get();
#endif
#ifdef VEYRA_ENABLE_XBOX
    if(xb)activeSource=xb.get();
#endif
    if(options.captureReplayForTest)veyra::log::info("capture-test","file replay exercises live scheduler; no physical capture device or latency measurement");
    bool audioStarted=false;bool failed=false;
    try {
        do {
            Status st=Status::Ok;gfx::DeviceContextDesc dd;dd.commandSlotCount=6;
            // Two bounded jobs, each up to three enhancement lists plus five
            // MFG lists. Allocators must not stall the presentation owner.
            wchar_t testSlots[16]{};unsigned commandSlots=16;
            if(GetEnvironmentVariableW(L"VEYRA_TEST_COMMAND_SLOTS",testSlots,16))commandSlots=std::clamp(unsigned(_wtoi(testSlots)),6u,24u);
            if(!gpu->initialize(commandSlots)){status(L"D3D12初始化失败，请查看诊断",true);break;}
            auto ext=std::filesystem::path(path).extension().wstring();for(auto& c:ext)c=towlower(c);
            const bool isImage=!media::networkMediaInput(path)&&(ext==L".png"||ext==L".jpg"||ext==L".jpeg");
            sink::RgbaImage image;
            uint32_t width=0,height=0;double duration=0;
            if(isImage){
                if(!sink::loadImage(path,image)){status(L"无法解码PNG/JPEG",true);break;}
                if(!pipeline::Extent{image.width,image.height}.valid()||uint64_t(image.width)*image.height>16777216){
                    if(options.nodeOrder){
                        veyra::log::warn("node-order","large-image tiling has no runtime node-order transport; request rejected");
                        status(L"节点模式尚未接入大图分块处理，请切换列表模式后打开",true);break;
                    }
                    runLargeImage(window,image,options,ctx,ring);break;
                }
                imageFrame=av_frame_alloc();imageFrame->format=AV_PIX_FMT_RGBA;imageFrame->width=image.width;imageFrame->height=image.height;imageFrame->pts=0;imageFrame->color_range=AVCOL_RANGE_JPEG;imageFrame->colorspace=AVCOL_SPC_RGB;imageFrame->color_trc=AVCOL_TRC_IEC61966_2_1;
                if(av_frame_get_buffer(imageFrame,32)<0){status(L"图片资源分配失败",true);break;}
                for(unsigned y=0;y<image.height;++y)memcpy(imageFrame->data[0]+size_t(y)*imageFrame->linesize[0],image.pixels.data()+size_t(y)*image.width*4,size_t(image.width)*4);
                width=image.width;height=image.height;options.fg=false;
                {std::lock_guard lock(mutex_);desired_.multiplier=1;snapshot_.image=true;snapshot_.desired=desired_;
                 snapshot_.sourceWidth=image.width;snapshot_.sourceHeight=image.height;
                 snapshot_.sourceDisplayAspect=image.height>0?double(image.width)/image.height:0.0;
                 snapshot_.sourceRotationDegrees=0;}
            }else{
                source::SourceOpenDesc od;od.path=path;
                od.cancelled=&stop_;
                od.deinterlace=options.deinterlace;
                // Network sources and files on a server (#48): buffer settings, reads that may report
                // "buffering" instead of blocking the loop, and tolerance for damaged packets. Local
                // files and capture sources ignore all three.
                od.network=options.network;
                // Site-specific request headers (Bilibili's CDN checks the Referer).
                od.networkHeaders=options.network.requestHeaders;
                // DASH audio arrives as its own address, not inside the video container.
                od.audioPath=options.audioPath;
                od.nonBlocking=!isCapture;
                od.tolerateCorruption=!isCapture;
                // Files use the same shared D3D12 device as the graph-> Capture
                // uses it for the compressed-payload decoder (H.264/HEVC/AV1/
                // VP9 through D3D12VA; MJPEG stays on the software path inside
                // CaptureCompressedDecoder). Each source performs its own
                // capability check and records its fallback.
                // Capture replay may decode on the CPU like a physical capture card (content-cadence tests).
                od.preferHardwareDecode=!(options.softwareDecode&&(!isCapture||options.captureReplayForTest));
                od.requireHardwareDecode=options.hardwareDecodeOnly&&!options.softwareDecode&&!isCapture&&!isImage; // stills have no hardware decoder
                od.d3d12Device=ctx.device();od.d3d12Queue=ctx.directQueue();
                od.d3d12AdapterLuid=ctx.adapter().luid;
                od.decodeDolbyEnhancementLayer=options.settings.doviP7Compose;
                veyra::log::info("decode", std::format("p7 compose setting={}", options.settings.doviP7Compose?1:0));
                if(!isCapture)veyra::log::info("decode",std::format("file decode preference={}",options.softwareDecode?"software":options.hardwareDecodeOnly?"hardware-only":"hardware-first"));
                // Diagnostic uses the production graph/presenter to validate
                // D3D12VA imports without needing a paired PS5 or credentials.
                if(!isCapture&&GetEnvironmentVariableW(L"VEYRA_TEST_FILE_HW_DECODE",nullptr,0)){
                    od.preferHardwareDecode=true;od.d3d12Device=ctx.device();od.d3d12Queue=ctx.directQueue();od.d3d12AdapterLuid=ctx.adapter().luid;
                }
                // Audio ingress policy has to be in place before the capture
                // graph negotiates its media type, otherwise the first connect
                // silently uses the previous mode. Kept above the branch chain:
                // inserting statements between `}else` and the open call
                // silently re-binds the `else` and made PS5 sessions fall
                // through to the file open check (fixed 2026-09-16).
                if(physicalCapture)captureSource.setAudioIngress(unsigned(options.settings.captureAudio));
                if(physicalCapture)captureSource.setVerticalFlip(options.settings.captureFlipVertical);
                if(physicalCapture)captureSource.setBufferMode(unsigned(options.settings.captureBuffer));
                if(physicalCapture)captureSource.setCpuUnpack(options.captureCpuUnpack);
#ifdef VEYRA_ENABLE_MOONLIGHT
                if(moon){
                    status(L"正在连接串流主机…");
                    ctx.device()->AddRef();moonlightRequest->decodeDevice=std::shared_ptr<ID3D12Device>(ctx.device(),[](ID3D12Device* device){device->Release();});
                    ctx.directQueue()->AddRef();moonlightRequest->decodeQueue=std::shared_ptr<ID3D12CommandQueue>(ctx.directQueue(),[](ID3D12CommandQueue* queue){queue->Release();});
                    if(!moon->connect(std::move(*moonlightRequest))){const auto message=moon->stats().message;status(message.empty()?L"串流连接失败，请查看诊断":message,true);break;}
                    moonlightRequest.reset();
                    const auto firstFrameDeadline=Clock::now()+std::chrono::seconds(20);
                    while(!stop_){
                        const AVFrame* first=nullptr;const auto result=moon->read(cachedPacket,&first);
                        if(result==source::SourceReadStatus::Frame){cachedFrame=av_frame_clone(first);break;}
                        if(result==source::SourceReadStatus::Error){const auto message=moon->stats().message;status(message.empty()?L"主机没有返回可解码的画面，请检查主机和网络后重新连接。":message,true);break;}
                        if(Clock::now()>firstFrameDeadline){status(L"已连接，但 20 秒内没有收到画面。请检查主机画面输出和编码设置。",true);break;}
                        std::this_thread::sleep_for(std::chrono::milliseconds(2));
                    }
                    if(stop_||!cachedFrame)break;
                }
#endif
#ifdef VEYRA_ENABLE_XBOX
                if(xb){
                    status(L"正在连接 Xbox…");
                    ctx.device()->AddRef();xboxRequest->decodeDevice=std::shared_ptr<ID3D12Device>(ctx.device(),[](ID3D12Device* device){device->Release();});
                    ctx.directQueue()->AddRef();xboxRequest->decodeQueue=std::shared_ptr<ID3D12CommandQueue>(ctx.directQueue(),[](ID3D12CommandQueue* queue){queue->Release();});
                    xboxRequest->stopRequested=&stop_;
                    if(!xb->connect(*xboxRequest)){const auto message=xb->stats().message;status(message.empty()?L"Xbox 串流连接失败，请查看诊断":message,true);break;}
                    const auto firstFrameDeadline=Clock::now()+std::chrono::seconds(20);
                    while(!stop_){
                        const AVFrame* first=nullptr;const auto result=xb->read(cachedPacket,&first);
                        if(result==source::SourceReadStatus::Frame){cachedFrame=av_frame_clone(first);break;}
                        if(result==source::SourceReadStatus::Error){const auto message=xb->stats().message;status(message.empty()?L"Xbox 没有返回可解码的画面，请重新连接。":message,true);break;}
                        if(Clock::now()>firstFrameDeadline){status(L"已连接 Xbox，但 20 秒内没有收到画面。请重新连接。",true);break;}
                        std::this_thread::sleep_for(std::chrono::milliseconds(2));
                    }
                    if(stop_||!cachedFrame)break;
                }
#endif
#ifdef VEYRA_ENABLE_REMOTEPLAY
                if(remote){
                    status(L"正在连接 PS5…");
                    ctx.device()->AddRef();remoteRequest->decodeDevice=std::shared_ptr<ID3D12Device>(ctx.device(),[](ID3D12Device* device){device->Release();});
                    if(!remote->connect(std::move(*remoteRequest))){status(L"PS5 连接失败，请查看诊断",true);break;}
                    remoteRequest.reset();
                    while(!stop_){
                        const AVFrame* first=nullptr;const auto result=remote->read(cachedPacket,&first);
                        const auto state=remote->sessionSnapshot().state;
                        {std::lock_guard lock(mutex_);snapshot_.remotePlayState=int(state);}
                        if(result==source::SourceReadStatus::Frame){cachedFrame=av_frame_clone(first);break;}
                        if(result==source::SourceReadStatus::Error){const auto recovery=remote->recoveryStatus();status(recovery.message.empty()?L"PS5 未返回可解码画面，请检查主机及网络后重新连接。":recovery.message,true);break;}
                        if(state==remoteplay::SessionState::LoginPinRequired)status(L"PS5 要求登录 PIN，请在串流面板输入");
                        std::this_thread::sleep_for(std::chrono::milliseconds(2));
                    }
                    if(stop_||!cachedFrame)break;
                }else{
#endif
                // Opening a source runs FFmpeg's demuxer, which can throw. Letting that
                // escape ends the whole session with a message that says nothing about
                // where it came from.
                bool sourceOpened=false;
                try{
                    sourceOpened=isMoonlight||isXbox||(physicalCapture?captureSource.configure(od):activeSource->open(od));
                }catch(const std::exception& e){
                    veyra::log::error("source-open",std::format("threw: {} (headers={} audio={})",
                        e.what(),od.networkHeaders.size(),od.audioPath.size()));
                    sourceOpened=false;
                }
                if(!isMoonlight&&!isXbox&&!sourceOpened){status(isScreen?screenSource.status():isFrameInput?frameInputSource.status():physicalCapture&&!captureSource.errorMessage().empty()?captureSource.errorMessage():!isCapture&&!source.errorMessage().empty()?source.errorMessage():L"无法打开视频，请查看诊断",true);break;}
#ifdef VEYRA_ENABLE_REMOTEPLAY
                }
#endif
                // A file's actual decoded pixel format and HDR VUI are only
                // reliable on AVFrame. Prime one frame before constructing
                // the graph so AV1/MOV 10-bit and HDR inputs do not get an
                // SDR graph by mistake. The cloned frame is consumed by the
                // normal owner-thread loop below, preserving its PTS.
                if(!isCapture){
                    pipeline::FramePacket firstPacket;const AVFrame* firstFrame=nullptr;
                    auto firstStatus=activeSource->read(firstPacket,&firstFrame);
                    // A network source collects its start-up buffer before the first picture; show the
                    // progress instead of an empty window, and let the user stop at any time.
                    {
                        auto nextShown=Clock::now();
                        while(firstStatus==source::SourceReadStatus::Waiting&&!stop_){
                            if(Clock::now()>=nextShown){
                                nextShown=Clock::now()+std::chrono::milliseconds(150);
                                const auto stats=source.networkStats();
                                {std::lock_guard lock(mutex_);snapshot_.network=stats;}
                                if(!stats.message.empty())status(stats.message);
                            }
                            firstStatus=activeSource->read(firstPacket,&firstFrame);
                        }
                        if(stop_)break;
                    }
                    if(firstStatus!=source::SourceReadStatus::Frame||firstFrame==nullptr||firstPacket.pts.isUnknown()){
                        status(activeSource->info().kind==pipeline::SourceKind::File&&source.errorMessage().empty()
                            ?L"视频首帧无法解码或没有有效时间戳，请查看诊断":source.errorMessage().empty()?L"视频首帧读取失败":source.errorMessage(),true);
                        break;
                    }
                    cachedFrame=av_frame_clone(firstFrame);
                    if(!cachedFrame){status(L"视频首帧缓存失败",true);break;}
                    cachedPacket=firstPacket;
                }
                width=activeSource->info().width;height=activeSource->info().height;duration=isCapture?0:activeSource->info().duration.toDouble();
                {std::lock_guard lock(mutex_);
                 const auto& si=activeSource->info();
                 snapshot_.sourceWidth=si.width;snapshot_.sourceHeight=si.height;
                 snapshot_.sourceDisplayAspect=si.displayAspect;
                 previewView_.rotationDegrees=si.rotationDegrees;
                 if(si.width&&si.height&&std::isfinite(si.displayAspect)&&si.displayAspect>0&&std::abs(si.displayAspect-double(si.width)/si.height)>.001)
                     previewView_.displayAspect=si.displayAspect;
                 snapshot_.sourceRotationDegrees=si.rotationDegrees;
                 // Poster for the minimal-mode bar. Built once, from the frame
                 // we already decoded; failure leaves it empty on purpose.
                 std::vector<uint8_t> poster;uint32_t pw=0,ph=0;
                 const AVFrame* posterSource=cachedFrame?cachedFrame:imageFrame;
                 if(posterSource&&makePosterFrame(posterSource,320,180,poster,pw,ph)){
                     snapshot_.posterRgba=std::move(poster);snapshot_.posterWidth=pw;snapshot_.posterHeight=ph;
                 }else{snapshot_.posterRgba.clear();snapshot_.posterWidth=snapshot_.posterHeight=0;}}
                {std::lock_guard lock(mutex_);snapshot_.sourceNotice=activeSource->info().dolbyVision.description();
                 const auto& si=activeSource->info();if(si.deinterlaced)snapshot_.sourceNotice+=std::format(L"{}去隔行：{} · {:.3f}i → {:.3f}p",snapshot_.sourceNotice.empty()?L"":L" · ",si.deinterlacePath=="d3d12-video-processor"?L"GPU":L"兼容软解",si.averageFps,si.averageFps);}
            }
            if(!pipeline::Extent{width,height}.valid()){status(L"图像尺寸超出单张GPU纹理能力，需要分块处理",true);break;}
            HdrDisplayState displayHdrState;
            bool displayQueryFailed=false;
            uint64_t hdrDisplaySerial=0;
            // Windows HDR comes from the shared display state (the same background
            // query as refresh and VRR, asked again only on a display change, a
            // monitor change or 刷新显示器状态). A new graph waits for a missing or
            // answer once (100ms maximum). A stale target-local cache stays
            // usable while the worker refreshes it; a settings transaction must
            // never wait for an unrelated slow VRR/driver call to finish.
            auto displayHdrActive=[&]{
                const HMONITOR target=displayStates_.monitorOf(window);
                auto known=displayStates_.state(target);
                if(!known||known->generation!=displayStates_.generation()){
                    displayStates_.request(window,"hdr-output");
                    if(!known)known=displayStates_.wait(target,std::chrono::milliseconds(100));
                }
                const std::optional<bool> queried=known?known->color.hdr:std::nullopt;
                if(known)hdrDisplaySerial=known->serial;
                const bool active=displayHdrState.update(reinterpret_cast<std::uintptr_t>(target),queried);
                if(!queried&&!displayQueryFailed)veyra::log::warn("display-color",std::format("HDR display query unavailable; using target-local hdr={} (unknown target defaults to SDR)",active));
                if(queried&&displayQueryFailed)veyra::log::info("display-color",std::format("HDR display query recovered hdr={}",active));
                displayQueryFailed=!queried.has_value();
                return active;
            };
            pipeline::EnhanceGraphDesc gd;gd.sourceWidth=width;gd.sourceHeight=height;gd.hdrInput=!isImage&&activeSource->info().color.isHdrPath();
            {const auto& sourceColor=activeSource->info().color;
    const unsigned sourceMastering=hdrMetadataNits(sourceColor.hdrMasteringPeakNits);
    const unsigned sourceCll=hdrMetadataNits(sourceColor.hdrMaxCllNits);
    const unsigned sourceFall=hdrMetadataNits(sourceColor.hdrMaxFallNits);
    std::lock_guard lock(mutex_);snapshot_.sourceHdr=gd.hdrInput;
    snapshot_.sourceMasteringPeakNits=sourceMastering;snapshot_.sourceMaxCllNits=sourceCll;
    snapshot_.sourceMaxFallNits=sourceFall;
      const auto& dvinfo=activeSource->info().dolbyVision;
      snapshot_.sourceDoviProfile=dvinfo.present?dvinfo.profile:0;
      snapshot_.sourceDoviRpu=dvinfo.present&&dvinfo.rpuDeclared;
      snapshot_.sourceDoviEnhancement=dvinfo.present&&dvinfo.enhancementLayer;
      snapshot_.sourceHdr10Plus=activeSource->info().hdr10Plus.present;}
            // Every source is resampled to the screen with the high-quality present
            // path (bounded Catmull-Rom up, Catmull-Rom widened by the shrink factor
            // down; PresentBlit.hlsl).
            // Until 2026-11-18 only PS5 Remote Play was: fullscreen captures and files
            // were magnified bilinearly (soft) and shrunk without filtering (jagged).
            // VEYRA_TEST_PRESENT_BILINEAR=1 restores the old sampling for comparison.
            static const bool bilinearPresent=GetEnvironmentVariableW(L"VEYRA_TEST_PRESENT_BILINEAR",nullptr,0)>0;
            gd.highQualityPresentation=!bilinearPresent;
            // PushFPS: what used the fine path before 4.1; the presenter falls back to it when sharp
            // scaling is switched off (engine/PushPresentScaling.h).
            gd.finePresentationBefore41=isRemote&&activeSource->info().color.reconstructChroma;
            gd.rgbInput=isImage||isScreen||(isCapture&&activeSource->info().color.pixelFormat==pipeline::SourcePixelFormat::Bgra8);
            auto ingressBitDepth=[](pipeline::SourcePixelFormat format){return format==pipeline::SourcePixelFormat::P010||format==pipeline::SourcePixelFormat::V210||format==pipeline::SourcePixelFormat::Rgb10xLE?10u:format==pipeline::SourcePixelFormat::P016?16u:8u;};
            gd.captureBitDepth=ingressBitDepth(activeSource->info().color.pixelFormat);
            gd.yuy2Input=isCapture&&activeSource->info().color.pixelFormat==pipeline::SourcePixelFormat::Yuy2;gd.stillImage=isImage;
            gd.packedInput=isCapture?pipeline::packedInputCode(activeSource->info().color.pixelFormat):0;
            auto captureGraphColor=activeSource->info().color;
            const bool nvidiaAdapter=ctx.adapter().isNvidia;
            // AMD adapters run NR on the lmxxf runtime. Both the normalization
            // and the stage description used to drop NR on every non-NVIDIA
            // adapter, so AMD NR never ran in the product (field log 2026-10-05,
            // RX 9070 XT: "normalized ... nr=false").
            const bool amdNrAdapter=ctx.adapter().vendorId==0x1002;
            auto stageRequest=[&](const PlayerOptions& o){
                StageRequest r;r.nr=o.nr;r.sr=o.sr;r.fg=o.fg;r.fgMultiplier=o.fgMultiplier;
                r.width=width;r.height=height;r.stillImage=isImage;r.nvidiaAdapter=nvidiaAdapter;r.amdNr=amdNrAdapter;
                r.uncompressedSource=isScreen||(physicalCapture&&!captureSource.compressedVideo());
                r.liveSource=isCapture;
                r.nodeOrder=o.nodeOrder?&*o.nodeOrder:nullptr;return r;
            };
            describeStages(stageRequest(options),options.snapshot(),gd);
            gd.noFeatures=false;
            gd.hdrOutput=options.settings.useHdrPreview(gd.hdrInput,displayHdrActive());
            veyra::log::info("display-color",std::format("hdrInput={} hdrOutput={} forceSdrPreview={}",gd.hdrInput,gd.hdrOutput,options.settings.forceSdrPreview));
            gd.runtimeAbsPath=runtime::localRuntimeDirectory().wstring();
            gd.compatibilityPreflight=[this](const auto& desc,const auto& device){return checkFgCompatibility(desc,device,stop_);};
            std::wstring backendRecoveryWarning;
            bool nrAutoPoolUnavailable=false;
            std::wstring nrAutoStatus;
            auto openPreparedPresenter=[&](const PlayerOptions& selected,bool createViews=true){
                // NGX creation cannot be interrupted. Observe exit when it
                // returns, before touching a UI-owned HWND or creating views.
                return !stop_&&presenter.open(ctx,window,*graph,selected.settings.captureCompatible,!isCapture&&!isImage)&&
                    !stop_&&(!createViews||graph->createViews());
            };
            auto initializePreview=[&](pipeline::EnhanceGraphDesc& desc,PlayerOptions& selected,bool preserveWorkingFg=false,bool preserveWorkingNr=false){
                backendRecoveryWarning.clear();
                auto supported=selected.snapshot();
                if(disableUnsupportedNvidiaEffects(supported,nvidiaAdapter,amdNrAdapter)){
                    selected=PlayerOptions::from(supported,selected.nodeOrder,&selected);
                    // Same stage rules as every other build: AMD FSR upscaling
                    // survives the normalization, it used to be dropped here.
                    describeStages(stageRequest(selected),selected.snapshot(),desc);
                    backendRecoveryWarning=amdNrAdapter?L"当前 GPU 不支持 NVIDIA 增强；超分及 DLSS 已关闭，NR 使用 AMD 运行库，XeSS选择保留":
                        L"当前 GPU 不支持 NVIDIA 增强；NR、超分及 DLSS 已关闭，XeSS选择保留";
                    veyra::log::warn("capability","normalized requested NVIDIA effects before graph creation; applied settings reflect actual disabled stages");
                }
                for(unsigned attempt=0;attempt<6;++attempt){
                    if(stop_)return false;
                    desc.vfgAsyncSubmission=!isImage&&selected.settings.frameGenerationBackend==FrameGenerationBackend::Vfg&&
                        GetEnvironmentVariableW(L"VEYRA_TEST_VFG_SYNC_SUBMIT",nullptr,0)==0;
                    desc.vfgFastFallback=desc.vfgAsyncSubmission&&selected.settings.vfgAutoRegulate&&(physicalCapture||isScreen||testReplayAsCard)&&selected.settings.multiplier==2&&
                        GetEnvironmentVariableW(L"VEYRA_TEST_LEGACY_LIVE_PACING",nullptr,0)==0;
                    // NR inference reuse belongs to the realtime preview only:
                    // export, the image path and the paused frame infer every frame.
                    desc.nrReusePreview=!isImage;
                    desc.videoHdr=selected.settings.videoHdr;
                    desc.hdrOutput=selected.settings.useHdrPreview(desc.hdrInput,displayHdrActive());
                    // Auto is optional and preview-only; fixed/export policies
                    // retain their existing contract. A prewarmed graph has no pool.
                    desc.nrAutoPoolLayer.reset();
                    const auto automatic=std::find(desc.nrLayersSizePolicy.begin(),desc.nrLayersSizePolicy.end(),pipeline::NrSizePolicy::Auto);
                    const bool autoRequested=selected.nr&&automatic!=desc.nrLayersSizePolicy.end();
                    const bool tested=GetEnvironmentVariableW(L"VEYRA_TEST_NR_AUTO_POOL",nullptr,0)>0;
                    const bool admitted=(tested||(autoRequested&&automatic==desc.nrLayersSizePolicy.begin()&&selected.settings.activeAutoNrLayerCount()==1))&&
                       !nrAutoPoolUnavailable&&selected.settings.activeNrLayerCount()<=2&&
                       !isCapture&&!isImage&&desc.enableNr&&!desc.enableSr&&!desc.enableFg&&
                       !desc.hdrWorking()&&!desc.videoHdr.enabled&&!desc.color.enabled&&!desc.additionalColorCount&&!desc.antiAliasActive()&&!desc.beautyActive()&&!desc.runtimeNodeOrder&&desc.nrHoldStrength==0&&
                       desc.nrReuse==NrReuseMode::Off&&
                       currentNrRuntime(desc.nrRuntime)==NrRuntime::Ampere&&desc.opticalFlowBackend==OpticalFlowBackend::Nvidia&&
                       desc.nrMotion==MotionSource::OpticalFlow&&
                       nvidiaAdapter&&ctx.adapter().deviceId==0x2f04&&desc.workWidth==1920&&desc.workHeight==1080&&
                       desc.sourceWidth==1920&&desc.sourceHeight==1080&&
                       !desc.nrLayersExtent.empty()&&desc.nrLayersExtent[0]==pipeline::Extent{1920,1080}&&
                       std::none_of(desc.nrLayersTemporal.begin(),desc.nrLayersTemporal.end(),[](bool value){return value;});
                    nrAutoStatus.clear();
                    if(admitted)desc.nrAutoPoolLayer=0;
                    else if(autoRequested)nrAutoStatus=nrAutoPoolUnavailable?
                        L"自动NR实例池不可用，保留1080p NR":L"当前配置未启用自动NR，保留1080p NR";
                    // The only graph allowed beside an inactive NR adapter is
                    // effects-off. Evict before any other NGX initialization.
                    if(recentGraphCache.hasCachedGraph()&&!RecentGraphCache::effectsOff(desc)){
                        recentGraphCache.evict("enhancement-build");
                        graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,&coreCache);
                    }
                    uint64_t buildBudget=0,buildUsage=0;const bool measuredBefore=ctx.videoMemoryInfo(buildBudget,buildUsage);
                    const bool adopted=gpu->adopt(selected.snapshot(),desc);
                    if(!adopted&&!gpu->configureQueue(desc,!isCapture&&!isImage))return false;
                    bool opened=adopted||graph->initialize(desc);
                    if(stop_){veyra::log::info("engine","preview initialization cancelled after graph creation");return false;}
                    auto failure=graph->failedBackend();
                    if(opened){
                        opened=openPreparedPresenter(selected);
                        failure=FailedBackend::Infrastructure;
                        if(opened&&graph->xessEnabled()&&!presenter.xessActive()){opened=false;failure=FailedBackend::Fg;}
                        if(opened&&graph->fsrEnabled()&&!graph->fsrActive()){opened=false;failure=FailedBackend::Fg;}
                        // Requested AMD FSR upscaling that could not be created
                        // (missing local runtime, unsupported layout) degrades
                        // to the plain scale path with a visible warning.
                        if(opened&&graph->fsrSrRequested()&&!graph->fsrSrEnabled()){opened=false;failure=FailedBackend::Sr;}
                    }
                if(stop_)return false;
                if(opened){
                    uint64_t afterBudget=0,afterUsage=0;
                    const auto newBytes=measuredBefore&&ctx.videoMemoryInfo(afterBudget,afterUsage)&&afterUsage>buildUsage?afterUsage-buildUsage:0;
                    graphBytes=adopted?graphBytes+newBytes:newBytes;
                    {std::lock_guard lock(mutex_);snapshot_.nrAutoStatus=nrAutoStatus;snapshot_.nrAutoActive=false;
                     snapshot_.nrAutoPercent=snapshot_.nrAutoWidth=snapshot_.nrAutoHeight=0;}
                    return true;
                }
                if(desc.nrAutoPoolLayer&&failure==FailedBackend::Nr&&SUCCEEDED(ctx.device()->GetDeviceRemovedReason())){
                    nrAutoPoolUnavailable=true;graph->shutdown();
                    veyra::log::warn("nr-auto","pool initialization unavailable; retrying the same NR settings at fixed 1080p");
                    continue;
                }
                // A live backend/multiplier switch must not turn a working FG
                // session into effects-off playback when the new provider fails.
                // FSR 4 ML that the provider does not offer switches to FSR 3.1
                // below rather than rolling the request back.
                if(preserveWorkingFg&&failure==FailedBackend::Fg&&selected.settings.frameGenerationBackend!=FrameGenerationBackend::Fsr4)return false;
                if(preserveWorkingNr&&failure==FailedBackend::Nr)return false;
                auto reduced=selected.snapshot();
                // Requested multiplier above this GPU's capability: clamp to what
                // the runtime supports and say so, instead of dropping frame
                // generation entirely (the old behaviour users saw as "选了 4X
                // 之后补帧直接没了").
                bool clampedOverCapability=false;
                int capabilityGeneratedFrames=-1;
                if(failure==FailedBackend::Fg&&reduced.multiplier>1){
                    if(reduced.frameGenerationBackend==FrameGenerationBackend::Dlss)capabilityGeneratedFrames=graph->fgMultiFrameCountMax();
                    else if(reduced.frameGenerationBackend==FrameGenerationBackend::XeSS){
                        const auto xessState=gfx::XessMfgUnlock::snapshot();
                        if(xessState.applied)capabilityGeneratedFrames=int(xessState.maxInterpolations);
                    }
                    else if(fsrFrameGeneration(reduced.frameGenerationBackend)){
                        capabilityGeneratedFrames=int((graph->fsrActive()?1u:0u));
                    }
                    else if(reduced.frameGenerationBackend==FrameGenerationBackend::AmdFrc){
                        capabilityGeneratedFrames=int((graph->amfFrcActive()?1u:0u));
                    }
                    else if(reduced.frameGenerationBackend==FrameGenerationBackend::PushFlow){
                        capabilityGeneratedFrames=graph->pushFlowActive()?3:0;
                    }
                }
                if(capabilityGeneratedFrames>0&&int(reduced.multiplier)-1>capabilityGeneratedFrames){
                    const uint32_t clamped=uint32_t(capabilityGeneratedFrames+1);
                    veyra::log::warn("backend-recovery",std::format("requested multiplier {} exceeds capability maxGeneratedFrames={}; applying {}X with frame generation kept",reduced.multiplier,capabilityGeneratedFrames,clamped));
                    reduced.multiplier=clamped;
                    clampedOverCapability=true;
                    if(!backendRecoveryWarning.empty())backendRecoveryWarning+=L"；";
                    backendRecoveryWarning+=std::format(L"当前最多支持 {}X 帧生成，已按 {}X 应用",clamped,clamped);
                }
                if(FAILED(ctx.device()->GetDeviceRemovedReason()))return false;
                if(!clampedOverCapability&&!disableFailedBackend(reduced,failure))return false;
                    veyra::log::warn("backend-recovery",std::format("initialization failed component={} attempt={} revision={} -> nr={} sr={} multiplier={}; original SDK error above",unsigned(failure),attempt+1,reduced.revision,reduced.nr,reduced.sr,reduced.multiplier));
                    if(!backendRecoveryWarning.empty())backendRecoveryWarning+=L"；";
                    const uint32_t ngxResult=uint32_t(graph->failedNgxResult());
                    if(selected.settings.frameGenerationBackend==FrameGenerationBackend::Anr&&failure==FailedBackend::Fg)
                        backendRecoveryWarning+=L"ANR 帧生成未能启用，已关闭补帧；请检查运行组件、驱动与工作尺寸（至少 640×360），详细原因见日志";
                    else if(selected.settings.frameGenerationBackend==FrameGenerationBackend::Vfg&&failure==FailedBackend::Fg)
                        backendRecoveryWarning+=L"NVIDIA VFG 未能启用（需要 Ada / Blackwell 显卡、VFG 运行组件和支持的输出格式），已关闭补帧；原因见日志";
                    else if(selected.settings.frameGenerationBackend==FrameGenerationBackend::AmdFrc&&failure==FailedBackend::Fg)
                        backendRecoveryWarning+=L"AMD FRC 未能启用（需要 AMD 显卡和驱动自带的 AMF 运行库），已关闭补帧；原因见日志";
                    else if(selected.settings.frameGenerationBackend==FrameGenerationBackend::PushFlow&&failure==FailedBackend::Fg)
                        backendRecoveryWarning+=L"PushFlow 未能启用（需要 DirectX 12 显卡和 PushFlow 运行组件），已关闭补帧；原因见日志";
                    else if(selected.settings.frameGenerationBackend==FrameGenerationBackend::Fsr4&&failure==FailedBackend::Fg)
                    {
                        backendRecoveryWarning+=L"FSR 4 ML 提供方不可用（需要支持的 RX 9000 和驱动），已改用 FSR 3.1；原因见日志";
                        veyra::log::warn("fsr-fg","FSR 4 ML unavailable on this adapter/driver; switching to FSR 3.1 at 2X");
                    }
                    else if((ngxResult&0xFFF00000u)==0xBAD00000u)
                        backendRecoveryWarning+=std::wstring(backendFailureName(failure))+L"："+ngxFailureHint(ngxResult)+std::format(L"（NGX 0x{:08X}，驱动 {}），已关闭依赖效果",ngxResult,ctx.adapter().driverVersion);
                    else if(!clampedOverCapability)
                        backendRecoveryWarning+=std::wstring(backendFailureName(failure))+L" 初始化失败，已关闭依赖效果；原因见诊断日志";
                    if(!graph->driverRequirementNotice().empty())backendRecoveryWarning+=L"；"+graph->driverRequirementNotice();
                    if(failure==FailedBackend::Fg&&(ngx::AmpereMfgUnlock::applied()||(ngx::DlssgTransfusion::applied()&&ngx::DlssgTransfusion::snapshot().target==ngx::DlssgTransfusion::Target::Ampere)))backendRecoveryWarning+=L"；RTX 30 系补帧解锁已应用，但当前驱动/运行库组合下运行时不开放补帧，可改用 AMD FSR 补帧";

                    if(!ring.drainQueue()||!ring.discardRecording())return false;
                    if(!presenter.prepareGraphChange())return false;
                    graph->shutdown();selected=PlayerOptions::from(reduced,selected.nodeOrder,&selected);
                    describeStages(stageRequest(selected),selected.snapshot(),desc);
                }
                return false;
            };
            auto publishFrameGenerationCapabilities=[&]{
                // Read the active provider after every rebuild or rollback;
                // an initial effects-off graph has no DLSS capability yet.
                std::lock_guard lock(mutex_);
                fgMultiFrameMaxCap_=graph->fgMultiFrameCountMax();
                snapshot_.fgMultiFrameMax=fgMultiFrameMaxCap_;
                snapshot_.fgCapabilityKnown=fgMultiFrameMaxCap_>0;
                snapshot_.dlssgLiteState=graph->dlssgLiteState();
                const auto xessState=gfx::XessMfgUnlock::snapshot();
                // Unknown until the XeSS provider actually ran: a DLSS-only
                // session must not restrict the XeSS choices in the UI.
                xessMaxInterpolatedFramesCap_=presenter.xessActive()?int(std::max(1u,xessState.maxInterpolations)):0;
                snapshot_.xessMaxInterpolatedFrames=xessMaxInterpolatedFramesCap_;
                // AMD FSR ceiling comes from the active graph provider; 0 keeps the
                // settings UI on its static 2X fallback until a session ran.
                fsrMaxGeneratedFramesCap_=graph->fsrEnabled()&&graph->fsrActive()?int((graph->fsrActive()?1u:0u)):0;
                snapshot_.fsrMaxGeneratedFrames=fsrMaxGeneratedFramesCap_;
                snapshot_.fsrProviderVersion=graph->fsrProviderVersion();
                snapshot_.fsrSrProviderVersion=graph->fsrSrProviderVersion();
                snapshot_.hudLockState=graph->hudLockState();snapshot_.hudStillState=graph->hudStillState();snapshot_.crosshairHoldState=graph->crosshairHoldState();snapshot_.crosshairHoldPixels=int(graph->crosshairHoldPixels());snapshot_.crosshairHoldFrames=graph->crosshairHoldFrames();
                if(fgMultiFrameMaxCap_>0)veyra::log::info("settings",std::format("frame-generation capability: maxGeneratedFrames={} maxMultiplier={}",fgMultiFrameMaxCap_,fgMultiFrameMaxCap_+1));
                veyra::log::info("settings",std::format("xess capability: active={} maxInterpolatedFrames={} unlockApplied={} (active context only)",presenter.xessActive(),xessMaxInterpolatedFramesCap_,xessState.applied));
                if(fsrMaxGeneratedFramesCap_>0)veyra::log::info("settings",std::format("fsr capability: generatedPerPresent={} => maxMultiplier={}",fsrMaxGeneratedFramesCap_,fsrMaxGeneratedFramesCap_+1));
            };
            const auto initialRequested=options.snapshot();
            const bool previewInitialized=initializePreview(gd,options);
            if(stop_)break;
            publishFrameGenerationCapabilities();
            if(!previewInitialized){status(L"视频初始化失败，请查看对应组件的诊断日志",true);break;}
            if(!backendRecoveryWarning.empty()){
                std::lock_guard lock(mutex_);desired_.rejectVideoRequest(initialRequested,options.snapshot());snapshot_.desired=desired_;snapshot_.rejectedRevision=initialRequested.revision;snapshot_.backendWarning=backendRecoveryWarning;
            }
            if(!nvidiaAdapter&&nvidiaOnlyStagesRequested(options.nr,options.sr,options.fg,options.settings,amdNrAdapter)){
                veyra::log::warn("capability",std::format("non-NVIDIA adapter disabled requested features: nr={} sr={} fgBackend={} flowBackend={}",options.nr,options.sr,frameGenerationBackendName(options.settings.frameGenerationBackend),opticalFlowBackendName(options.settings.opticalFlowBackend)));
                status(L"当前非 NVIDIA 适配器：NR、NVIDIA 超分与 DLSS 已禁用；可使用 XeSS 预览和 AMD 光流",false);
            }
            if(gd.hdrInput)status(gd.hdrOutput?L"HDR输入 · HDR保留增强/显示":L"HDR输入 · SDR色调映射后增强/显示（1000nit参考峰值）",false);
            if(graph->xessEnabled()&&!presenter.xessActive())status(L"XeSS 未启用：运行时或设备不兼容；当前为普通呈现",false);
            {
                std::lock_guard lock(mutex_);
                if(!nvidiaAdapter&&nvidiaOnlyStagesRequested(options.nr,options.sr,options.fg,options.settings,amdNrAdapter))snapshot_.backendWarning=L"当前 GPU 不支持所选 NVIDIA 增强";
                if(graph->xessEnabled()&&!presenter.xessActive())snapshot_.backendWarning=L"XeSS 初始化失败；当前为普通呈现";
            }
            captureSource.setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
            captureSource.setAudioIngress(unsigned(options.settings.captureAudio));
            captureSource.setVerticalFlip(options.settings.captureFlipVertical);
            captureSource.setBufferMode(unsigned(options.settings.captureBuffer));
            if(physicalCapture){
                // Commit monitoring before the first PCM can reach the endpoint,
                // including deferred bitstream/vendor sessions.
                captureSource.setAudioGain(muted_||!captureAudioMonitoring_?0.0f:volume_.load());
                captureSource.setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                if(!captureSource.start()){status(L"无法启动采集，请查看诊断",true);break;}
            }
            {std::lock_guard lock(mutex_);snapshot_.duration=duration;snapshot_.nominalSourceFps=isImage?0:activeSource->info().averageFps;snapshot_.running=true;snapshot_.transport=TransportState::Playing;snapshot_.image=isImage;snapshot_.capture=isCapture;snapshot_.applied=options.snapshot();snapshot_.desired=desired_;}
            status(isImage?L"图片已增强，可保存PNG/JPEG":std::format(L"{} | 输入 {}×{} / 底图 {}×{} / NR {}×{} / 光流 {}×{} / FG与输出 {}×{} | {}",isRemote?L"PS5 串流":isMoonlight?L"PC 串流":isXbox?L"Xbox 串流":isCapture?L"实时采集":L"播放",width,height,gd.workWidth,gd.workHeight,gd.nrWidth,gd.nrHeight,gd.flowWidth,gd.flowHeight,gd.workWidth,gd.workHeight,gd.nrBeforeSr?L"低延迟 · NR先行后超分":gd.nrWidth<gd.workWidth?L"实时内部处理并回填":L"原生NR（性能成本较高）"));
            pipeline::EnhanceGraph::FrameOutputs out;bool reset=true,hasOutput=false,audioRebuffering=false,seekPreviewPending=false;
            bool initialRemoteFramePending=isStream;
            bool initialFileFramePending=!isImage&&!isCapture;
            uint64_t activeSeekId=0;
            // When the demuxer finished re-positioning; the gap to the first presented
            // frame is decode + first enhanced frame.
            Clock::time_point seekDemuxDone{};
            Clock::time_point seekStarted{};
            uint64_t seekDecoded=0;
            bool fileAwaitingVideo=true,fileAudioAlignPending=true,fileInputEnded=false;double lastFilePresentedMs=0,lastFilePresentLateness=0;
            TimingWindow presentEntryDeviation,presentReturnDeviation;
            // Network sources and files on a server share ONE connection between picture and sound:
            // the audio pipeline reads the same demux session instead of opening the address again.
            const auto demuxSession=isImage||isCapture?std::shared_ptr<media::DemuxSession>{}:source.sharedSession();
            // A DASH source (Bilibili) has no audio in its video container: the audio
            // arrives as its own address, so that address wins over the shared video
            // session, which carries no audio stream at all.
            const bool separateAudio=!options.audioPath.empty();
            const std::wstring audioTarget=separateAudio?options.audioPath:path;
            // Opening the audio address runs FFmpeg's demuxer, which can throw. Without
            // this guard a failure there escapes into the engine's outer catch and ends
            // the whole session, which is exactly what "bad allocation" was reporting.
            bool audioOpened=false;
            try{
                // The DASH audio address needs the same Referer/UA the video one uses.
                audioOpened=!isImage&&!isCapture&&((demuxSession&&!separateAudio)
                    ?audioPipe.open(demuxSession)
                    :audioPipe.open(audioTarget,&stop_,options.network.requestHeaders,options.network.userAgent));
            }catch(const std::exception& e){
                veyra::log::error("audio",std::format("open failed: {} (separateAudio={} targetLen={})",
                                                      e.what(),separateAudio?1:0,audioTarget.size()));
                audioOpened=false;
            }
            if(audioOpened){
                {std::lock_guard lock(mutex_);snapshot_.audioTracks=audioPipe.tracks();snapshot_.selectedAudioTrack=audioPipe.selectedTrack();}
                audioPipe.holdForVideo();audioPipe.startThread(&audio,true);audioStarted=true;
                std::lock_guard lock(mutex_);snapshot_.audioAvailable=true;
                veyra::log::info("audio",std::format("pipeline started separateAudio={} tracks={}",separateAudio?1:0,audioPipe.tracks().size()));
            }else if(demuxSession){
                demuxSession->selectAudioStream(-1);   // nobody reads audio: stop queueing it
                veyra::log::info("net-session","no audio pipeline for this source; audio packets are dropped");
            }
            auto holdFileAudio=[&]{if(audioStarted)audioPipe.holdForVideo();fileAwaitingVideo=true;fileInputEnded=false;};
            TimingWindow captureAges,scheduleWaits,processTimes,presentTimes,decodeTimes,gpuReadyTimes;
            std::array<TimingWindow,size_t(diagnostics::GpuStage::Count)> gpuStageTimes;
            std::array<uint64_t,size_t(diagnostics::GpuStage::Count)> lastGpuSampleEnd{};
            auto nextTimingLog=Clock::now()+std::chrono::seconds(1);
            // Video memory watchdog. A field log (RTX 5060 Ti, 2026-10-01) grew +3 GB a minute while
            // fullscreen, kept it after leaving fullscreen, and every pass slowed down once usage
            // passed the budget (5 fps). Unreproduced here. On growth beyond max(2 GiB, budget/4)
            // with no settings change the log names every third-party module, and the loop
            // rebuilds first the presentation swapchain, then (if that released less than half)
            // the processing graph too, logging what each released: the swapchain step points
            // at the driver or an overlay hooked on it, the graph step at our own passes.
            uint64_t vramFloor=0,vramRevision=~0ull,vramRecoverBefore=0,vramRecoverGrowth=0;auto vramSettleUntil=Clock::now(),vramRecoverCheckAt=Clock::now();
            bool vramWarned=false;int vramRecoverStep=0,vramRecoverDone=0,vramRecoveries=0;
            bool vramFullscreenBlocked=false;unsigned vramGrowthSamples=0;
            bool vramProtectionEnabled=fullscreenMemoryProtection_.load();
            // VEYRA_TEST_VRAM_LEAK_MIB=n: hold on to n MiB more of video memory every second;
            // VEYRA_TEST_VRAM_LEAK_RELEASE=1 lets the swapchain rebuild free it (as a leak tied
            // to the swapchain would), otherwise nothing frees it.
            const uint64_t testLeakMiB=[]{wchar_t v[16]{};return GetEnvironmentVariableW(L"VEYRA_TEST_VRAM_LEAK_MIB",v,16)?uint64_t(_wtoi(v)):0ull;}();
            const uint64_t testLeakLimitMiB=[]{wchar_t v[16]{};return GetEnvironmentVariableW(L"VEYRA_TEST_VRAM_LEAK_LIMIT_MIB",v,16)?uint64_t(std::max(0,_wtoi(v))):0ull;}();
            const bool testLeakReleases=GetEnvironmentVariableW(L"VEYRA_TEST_VRAM_LEAK_RELEASE",nullptr,0)>0;
            const bool testLeakFullscreenOnly=GetEnvironmentVariableW(L"VEYRA_TEST_VRAM_LEAK_FULLSCREEN_ONLY",nullptr,0)>0;
            std::vector<Microsoft::WRL::ComPtr<ID3D12Resource>> testLeak;
            auto watchVram=[&](uint64_t usage,uint64_t budget){
                (void)recentGraphCache.checkBudget();
                bool fullscreen=false;
                {std::lock_guard lock(mutex_);fullscreen=presentation_.fullscreen;}
                if(testLeakMiB&&(!testLeakLimitMiB||uint64_t(testLeak.size()+1)*testLeakMiB<=testLeakLimitMiB)&&(!testLeakFullscreenOnly||fullscreen)){
                    const D3D12_HEAP_PROPERTIES heap{D3D12_HEAP_TYPE_DEFAULT};
                    D3D12_RESOURCE_DESC desc{};desc.Dimension=D3D12_RESOURCE_DIMENSION_BUFFER;desc.Width=testLeakMiB<<20;desc.Height=1;desc.DepthOrArraySize=1;desc.MipLevels=1;desc.SampleDesc.Count=1;desc.Layout=D3D12_TEXTURE_LAYOUT_ROW_MAJOR;
                    Microsoft::WRL::ComPtr<ID3D12Resource> r;
                    const auto hr=ctx.device()->CreateCommittedResource(&heap,D3D12_HEAP_FLAG_NONE,&desc,D3D12_RESOURCE_STATE_COMMON,nullptr,IID_PPV_ARGS(&r));
                    if(SUCCEEDED(hr))testLeak.push_back(r);
                    log::info("vram-test",std::format("allocationMiB={} heldMiB={} limitMiB={} hr=0x{:X}",testLeakMiB,uint64_t(testLeak.size())*testLeakMiB,testLeakLimitMiB,unsigned(hr)));
                }
                const bool protection=fullscreenMemoryProtection_.load();
                if(protection!=vramProtectionEnabled){
                    vramProtectionEnabled=protection;vramFullscreenBlocked=false;vramGrowthSamples=0;vramFloor=0;
                    vramSettleUntil=Clock::now()+std::chrono::seconds(10);
                }
                if(!usage)return;
                // Leaving fullscreen stopped further growth in both field logs. Preserve
                // the source/effects and avoid repeated failed graph rebuilds. This only
                // contains the observed trigger; it does not identify the allocation owner
                // or promise that already retained memory is returned.
                if(vramFullscreenBlocked)return;
                if(vramRecoverDone){
                    if(Clock::now()<vramRecoverCheckAt)return;
                    const int64_t released=(int64_t(vramRecoverBefore)-int64_t(usage))/(1<<20);
                    veyra::log::warn("vram-watch",std::format("{} rebuild released {} MiB of {} MiB growth (before {} MiB, now {} MiB)",
                        vramRecoverDone==1?"swapchain":"graph+swapchain",released,vramRecoverGrowth>>20,vramRecoverBefore>>20,usage>>20));
                    // The graph is rebuilt only with room for it: a rebuild that runs out of budget
                    // stops the session, which is worse than running slowly.
                    if(vramRecoverDone==1&&released<int64_t(vramRecoverGrowth>>21)){
                        if(budget&&usage<budget/100*85)vramRecoverStep=2;
                        else veyra::log::warn("vram-watch","graph rebuild skipped: too close to the budget to rebuild safely");
                    }
                    vramRecoverDone=0;vramFloor=0;vramSettleUntil=Clock::now()+std::chrono::seconds(5);
                    return;
                }
                if(vramRecoverStep)return;
                if(options.settings.revision!=vramRevision){vramRevision=options.settings.revision;vramFloor=0;vramGrowthSamples=0;vramSettleUntil=Clock::now()+std::chrono::seconds(10);}
                if(Clock::now()<vramSettleUntil)return;
                if(!vramFloor||usage<vramFloor)vramFloor=usage;
                const uint64_t growth=usage-vramFloor;
                const uint64_t fullscreenLimit=std::max<uint64_t>(512ull<<20,std::min<uint64_t>(2048ull<<20,budget/8));
                if(vramProtectionEnabled&&fullscreen&&growth>fullscreenLimit){
                    if(++vramGrowthSamples<3)return;
                    vramFullscreenBlocked=true;vramWarned=true;
                    const std::wstring injected=gfx::riskyInjections();
                    {
                        std::lock_guard lock(mutex_);
                        snapshot_.vramRunawayMiB=growth>>20;snapshot_.vramInjected=injected;snapshot_.vramFullscreenUnsafe=true;
                    }
                    veyra::log::warn("vram-watch",std::format("sustained fullscreen growth {} MiB (usage {} / budget {} MiB); requesting windowed playback, preserving source/effects; allocation owner unconfirmed; modules: {}",
                        growth>>20,usage>>20,budget>>20,gfx::thirdPartyModules()));
                    return;
                }
                vramGrowthSamples=0;
                const uint64_t limit=std::max<uint64_t>(2048ull<<20,budget/4);
                if(growth<=limit)return;
                // Module presence is diagnostic context, not proof of allocation ownership.
                // Evaluate a bounded recovery by the measured memory result, regardless of
                // whether NVIDIA's plug-in (also present in stable local runs) is loaded.
                const std::wstring injected=gfx::riskyInjections();
                if(!vramWarned){
                    vramWarned=true;
                    veyra::log::warn("vram-watch",std::format("video memory grew {} MiB with no settings change (now {} of {} MiB budget); third-party modules: {}",
                        growth>>20,usage>>20,budget>>20,gfx::thirdPartyModules()));
                    std::lock_guard lock(mutex_);snapshot_.vramRunawayMiB=growth>>20;snapshot_.vramInjected=injected;
                }else veyra::log::warn("vram-watch",std::format("video memory grew {} MiB again (now {} MiB)",growth>>20,usage>>20));
                if(vramRecoveries<3){++vramRecoveries;vramRecoverStep=1;vramRecoverGrowth=growth;}
                else{vramFloor=usage;}   // give up rebuilding; report again only on further growth
            };
            double playbackRate=1.0;
            auto anchor=Clock::now(),statsStart=anchor;double anchorMs=0;uint64_t frames=0,sourceFrames=0;bool wasPaused=false;double discardBefore=0;
            double lastAudioClockMs=0;bool audioClockExhausted=false;auto audioTailAnchor=anchor;
            bool publishedAudioRecovery=false;HRESULT publishedAudioError=S_OK;uint64_t publishedAudioRecoveries=0;
            const bool injectFileEndpointLoss=GetEnvironmentVariableW(L"VEYRA_TEST_FILE_ENDPOINT_LOSS",nullptr,0)>0;
            bool fileEndpointLossInjected=false;
            auto publishAudioStatus=[&]{
                const bool recovering=audioPipe.endpointRecovering();const auto error=audioPipe.endpointError();const auto count=audioPipe.endpointRecoveries();
                {std::lock_guard lock(mutex_);snapshot_.audioRebuffering=audioPipe.waitingForVideo();snapshot_.audioVideoWaits=audioPipe.videoWaitCount();}
                if(recovering!=publishedAudioRecovery||error!=publishedAudioError||count!=publishedAudioRecoveries){
                    publishedAudioRecovery=recovering;publishedAudioError=error;publishedAudioRecoveries=count;
                    std::lock_guard lock(mutex_);snapshot_.audioInputChannels=audioPipe.pcmFormat().channels;snapshot_.audioOutputChannels=audio.outputFormat().channels;snapshot_.audioEndpointRecovering=recovering;snapshot_.audioEndpointError=error;snapshot_.audioEndpointRecoveries=count;
                }
            };
            PresentationScheduler liveTimeline;uint64_t submitted=0,expired=0;std::deque<int64_t> submissionTimes;
            DeadlineWait deadlineWait;
            // Live capture: the GPU fence of a submitted frame wakes this thread
            // directly. The 0.2 ms ready poll alone left a finished frame waiting
            // up to one timer slice (plus timer jitter) before its Present.
            struct EventHandle{HANDLE handle=CreateEventW(nullptr,FALSE,FALSE,nullptr);~EventHandle(){if(handle)CloseHandle(handle);}} gpuReadyEvent;
            // Realtime file preview scheduling (P2/P3): expired decoded
            // candidates lose their enhancement opportunity against the audio
            // master clock; FG admission predicts pair completion; XeSS-FG
            // generation is suppressed over stable intervals when sustained
            // late. Export/images/paused frames never enter these paths.
            uint64_t previewSkippedTotal=0,previewSkippedSinceSubmit=0,previewSkipRetained=0;int64_t nextPreviewSkipLog=0;
            // Media PTS of the last frame the graph actually processed. The
            // temporal stages care about the gap to that frame, not about how
            // many candidates were dropped on the way (see boundedSkip below).
            double lastProcessedPtsMs=std::numeric_limits<double>::quiet_NaN();
            bool previewSkipSinceProcess=false;
            // Cumulative provider-submission totals already fed to the frame
            // flow. The AMD provider reports presentation from its own thread,
            // so per-call deltas systematically miss updates that land just
            // after a submission; feeding the cumulative difference at the
            // next submission cannot lose them. Reset with the presenter.
            ProviderSubmissionCounter xessSubmissions;
            double playbackSpeedLastPts=0;Clock::time_point playbackSpeedLastWall{};
            CaptureHalfRate captureSampler;
            CapturePreviewClock capturePreviewClock;
            // Content cadence for live sources (ContentDedup.h): in the auto / 30 / 50 /
            // 60 fps content modes, repeated pictures (every component within the
            // capture-noise band, PictureCompare.h) are dropped before any GPU work and
            // kept frames get content timestamps. "60->30" is the plain
            // every-second-sample CaptureHalfRate again (user 2026-10-12); since
            // 2026-10-27 the callback's picture numbers move its phase onto the
            // first copies of a 30 fps game, and a due sample repeating the last kept
            // picture waits for the next new one, so a game that hitches or runs below
            // 30 is not fed repeats and loses no picture (CaptureHalfRate.h).
            // VEYRA_TEST_CONTENT_DEDUP_LEGACY=1 restores the report-only content modes
            // for A/B runs.
            ContentDedup contentDedup;uint64_t dedupRevision=0;
            // PushFPS Frame Pacing Repair (PushPacingRepair.h): even times for the kept frames
            // of a locked game whose frames the console shows unevenly.
            PushPacingRepair pacingRepair;int64_t pacingLastPts=0;bool pacingHaveLast=false;int64_t nextPacingLog=0;
            ContentDedup::Stats dedupLogged{};
            static const bool legacyCadence=GetEnvironmentVariableW(L"VEYRA_TEST_CONTENT_DEDUP_LEGACY",nullptr,0)>0;
            const auto dedupContent=[](ContentRate content){return content!=ContentRate::Transport&&content!=ContentRate::Capture60To30;};
            // CPU frames are compared here; capture-card frames arrive numbered by the callback.
            pipeline::PictureReference enginePictures{2};
            unsigned dedupRepeatMax8=0;uint64_t dedupRepeatMaxOver=0,dedupNewMinOver=UINT64_MAX;
            FrameLineageTracker lineageTracker;
            auto completedProcessing=[&](pipeline::FrameIdentity id){std::lock_guard lock(mutex_);if(snapshot_.applied.revision==id.settingsRevision)++snapshot_.processedCompleted;};
            auto host100ns=[](){return std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now().time_since_epoch()).count()/100;};
            // Live ingress stays latest-frame; file preview keeps the audio clock
            // and may skip expired enhancement opportunities, never PCM.
            // Graph, query collection and presentation remain on this owner.
            graph->recordGpuTimings();presenter.recordGpuTimings();
            struct LiveStats {uint64_t submitted=0,expired=0;double waitMs=0,presentMs=0,readyMs=0,ageMs=0,fps=0,ageP95=0,waitP95=0,presentP95=0,readyP95=0;diagnostics::GpuSample blit;};
            LiveStats liveStats;std::deque<int64_t> liveSubmissions;
            TimingWindow liveAges,liveWaits,liveReady;
            TimingWindow livePresent{std::chrono::seconds(1)};
            TimingWindow livePresentGpu{std::chrono::seconds(1)};
            FgRecoveryBudget fgBudget;uint64_t fgBudgetRevision=options.settings.revision;
            const bool vfgMeasuredReducedQueue=GetEnvironmentVariableW(L"VEYRA_TEST_VFG_FULL_REDUCED_QUEUE_COST",nullptr,0)==0;
            int64_t nextVfgQueueLog=0;
            VfgOverloadEstimate vfgOverload;
            const bool vfgRetainOverload=GetEnvironmentVariableW(L"VEYRA_TEST_VFG_NO_OVERLOAD_ESTIMATE",nullptr,0)==0;
            int64_t nextVfgOverloadLog=0;
            unsigned previewFgMultiplier=options.fgMultiplier;
            // Live output hint (DisplayFgBudget.h): a status-line suggestion only.
            // VEYRA_TEST_DISPLAY_HZ=<hz> replaces the measured refresh for it.
            DisplayFgBudgetGate displayFgGate;
            // PushFPS adaptive frame generation (PushAdaptiveFg.h): per-pair multiplier
            // from the measured content rate, the configured one being the ceiling.
            PushAdaptiveFgGate pushAdaptiveGate;bool pushAdaptiveWas=false;int64_t nextPushAdaptiveLog=0;
            static const double displayFgTestHz=[]{wchar_t v[16]{};return GetEnvironmentVariableW(L"VEYRA_TEST_DISPLAY_HZ",v,16)?std::clamp(_wtof(v),0.0,1000.0):0.0;}();
            // Live graph FG presents on a smoothed anchor (LiveArrivalSmoother).
            // VEYRA_TEST_LEGACY_LIVE_PACING=1 restores the callback anchor, the
            // 2 ms capacity wait and the lone VFG probe for A/B runs.
            static const bool legacyLivePacing=GetEnvironmentVariableW(L"VEYRA_TEST_LEGACY_LIVE_PACING",nullptr,0)>0;
            // A/B: the capacity wait before it followed the measured callback jitter.
            static const bool fixedCapacityWait=GetEnvironmentVariableW(L"VEYRA_TEST_FIXED_CAPACITY_WAIT",nullptr,0)>0;
            LiveArrivalSmoother liveArrival;int64_t liveGeneratedGrace=kLiveGeneratedGrace100ns,nextLiveAnchorLog=0;
            FgCostSettling vfgCostSettling;
            double vfgChosenFgMs=0,vfgFastFgMs=0;uint64_t vfgFastPairs=0,vfgFastBudgetPairs=0,vfgChosenPairs=0;int64_t vfgChosenAt=0,nextVfgFastLog=0;
            uint64_t generatedDropDeadline=0,generatedDropCapacity=0,generatedDropCap=0;
            LivePairLatency pairLatency;
            // Capture-card FG pairs: automatic deadline margin (0-1 ms) on top of the phase.
            LiveDeadlineMargin deadlineMargin;
            // Capture-card FG pairs rejected for a second: real frames without the FG phase.
            LiveFgRejectionHold fgRejectionHold;uint64_t fgHeldPairs=0,fgHeldProbes=0;
            // VEYRA_TEST_ADAPTIVE_SCREEN_PHASE=1 and VEYRA_TEST_ARRIVAL_JITTER_MS=<sd> give
            // window capture what a USB card has: this phase and a late callback.
            const bool adaptiveCapturePhase=(physicalCapture||testReplayAsCard||(isScreen&&GetEnvironmentVariableW(L"VEYRA_TEST_ADAPTIVE_SCREEN_PHASE",nullptr,0)>0))&&GetEnvironmentVariableW(L"VEYRA_TEST_LEGACY_CAPTURE_PHASE",nullptr,0)==0;
            static const double testArrivalJitterMs=[]{wchar_t v[16]{};return GetEnvironmentVariableW(L"VEYRA_TEST_ARRIVAL_JITTER_MS",v,16)?std::clamp(_wtof(v),0.0,10.0):0.0;}();
            uint32_t testArrivalSeed=7;int64_t testCardStart=0;double testCardFirstPtsMs=0;
            const unsigned testReplayDropEvery=[]{wchar_t value[16]{};return GetEnvironmentVariableW(L"VEYRA_TEST_REPLAY_DROP_EVERY",value,16)?unsigned(std::clamp(_wtoi(value),0,120)):0u;}();
            bool testReplayDropPending=false;
            int64_t nextFgAdmissionLog=0,nextFgRejectionLog=0;
            uint64_t fgAdmittedPairs=0,fgRejectedPairs=0,fgReducedPairs=0;int64_t nextFgReducedLog=0;
            std::atomic<uint64_t> historyResets=0,presentationDrains=0,presentationCompletedReal=0,presentationSkippedGenerated=0,presentationCancelledJobs=0;
            std::atomic<uint64_t> presentationGeneration{0};
            std::unique_ptr<LiveGpuScheduler> liveScheduler;
            struct CompletionWatch {
                uint64_t reflexFrame=0;
                int64_t captureArrival=0;
                int64_t phaseAnchor=0;
                uint64_t presentationGeneration=0;
                pipeline::EnhanceGraph::FrameOutputs output;
                std::shared_ptr<FrameFlowWindow> flow;
                Clock::time_point processStart;
                int64_t predictedGpuStart100ns=0;
                std::optional<double> gpuExecutionMs,fgExecutionMs,firstFgExecutionMs;
                bool real=false;
                // B1: presented before the GPU finished; the completion poll
                // records the GPU-ready time (from jobStart) instead of the job.
                bool presentedBeforeReady=false;
                Clock::time_point jobStart{};
                std::atomic<bool> ready=false;
                Clock::time_point readyObserved{};
                std::array<int64_t,pipeline::FrameBatch::Capacity> frameReadyObserved{};
            };
            int64_t nextFgDeadlineLog=0;
            std::vector<std::shared_ptr<CompletionWatch>> pendingCompletions;
            std::shared_ptr<FrameFlowWindow> frameFlow;
            const uint64_t runSessionId=[&]{std::lock_guard lock(mutex_);return snapshot_.sessionId;}();
            pipeline::ResetReason pendingResetCause=pipeline::ResetReason::Open;
            auto traceFrame=[&](diagnostics::TraceKind kind,pipeline::FrameIdentity identity,uint64_t batch,
                uint64_t fence,int64_t pts,uint32_t detail,uint32_t count,double ms){
                Logger::instance().recordFrame({host100ns(),runSessionId,identity,batch,fence,pts,kind,detail,count,ms});
            };
            std::optional<diagnostics::FrameFlowMetrics::ResetRecord> resetRecord;
            std::optional<diagnostics::FrameFlowMetrics::ResetRecord> lastResetRecord;
            bool rollbackWarmupPending=false;
            Clock::time_point resetStart{},resetStageStart{};
            auto markResetStage=[&](diagnostics::ResetStage stage){
                if(!resetRecord)return;
                const auto now=Clock::now();
                resetRecord->stageMs[size_t(stage)]=std::chrono::duration<double,std::milli>(now-resetStageStart).count();
                resetStageStart=now;
                if(frameFlow)frameFlow->resetLifecycle(*resetRecord);
            };
            auto finishReset=[&](diagnostics::ResetOutcome outcome){
                if(!resetRecord)return;
                resetRecord->outcome=outcome;resetRecord->totalMs=elapsedMs(resetStart);
                lastResetRecord=resetRecord;
                if(outcome==diagnostics::ResetOutcome::RolledBack)rollbackWarmupPending=true;
                if(frameFlow)frameFlow->resetLifecycle(*resetRecord);
                const auto& r=*resetRecord;const auto ms=[&](diagnostics::ResetStage s){return r.stageMs[size_t(s)].value_or(-1.0);};
                traceFrame(diagnostics::TraceKind::Reset,{r.epoch,r.settingsRevision,r.sourceFrameId},0,0,0,r.reason,unsigned(outcome),*r.totalMs);
                veyra::log::info("reset-lifecycle",std::format("session={} revision={} epoch={} source={} reason={} outcome={} drainMs={:.3f} destroyMs={:.3f} createMs={:.3f} warmupSubmitMs={:.3f} firstValidObserveMs={:.3f} totalMs={:.3f} (CPU observed; -1=not measured)",r.sessionId,r.settingsRevision,r.epoch,r.sourceFrameId,unsigned(r.reason),unsigned(r.outcome),ms(diagnostics::ResetStage::Drain),ms(diagnostics::ResetStage::Destroy),ms(diagnostics::ResetStage::Create),ms(diagnostics::ResetStage::Warmup),ms(diagnostics::ResetStage::FirstValid),*r.totalMs));
                resetRecord.reset();
            };
            auto completeReset=[&](pipeline::FrameIdentity identity){
                if(!resetRecord||resetRecord->settingsRevision!=identity.settingsRevision||resetRecord->epoch!=identity.epoch||resetRecord->sourceFrameId!=identity.sourceFrameId)return;
                markResetStage(diagnostics::ResetStage::FirstValid);
                finishReset(diagnostics::ResetOutcome::Completed);
            };
            OnExit resetExit{[&]{finishReset(stop_?diagnostics::ResetOutcome::Cancelled:diagnostics::ResetOutcome::Failed);
                // The recording ends with the session; its file is finished in the background.
                recorder_->sessionEnded(stop_?L"播放已停止，录制已保存":L"播放已结束，录制已保存");
                secondRecorder_->sessionEnded({});
                replay_->sessionEnded({});stream_->sessionEnded({});virtualCamera_->sessionEnded();}};
            auto collectTimings=[&]{
                auto record=[&](const diagnostics::GpuFrameTiming& sample){
                    const auto& fgCost=sample.gpu[size_t(diagnostics::GpuStage::FgBatch)];
                    for(auto& watch:pendingCompletions){
                        const auto& id=watch->output.batch.identity;
                        if(id.epoch==sample.identity.epoch&&id.settingsRevision==sample.identity.settingsRevision&&id.sourceFrameId==sample.identity.sourceFrameId){
                            if(const auto span=diagnostics::graphExecutionSpanMs(sample))watch->gpuExecutionMs=span;
                            if(fgCost.state==diagnostics::SampleState::Measured)watch->fgExecutionMs=fgCost.milliseconds;
                            const auto& first=sample.gpu[size_t(diagnostics::GpuStage::Fg1)];
                            if(first.state==diagnostics::SampleState::Measured)watch->firstFgExecutionMs=first.milliseconds;
                        }
                    }
                    const auto& blit=sample.gpu[size_t(diagnostics::GpuStage::Blit)];
                    if(sample.identity.settingsRevision==fgBudgetRevision&&blit.state==diagnostics::SampleState::Measured&&blit.milliseconds)livePresentGpu.add(*blit.milliseconds);
                    if(frameFlow)frameFlow->gpuFrame(sample,host100ns());
                    for(size_t i=0;i<sample.gpu.size();++i){const auto& gpu=sample.gpu[i];
                        if(gpu.state==diagnostics::SampleState::Measured&&gpu.milliseconds){
                            traceFrame(diagnostics::TraceKind::Gpu,sample.identity,0,0,0,unsigned(i),1,*gpu.milliseconds);
                            if(*gpu.milliseconds>=80.0)veyra::log::info("gpu-stage-stall",std::format("source={} epoch={} revision={} stage={} gpuMs={:.3f}",sample.identity.sourceFrameId,sample.identity.epoch,sample.identity.settingsRevision,i,*gpu.milliseconds));
                        }
                    }
                };
                // The graph object is replaced on rebuilds (core reuse, recent-graph
                // cache, prewarm adoption). Re-arm recording on whichever graph is
                // current; arming only the first one left every later graph
                // unmeasured ("未测量" after any effect change, 2026-10-05).
                graph->recordGpuTimings();
                for(const auto& sample:graph->takeGpuTimings())record(sample);
                for(const auto& sample:presenter.takeGpuTimings(ctx.fence()))record(sample);
            };
            const bool traceSubframes=GetEnvironmentVariableW(L"VEYRA_TEST_TRACE_SUBFRAMES",nullptr,0)>0;
            // Shared with the presenter: resolve each batch on this single
            // object so SDK status and generated counts are consumed once.
            auto pollCompletions=[&]{
                diagnostics::CpuStallTrace trace("completion-stall");
                collectTimings();
                for(auto it=pendingCompletions.begin();it!=pendingCompletions.end();){
                    auto& watch=**it;auto& batch=watch.output;
                    for(unsigned i=0;i<batch.batch.count;++i){const auto& item=batch.batch.frames[i];
                        if(!watch.frameReadyObserved[i]&&item.lease&&item.lease->ready()){
                            watch.frameReadyObserved[i]=host100ns();
                            if(traceSubframes)traceFrame(diagnostics::TraceKind::FrameReady,item.identity,batch.batch.batchId,item.lease->readyFence,item.pts100ns,item.subframe,1,elapsedMs(watch.processStart));
                        }
                    }
                    if(!graph->resolveGeneration(batch)){++it;continue;}
                    // The GPU may finish between the first poll and resolve.
                    // Collect its timestamps before removing this watch.
                    if(!watch.gpuExecutionMs)collectTimings();
                    unsigned valid=0,invalid=0,failed=0;
                    for(unsigned i=0;i<batch.batch.count;++i)if(batch.batch.frames[i].kind==pipeline::FrameKind::Generated){
                        if(batch.batch.frames[i].validity==pipeline::GenerationValidity::Valid)++valid;else ++invalid;
                        failed+=batch.batch.frames[i].validity==pipeline::GenerationValidity::Failed;
                    }
                    watch.flow->ready(batch.batch.batchId,watch.real,valid,invalid,host100ns());
                    traceFrame(diagnostics::TraceKind::Ready,batch.batch.identity,batch.batch.batchId,std::max(batch.videoFenceValue,batch.genFenceValue),batch.batch.b100ns,invalid,valid,elapsedMs(watch.processStart));
                    if(watch.real)completedProcessing(batch.batch.identity);
                    // A reduced (2X) group must not lower the full-group FG
                    // cost estimate, but its base cost is a normal sample -
                    // see FgRecoveryBudget::complete. A history reset, an FG
                    // recovery and a live VFG pair settling after a long skip
                    // (FgCostSettling) are warmup samples.
                    const bool currentCost=batch.batch.identity.settingsRevision==fgBudgetRevision&&
                        watch.presentationGeneration==presentationGeneration.load();
                    const auto vfgHeldUntil=vfgCostSettling.holdUntil();
                    // PushFlow keeps its A/B history across skipped pairs like VFG, so its first
                    // evaluation after a skip is the same slow probe (clocks and caches gone cold).
                    const bool costSettling=currentCost&&isCapture&&!legacyLivePacing&&
                        (options.settings.frameGenerationBackend==FrameGenerationBackend::Vfg||options.settings.frameGenerationBackend==FrameGenerationBackend::PushFlow)&&
                        vfgCostSettling.observe((batch.fgCandidates>0&&batch.fgEvaluated==0&&!(batch.historyReset&&options.settings.frameGenerationBackend==FrameGenerationBackend::PushFlow))||batch.fgFastForBudget,batch.fgEvaluated>0&&!batch.fgFast,host100ns());
                    // Each model's own time. The steady time is the low envelope: an
                    // evaluation after skips can cost 1.7x (see FgCostSettling).
                    if(currentCost&&watch.fgExecutionMs&&batch.fgEvaluated>0&&!batch.fgReduced&&!batch.historyReset&&!batch.fgRecovery){
                        auto& cost=batch.fgFast?vfgFastFgMs:vfgChosenFgMs;const double ms=*watch.fgExecutionMs;
                        cost=cost>0&&ms>=cost?cost+.1*(ms-cost):ms;
                        if(!batch.fgFast){vfgChosenAt=host100ns();++vfgChosenPairs;}
                    }
                    if(vfgCostSettling.holdUntil()!=vfgHeldUntil)veyra::log::info("vfg-probe",std::format("revision={} retryInMs={} (a VFG/PushFlow probe after a long skip stayed over budget; failed probes retry after 2, 4, then every 8 s)",options.settings.revision,(vfgCostSettling.holdUntil()-host100ns())/10000));
                    if(currentCost)fgBudget.complete(watch.gpuExecutionMs,batch.fgEvaluated>0,batch.historyReset||batch.fgRecovery||costSettling,host100ns(),watch.fgExecutionMs,!batch.fgReduced&&!batch.fgFast);
                    if(options.settings.frameGenerationBackend==FrameGenerationBackend::Vfg&&currentCost){
                        if(batch.historyReset)vfgOverload.reset();
                        if(!batch.historyReset&&!batch.fgRecovery&&!batch.fgReduced&&batch.fgEvaluated+1==options.fgMultiplier)
                            vfgOverload.observe(watch.fgExecutionMs,watch.firstFgExecutionMs,host100ns());
                    }
                    // A group whose frames were all evaluated but then marked a content
                    // duplicate or provider-disabled did the same GPU work, so its
                    // readiness is a valid phase sample. Learning only from displayed
                    // groups let samples expire during static/duplicate content (60->30:
                    // B held 33 ms) and re-converge for ~1 s once motion resumed.
                    // VEYRA_TEST_PAIR_PHASE_VALID_ONLY=1 restores the old rule for A/B.
                    static const bool phaseValidOnly=GetEnvironmentVariableW(L"VEYRA_TEST_PAIR_PHASE_VALID_ONLY",nullptr,0)>0;
                    // resolveGeneration clears hasGenerated when no frame stayed valid,
                    // so the evaluated group is recognised by its generated frames.
                    const bool phaseSample=phaseValidOnly?valid==batch.fgCandidates&&batch.hasGenerated:
                        batch.fgCandidates>0&&valid+invalid==batch.fgCandidates&&!failed;
                    if(adaptiveCapturePhase&&watch.phaseAnchor>0&&phaseSample&&!batch.fgPredict&&
                       !batch.historyReset&&!batch.fgRecovery&&!costSettling&&!batch.fgFast&&
                       batch.batch.identity.settingsRevision==fgBudgetRevision&&watch.presentationGeneration==presentationGeneration.load()){
                        int64_t requiredDelay=0;
                        const auto observed=host100ns();
                        for(unsigned i=0;i<batch.batch.count;++i){const auto& item=batch.batch.frames[i];
                            // resolveGeneration can observe a fence after the
                            // first poll. Its current host time is a safe upper bound.
                            const auto ready=watch.frameReadyObserved[i]?watch.frameReadyObserved[i]:observed;
                            requiredDelay=std::max(requiredDelay,ready-watch.phaseAnchor+batch.batch.b100ns-item.pts100ns);
                        }
                        pairLatency.observe(observed,requiredDelay);
                    }
                    completeReset(batch.batch.identity);
                    watch.readyObserved=Clock::now();
                    if(watch.presentedBeforeReady&&watch.flow==frameFlow&&liveScheduler){
                        const double readyMs=std::max(0.0,std::chrono::duration<double,std::milli>(watch.readyObserved-watch.jobStart).count());
                        watch.flow->cpu(diagnostics::CpuStage::ReadyWait,readyMs,host100ns());
                        liveReady.add(readyMs);liveStats.readyMs=readyMs;liveStats.readyP95=liveReady.p95();
                    }
                    watch.ready=true;it=pendingCompletions.erase(it);
                }
                collectTimings();
            };
            if(!isImage){liveScheduler=std::make_unique<LiveGpuScheduler>();veyra::log::info("scheduler",std::format("single GPU owner thread={} capacity=2 source={} (bounded enhanced lookahead)",GetCurrentThreadId(),isCapture?"live":"file"));}
            PresentationCadence cadence;
            PresentationSettings presentationEffective;
            // presentationPaced: VSync keeps a one-deep display queue (latency
            // object). A failed wait turns pacing off for this configuration.
            // VEYRA_TEST_LEGACY_VSYNC_QUEUE=1 restores the unwaited VSync queue
            // (no read gate, waits only with the toggle/cap) for A/B runs.
            bool presentationPaced=false;
            static const bool legacyVsyncQueue=GetEnvironmentVariableW(L"VEYRA_TEST_LEGACY_VSYNC_QUEUE",nullptr,0)>0;
            // XeSS live presentation (latency-min B1): the presenter records on the
            // graph's own queue, so a real frame can be tagged and presented right
            // after its graph submission; GPU order keeps it after the enhancement.
            // One loop is then one XeLL cycle: sleep -> read -> submit -> present.
            // Waiting for the CPU fence first let the next source enter the same
            // cycle, so the following present opened the next cycle and slept
            // inside Present. VEYRA_TEST_XESS_PRESENT_AFTER_READY=1 restores the
            // fence wait; VEYRA_TEST_XESS_STACKED_READS=1 lets XeSS read the next
            // source while the previous one is still on the GPU, as before.
            static const bool xessPresentAfterReady=GetEnvironmentVariableW(L"VEYRA_TEST_XESS_PRESENT_AFTER_READY",nullptr,0)>0;
            static const bool xessStackedReads=GetEnvironmentVariableW(L"VEYRA_TEST_XESS_STACKED_READS",nullptr,0)>0;
            uint64_t pacingRevision=0,presenterGeneration=0;double pacingRefreshHz=0;
            auto applyPresentation=[&]{
                PresentationSettings requested;uint64_t revision;
                {std::lock_guard lock(mutex_);requested=presentation_;revision=presentationRevision_;}
                // Poll completed display/VRR queries before comparing policy.
                // It must not make synchronous driver calls on the GPU owner.
                const double refreshHz=presenter.displayRefreshHz();
                // PushFPS 4.1: a fixed cap is fitted to the screen too (PushDisplayCap.h), so another
                // screen's refresh rate applies it again, as it always did for the cap that follows the display.
                const bool capRefreshChanged=(requested.outputRate==OutputRateMode::FollowDisplay||requested.outputRate==OutputRateMode::Custom)&&std::abs(refreshHz-pacingRefreshHz)>0.001;
                // 可变刷新: the monitor's VRR availability is read again on events
                // (another monitor, a display change, 重新检测, the VRR
                // confirmation); a change re-applies.
                const bool vrrChanged=presenter.vrrSync()!=VideoPresenter::vrrSyncWanted(requested,presenter.displayVrr());
                if(revision==pacingRevision&&presenterGeneration==presenter.generation()&&!vrrChanged&&!capRefreshChanged){
                    // Reflex dropped out at runtime: the queue-depth part of the
                    // low-latency setting stays, so only the status line changes.
                    if(presentationEffective.nvidiaLowLatency!=NvidiaLowLatency::Off&&!presenter.reflexActive()&&presenter.reflexFailed()){
                        presentationEffective.nvidiaLowLatency=NvidiaLowLatency::Off;
                        std::lock_guard lock(mutex_);snapshot_.presentationEffective=presentationEffective;snapshot_.presentationStatus=presenter.reflexDisablePending()?L"英伟达低延迟调用及撤销失败；请关闭视频后重试":
                            presenter.reflexStalled()?L"英伟达低延迟：驱动每帧等待过长，本次播放已关闭；当前使用低排队":L"英伟达低延迟调用失败，当前使用低排队；详见日志";
                    }
                    if(presentationPaced&&!presenter.pacingActive()){
                        // The sink already stopped waiting; reconfiguring would arm it again.
                        presentationPaced=false;cadence.reset();
                        std::lock_guard lock(mutex_);snapshot_.presentationStatus=L"显示队列等待失败，垂直同步屏幕队列不再限制；详见日志";
                    }
                    return;
                }
                if(isImage){requested.enabled=false;requested.nvidiaLowLatency=NvidiaLowLatency::Off;}
                std::wstring message;
                presentationEffective=presenter.configurePresentation(ctx,requested,options.fg,message);
                presentationPaced=presenter.pacingActive()&&!legacyVsyncQueue;
                pacingRevision=revision;presenterGeneration=presenter.generation();pacingRefreshHz=refreshHz;cadence.reset();
                {std::lock_guard lock(mutex_);snapshot_.presentationEffective=presentationEffective;snapshot_.presentationRevision=revision;snapshot_.presentationStatus=message;snapshot_.presentationProviderOwned=presenter.providerOwnedPresentation();}
                veyra::log::info("pacing",std::format("revision={} requested={}/{}/{} effective={}/{}/{} displayQueuePaced={} variableRefresh={} vrrLevel={} vrrSync={}",revision,requested.enabled,unsigned(requested.mode),unsigned(requested.display),presentationEffective.enabled,unsigned(presentationEffective.mode),unsigned(presentationEffective.display),presentationPaced,requested.variableRefresh,gfx::vrrLevel(presenter.displayVrr()),presenter.vrrSync()));
            };
            auto drainLivePresentation=[&]{cadence.reset();if(liveScheduler){++presentationDrains;liveScheduler->cancel();pollCompletions();pendingCompletions.clear();}pairLatency.reset();deadlineMargin.reset();fgRejectionHold.reset();};
            const bool preciseDeadlines=GetEnvironmentVariableW(L"VEYRA_TEST_LEGACY_DEADLINE_WAIT",nullptr,0)==0;
            // A ready frame whose deadline has come goes out before the completion
            // poll: the poll collects GPU timings and FG budget samples, and a frame
            // due meanwhile waited for it (the P99 present interval is the 1% low).
            // The step checks its own fence; it does not need the poll.
            auto advanceLive=[&]{applyPresentation();if(liveScheduler){
                const auto halted=[&]{return stop_||(paused_&&!seekPreviewPending)||seekSeconds_>=0;};
                if(!halted()&&preciseDeadlines&&liveScheduler->preciseWake()){const auto now=host100ns(),due=liveScheduler->wakeAt();if(due>0&&due<=now)liveScheduler->advance(now);}
                pollCompletions();if(halted()){liveScheduler->cancel();cadence.reset();}else liveScheduler->advance(host100ns());}};
            FrameFlowWindow* waitingFlow=nullptr;uint64_t waitingPresented=0;size_t waitingPending=0;
            auto publishWaitingProgress=[&](bool force=false){
                if(!frameFlow)return;
                const auto presented=presentationCompletedReal.load();const auto pending=pendingCompletions.size();
                if(!force&&waitingFlow==frameFlow.get()&&waitingPresented==presented&&waitingPending==pending)return;
                waitingFlow=frameFlow.get();waitingPresented=presented;waitingPending=pending;
                // A source can stop delivering after submitting its last batch.
                // Publish actual completion/presentation progress without waiting
                // for another input. No GPU work, timer change or frame replay.
                const auto flow=frameFlow->snapshot(host100ns());
                std::lock_guard lock(mutex_);snapshot_.metrics.flow=flow;
            };
            const bool checkpointPresentation=GetEnvironmentVariableW(L"VEYRA_TEST_NO_PROCESS_PRESENT",nullptr,0)==0;
            const bool capturePresentAfterReady=GetEnvironmentVariableW(L"VEYRA_TEST_CAPTURE_PRESENT_AFTER_READY",nullptr,0)>0;
            bool processingGraph=false;
            auto waitLive=[&]{
                const auto due=liveScheduler?liveScheduler->wakeAt():0;
                const auto arrivalEvent=physicalCapture?captureSource.frameEvent():nullptr;
                const auto readyEvent=physicalCapture?gpuReadyEvent.handle:nullptr;
                if(preciseDeadlines&&liveScheduler&&liveScheduler->preciseWake()){
                    deadlineWait.until(due,arrivalEvent,readyEvent,[&]{return stop_||(paused_&&!seekPreviewPending)||seekSeconds_>=0;});
                }else deadlineWait.slice(due>host100ns()?std::min(1.0,double(due-host100ns())/10000):1.0,arrivalEvent,readyEvent);
            };
            // No full advanceLive here: it collects the graph's timing queries
            // and can apply presentation settings. Only older leased outputs
            // may run, on the presenter's independent ring; never XeSS/file.
            // Never wait here for a frame that is not due yet. Holds of up to 0.3 ms
            // (2026-11-13) sent real frames on time but started this batch's GPU work as
            // much later: learned, the pair phase and capture-to-present grew 0.3-0.4 ms;
            // left out of the learning, the generated frames lost their margin and the
            // result swung between runs (DLSS 2X 1% low 113-118). The single owner thread
            // cannot do both; a frame due here goes out at the next checkpoint.
            auto presentDuringProcess=[&]{
                if(!checkpointPresentation||!isCapture||!options.fg||graph->hdrOutput()||!presenter.independentQueue()||
                   !liveScheduler||stop_||(paused_&&!seekPreviewPending)||seekSeconds_>=0)return;
                const auto due=liveScheduler->wakeAt(),now=host100ns();
                if(due>0&&due<=now)liveScheduler->advance(now);
            };
            uint64_t metricsRevision=options.settings.revision,metricsEpoch=0,metricsWindowEpoch=0,statsSourceBase=0;
            uint64_t slotWaitBase=ring.cpuWaitCount(),submitBase=ring.submitCount();double slotWaitMsBase=ring.cpuWaitMilliseconds();
            std::shared_ptr<FrameCompletionRates> completionRates;
            source::CaptureMetrics captureFlowBase{},captureFlowLast{};
            uint64_t rateSkippedBase=0;
            // Queued steps capture these locals; cancel before their destruction.
            const bool injectSourceGap=options.captureReplayForTest&&GetEnvironmentVariableW(L"VEYRA_TEST_REPLAY_SOURCE_GAP",nullptr,0)>0;
            std::optional<Clock::time_point> sourceGapUntil;
            // Master media clock for file playback: the audio device clock when
            // mapped, a monotonic anchor without audio, and its frozen value
            // while an endpoint recovers. Steady-state video scheduling reads
            // this clock; it never waits on audio coverage.
            // 网络源是否正被缓冲按住。nowMs() 要用它区分「音频真的放完了」和
            // 「只是网络暂时没数据」：后者不能把媒体时钟交给墙钟。
            std::atomic<bool> networkHolding{false};
            // 缓冲相位每秒会在 buffering / playing 之间抖好几次，直接拿它去暂停音频会
            // 让声音断断续续。只有连续处于缓冲状态半秒以上才真的停声音；恢复则立即生效。
            // The buffering phase flaps between buffering and playing several times a
            // second; pausing the audio straight from it makes the sound stutter. Only a
            // stretch of half a second really stops it, while resuming applies at once.
            Clock::time_point audioHoldSince{};
            bool audioHoldPushed=false;
            auto nowMs=[&](){
                if(!audioStarted)return anchorMs+std::chrono::duration<double,std::milli>(Clock::now()-anchor).count()*playbackRate;
                publishAudioStatus();const double a=audio.mediaTimeMs();
                // 音频正在等网络重试：让媒体时钟停住，画面跟着停下等声音。不这么做
                // 画面会一直往前跑，声音补上来时就落后几秒，对不上口型 —— 现场
                // 2026-10-25：leadMs 到过 -1081 和 -7495。
                // The audio is between read attempts: freeze the media clock so the picture
                // waits for the sound. Otherwise the picture runs ahead and the sound comes
                // back seconds behind (field log 2026-10-25: leadMs -1081, -7495).
                if(audioPipe.retryingRead()){audioClockExhausted=false;return lastAudioClockMs;}
                if(std::isfinite(a)){lastAudioClockMs=a;audioClockExhausted=false;return a;}
                // A disconnected endpoint freezes the shared media clock. Only a
                // fully exhausted audio stream may hand its tail to the wall clock.
                if(audioPipe.clockExhausted()){
                    // 但网络正在缓冲时必须继续冻结：网络源的数据是「暂时没有」，不是
                    // 「放完了」。这时若用墙钟推进，媒体时钟会跑到没有画面的地方去，
                    // 缓冲恢复后视频要等很久才追上来 —— 观感就是「画面卡住不恢复」
                    // （现场 2026-10-24：clockMs 8 秒内前进 10 秒，coverage 停在原处）。
                    if(networkHolding.load()){
                        audioClockExhausted=false;
                        return lastAudioClockMs;
                    }
                    if(!audioClockExhausted){audioClockExhausted=true;audioTailAnchor=Clock::now();}
                    return lastAudioClockMs+std::chrono::duration<double,std::milli>(Clock::now()-audioTailAnchor).count()*playbackRate;
                }
                return lastAudioClockMs;
            };
            // Network sources and files on a server: statistics for the signal panel, and the buffering /
            // reconnect explanation on the status line while playback is held. The previous status comes
            // back when the hold ends, unless something else replaced the text in the meantime.
            std::wstring networkSavedStatus,networkShownStatus;
            bool networkClockFrozen=false;double networkFrozenMs=0;
            auto nextNetworkPublish=Clock::now();
            auto publishNetwork=[&]{
                const auto stats=source.networkStats();
                std::lock_guard lock(mutex_);
                snapshot_.network=stats;
                const bool explain=!stats.message.empty()&&(stats.holding()||stats.state==media::NetworkStats::State::Reconnecting);
                if(explain){
                    if(networkShownStatus.empty())networkSavedStatus=snapshot_.status;
                    snapshot_.status=networkShownStatus=stats.message;
                }else if(!networkShownStatus.empty()){
                    if(snapshot_.status==networkShownStatus)snapshot_.status=networkSavedStatus;
                    networkShownStatus.clear();
                }
            };
            // Runs every loop turn and inside the presentation back-pressure wait: while playback is held
            // for buffering the frozen clock keeps queued pictures from presenting, and that wait must
            // neither look like a hang to the watchdog nor stop the statistics.
            // P0 缓冲闸门：视频侧的水位由 demux 的 phase 给出，音频侧没有对应信号 ——
            // B 站那种音轨单独打开（session_ 为空）的来源掉数据时，demux 一无所知，
            // 于是画面照跑、声音断了。这里用音频自己的两个水位把它补上：PCM 缓冲见底，
            // 或者预读队列见底。阈值带滞回（300→1000、500→1500），否则会在阈值附近
            // 一秒钟抖好几次，声音断断续续。
            // P0 buffering gate: the video side reports through the demux phase, the audio
            // side has no such signal - for a separately opened track (Bilibili) the demux
            // knows nothing when the sound runs dry, so the picture kept going in silence.
            // Two audio water levels fill that gap, with hysteresis so it cannot flap.
            // P2：阈值从环境变量读，现场按网络情况调，不必重新编译。
            // P2: thresholds come from the environment so a field can be tuned without
            // rebuilding; anything unset or <= 0 falls back to the built-in value.
            auto gateEnvMs=[](const char* name,double fallback){
                const char* value=std::getenv(name);
                if(!value||!*value)return fallback;
                const double parsed=std::atof(value);
                return parsed>0.0?parsed:fallback;
            };
            engine::BufferingGateLimits gateLimits;
            gateLimits.enterPcmMs=gateEnvMs("VEYRA_GATE_ENTER_PCM_MS",gateLimits.enterPcmMs);
            gateLimits.enterQueuedMs=gateEnvMs("VEYRA_GATE_ENTER_QUEUED_MS",gateLimits.enterQueuedMs);
            gateLimits.exitPcmMs=gateEnvMs("VEYRA_GATE_EXIT_PCM_MS",gateLimits.exitPcmMs);
            gateLimits.exitQueuedMs=gateEnvMs("VEYRA_GATE_EXIT_QUEUED_MS",gateLimits.exitQueuedMs);
            gateLimits.warmupMs=static_cast<long long>(gateEnvMs("VEYRA_GATE_WARMUP_MS",static_cast<double>(gateLimits.warmupMs)));
            // 判定在 BufferingGate 里，有单元测试兜着（tests/unit/BufferingGateTests.cpp）：
            // 阈值滞回、5 秒窗口、重连预算、放弃。
            // The decision lives in BufferingGate, covered by unit tests: the hysteresis,
            // the 5 s window, the reconnect budget and giving up.
            engine::BufferingGate bufferingGate(gateLimits);
            auto gateNow=[]{
                return std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now().time_since_epoch()).count();
            };
            bool audioGateNotified=false,audioGateWasHolding=false;
            Clock::time_point nextGateLog{};
            auto networkTick=[&]{
                if(!demuxSession)return;
                const bool videoHolding=demuxSession->holding();
                long long gateNowMs=0;
                // A shared demux session already gates both tracks. Its audio has
                // no independent read-ahead queue, so queuedMs() is always zero.
                if(audioStarted&&separateAudio){
                    const double pcmMs=audioPipe.bufferedMs();
                    const double queuedMs=audioPipe.queuedMs();
                    // 流已经读到结尾时水位自然会掉到 0 —— 那不是断流。当成断流会做一次毫无
                    // 意义的重连（地址已经播完），重连失败又把会话标成 failed，B 站层据此
                    // 「换镜像重开」，表现就是播完之后重新缓冲、又把最后几秒重播一遍。
                    // A finished stream drains its queue: that is not dryness. Treating it as
                    // such fired a pointless reconnect, marked the session failed, and made the
                    // Bilibili layer reopen on another mirror - replaying the last few seconds.
                    const bool streamEnded = audioPipe.decodingComplete() || audioPipe.clockExhausted() ||
                                             (demuxSession && demuxSession->eof());
                    gateNowMs=gateNow();
                    const auto gateAction=bufferingGate.update(!streamEnded,pcmMs,queuedMs,gateNowMs);
                    const bool gateHolding=bufferingGate.holding();
                    if(gateHolding&&!audioGateWasHolding)
                        veyra::log::warn("buffering-gate",std::format(
                            "audio running dry: pcmMs={:.0f} queuedMs={:.0f}; holding the picture with the sound",
                            pcmMs,queuedMs));
                    else if(!gateHolding&&audioGateWasHolding)
                        veyra::log::info("buffering-gate",std::format(
                            "audio recovered: pcmMs={:.0f} queuedMs={:.0f}",pcmMs,queuedMs));
                    audioGateWasHolding=gateHolding;
                    // P1：5 秒还没回来就不是「慢」，是连接死了。用原地址重开一次（B 站音频
                    // 地址在播放期内仍有效），从当前媒体时刻接上。刻意让**音频**当基准：
                    // 画面为此微跳一帧，好过让口型一直漂。
                    // P1: five seconds means the connection is dead, not slow. Reopen the same
                    // audio address and continue from the current media time. The sound stays
                    // the reference on purpose - the picture takes one small step instead of
                    // drifting out of sync.
                    if(gateAction==engine::BufferingGate::Action::Reconnect){
                        const double resumeMs=lastAudioClockMs;
                        veyra::log::warn("buffering-gate",std::format(
                            "reopening the audio address (attempt {}) at {:.0f} ms",bufferingGate.reconnects(),resumeMs));
                        audioPipe.stopThread();
                        bool reopened=false;
                        try{
                            reopened=audioPipe.open(audioTarget,&stop_,options.network.requestHeaders,options.network.userAgent);
                        }catch(const std::exception& e){
                            veyra::log::error("buffering-gate",std::format("audio reopen threw: {}",e.what()));
                        }
                        if(reopened){
                            audioPipe.holdForVideo();audioPipe.startThread(&audio,true);
                            {
                                std::lock_guard lock(mutex_);
                                snapshot_.audioTracks=audioPipe.tracks();
                                snapshot_.selectedAudioTrack=audioPipe.selectedTrack();
                                snapshot_.audioAvailable=true;
                            }
                            if(std::isfinite(resumeMs)&&resumeMs>0.0)(void)audioPipe.requestSeek(resumeMs);
                            audioGateWasHolding=false;
                            watchdog_->beat();
                            veyra::log::info("buffering-gate",std::format(
                                "audio reopened; continuing at {:.0f} ms (the picture follows the sound)",resumeMs));
                        }else{
                            veyra::log::error("buffering-gate","audio address could not be reopened");
                            // 重连也失败：这次会话没有可用的声音了。把音频从时钟与闸门里摘掉，
                            // 否则水位恒为 0，闸门会永远保持，用户点播放只看到冻结的画面。
                            // Reopening failed too: this session has no usable sound left. Take the
                            // audio out of the clock and the gate, or a zero water level holds the
                            // picture for ever and pressing play changes nothing.
                            audioStarted=false;
                            bufferingGate.abandon();
                            {
                                std::lock_guard lock(mutex_);
                                snapshot_.audioAvailable=false;   // 界面上也不要再声称有声音
                            }
                        }
                    }
                }
                const bool holding=videoHolding||bufferingGate.holding();
                networkHolding.store(holding);
                // P2：每秒把两路水位和判定结果写一行，掉一次缓冲也能从日志还原现场。
                // P2: one line a second with both water levels and the verdict, so a single
                // buffering episode can be reconstructed from the log alone.
                if(Clock::now()>=nextGateLog){
                    // 五秒一条：既能在掉一次缓冲时还原现场，又不会把日志撑爆
                    // （每秒一条意味着看两小时片子多出七千行）。
                    // One line every five seconds: enough to reconstruct an episode,
                    // few enough not to flood a two-hour session.
                    nextGateLog=Clock::now()+std::chrono::seconds(5);
                    veyra::log::info("buffering-gate",std::format(
                        "pcmMs={:.0f} queuedMs={:.0f} videoHolding={} audioHolding={} holding={} reconnects={}",
                        audioStarted?audioPipe.bufferedMs():-1.0,
                        audioStarted?audioPipe.queuedMs():-1.0,
                        videoHolding,bufferingGate.holding(),holding,bufferingGate.reconnects()));
                }
                // B 站那种「音轨单独打开」的来源，音频管道看不到视频会话的阶段，
                // 必须由这里把缓冲状态推过去：否则画面因缓冲停住、声音继续播。
                // For a source whose audio is opened separately (Bilibili) the pipeline
                // cannot see the video session's phase, so the buffering state is pushed
                // here - otherwise the picture stalls while the sound keeps going.
                // 半秒防抖后再停声音（见上面 audioHoldSince 的说明）。
                // Half a second of debounce before the sound is actually stopped.
                if(holding){
                    if(audioHoldSince==Clock::time_point{})audioHoldSince=Clock::now();
                    if(!audioHoldPushed&&Clock::now()-audioHoldSince>std::chrono::milliseconds(500)){
                        audioPipe.setNetworkHold(true);
                        audioHoldPushed=true;
                    }
                }else{
                    audioHoldSince=Clock::time_point{};
                    if(audioHoldPushed){audioPipe.setNetworkHold(false);audioHoldPushed=false;}
                }
                if(holding)watchdog_->beat();
                // Without an audio device the media clock is the wall clock: stand it still while the
                // session pauses playback for buffering (with audio, pausing the endpoint does that).
                if(!audioStarted){
                    if(holding){
                        if(!networkClockFrozen){networkClockFrozen=true;networkFrozenMs=nowMs();}
                        anchor=Clock::now();anchorMs=networkFrozenMs;
                    }else networkClockFrozen=false;
                }
                // Where playback is decides how far ahead the session reads and when it pauses for buffering.
                source.setPlaybackPositionMs(nowMs());
                if(Clock::now()>=nextNetworkPublish){nextNetworkPublish=Clock::now()+std::chrono::milliseconds(100);publishNetwork();}
            };
            uint64_t hdrDisplayCheck=0;
            bool captureRecovering=false;unsigned captureRetries=0;
            Clock::time_point captureRetryAt{};
            bool xessPresentationRecovery=false;
            auto recoverXessPresentation=[&]{
                if(!presenter.xessFailed()||FAILED(ctx.device()->GetDeviceRemovedReason()))return false;
                auto reduced=options.snapshot();
                if(!disableFailedBackend(reduced,FailedBackend::Fg))return false;
                holdFileAudio();fileAudioAlignPending=true;
                drainLivePresentation();
                if(!ring.drainQueue()||!ring.discardRecording())return false;
                out={};hasOutput=false;
                // A failed scheduler stays failed after cancel. Recreate it on
                // its owner, then rebuild the SDK swapchain via settings below.
                if(liveScheduler)liveScheduler=std::make_unique<LiveGpuScheduler>();
                {
                    std::lock_guard lock(mutex_);
                    desired_.rejectVideoRequest(options.snapshot(),reduced);
                    desired_.revision=++nextRevision_;snapshot_.desired=desired_;snapshot_.applying=true;
                    snapshot_.backendWarning=L"XeSS 呈现失败，正在恢复基础播放；错误码见日志";
                }
                veyra::log::warn("backend-recovery",std::format("{} presentation failed; drained commands, requesting swapchain rebuild without FG","XeSS"));
                xessPresentationRecovery=true;
                reset=true;pendingResetCause=pipeline::ResetReason::Settings;
                return true;
            };
            // Disarmed after stopPresentation's teardown, so a teardown that blocks is
            // reported too.
            OnExit leaveWatchdog{[&]{watchdog_->disarm();}};
            // Test hook: block the owner once, after 120 loop frames, for the given ms
            // (-1 = forever), to exercise the hang watchdog and bounded shutdown.
            wchar_t testHangText[16]{};
            int testHangMs=GetEnvironmentVariableW(L"VEYRA_TEST_ENGINE_HANG_MS",testHangText,16)?_wtoi(testHangText):0;
            // Test hook: VEYRA_TEST_GPU_FAILURE=<frames>:<removeAfterMs> fails live presentation
            // once, as a GPU frame-ready timeout does, and removes this device that many ms
            // later as the driver reset does (-1 = never), for the recovery paths.
            wchar_t testGpuFailureText[32]{};int testGpuFailureFrames=0,testGpuRemoveMs=-1;bool testGpuFailure=false;
            if(GetEnvironmentVariableW(L"VEYRA_TEST_GPU_FAILURE",testGpuFailureText,32)){
                testGpuFailureFrames=_wtoi(testGpuFailureText);
                if(const wchar_t* colon=wcschr(testGpuFailureText,L':'))testGpuRemoveMs=_wtoi(colon+1);
            }
            // Declared LAST before the loop on purpose: it is destroyed first at
            // scope exit, so the scheduler (whose queued step/finish lambdas
            // capture the locals above by reference) is torn down before any of
            // those locals (sweep 2026-09-22 B1). Do not move declarations that
            // the lambdas reference below this line.
            AutoNrController autoNrControl;autoNrControl.reset(host100ns());
            uint64_t autoNrRevision=options.settings.revision;int64_t autoNrLogAt=0;
            AutoNrReuseController nrReuseControl;nrReuseControl.reset(host100ns());
            uint64_t nrReuseRevision=options.settings.revision;int64_t nrReuseLogAt=0;
            // A simultaneous seek/speed change may discard the cached frame
            // after a successful rebuild. Keep its status acknowledgement
            // until the first successfully processed frame, across loop turns.
            bool pendingSettingsAck=false;
            OnExit stopPresentation{[&]{liveScheduler.reset();finishReset(stop_?diagnostics::ResetOutcome::Cancelled:diagnostics::ResetOutcome::Failed);std::lock_guard lock(mutex_);if(snapshot_.sessionId==runSessionId){if(frameFlow)snapshot_.metrics.flow=frameFlow->snapshot(host100ns());activeFlow_.reset();}}};
            while(!stop_){
                watchdog_->beat();
                if(testHangMs&&frames>=120){veyra::log::warn("engine-test",std::format("blocking owner thread for {} ms",testHangMs));Sleep(testHangMs<0?INFINITE:DWORD(testHangMs));testHangMs=0;}
                if(Clock::now()-cacheBudgetPolledAt>=std::chrono::milliseconds(500)){
                    (void)recentGraphCache.checkBudget();cacheBudgetPolledAt=Clock::now();
                }
                diagnostics::CpuStallTrace loopTrace("engine-stall",frames,45.0,watchdog_->stage());
                collectTimings();
                loopTrace.mark("collect");
                networkTick();
                // P0 缓冲闸门：音频 5 秒没回来就不再一起等 —— 暂停并明确告诉用户重开，
                // 而不是让画面和声音一起冻住、什么提示都没有。
                // P0: once the sound has been gone for five seconds, stop waiting together:
                // pause and say so, instead of freezing picture and sound in silence.
                if(bufferingGate.gaveUp()){
                    if(!audioGateNotified){
                        audioGateNotified=true;
                        status(L"音频已中断超过 5 秒，已暂停播放，请重新打开该视频", true);
                        pause(true);
                    }
                }else if(audioGateNotified)audioGateNotified=false;
                if(captureRecovering){
                    if(Clock::now()<captureRetryAt){std::this_thread::sleep_for(std::chrono::milliseconds(20));continue;}
                    ++captureRetries;
                    {std::lock_guard lock(mutex_);snapshot_.captureReconnectAttempts=captureRetries;}
                    status(std::format(L"采集信号中断，正在重连原设备（第 {} 次）",captureRetries));
                    captureSource.setAudioIngress(unsigned(options.settings.captureAudio));
                    captureSource.setVerticalFlip(options.settings.captureFlipVertical);
                    captureSource.setBufferMode(unsigned(options.settings.captureBuffer));
                    if(captureSource.reconnect(muted_||!captureAudioMonitoring_?0.0f:volume_.load(),unsigned(options.settings.audioSync),options.settings.audioOffsetMs)){
                        captureRecovering=false;reset=true;pendingResetCause=pipeline::ResetReason::DeviceLost;captureSampler.reset();
                        {std::lock_guard lock(mutex_);snapshot_.captureRecovering=false;
                            if(captureSource.info().videoDecodePath=="decklink")snapshot_.nominalSourceFps=captureSource.info().averageFps;}
                        status(L"采集设备已重新连接，等待新画面");
                    }else{
                        captureRetryAt=Clock::now()+std::chrono::seconds(std::min(5u,captureRetries));
                        continue;
                    }
                }
                // Windows HDR flips with a newer display answer (a display or monitor
                // change, 刷新显示器状态, a session start). Reading it calls no driver; the
                // owner used to enumerate DXGI outputs here every 2 s (0.25-0.64 ms each).
                if((gd.hdrInput||options.settings.videoHdr.enabled)&&GetTickCount64()-hdrDisplayCheck>250){
                    hdrDisplayCheck=GetTickCount64();
                    const HMONITOR target=displayStates_.monitorOf(window);
                    if(const auto known=displayStates_.state(target);known&&known->serial!=hdrDisplaySerial){
                        hdrDisplaySerial=known->serial;
                        const bool active=displayHdrState.update(reinterpret_cast<std::uintptr_t>(target),known->color.hdr);
                        const bool native=options.settings.useHdrPreview(gd.hdrInput,active);
                        if(native!=gd.hdrOutput){std::lock_guard lock(mutex_);if(desired_.revision==options.settings.revision){desired_.revision=++nextRevision_;snapshot_.desired=desired_;snapshot_.applying=true;}}
                    }
                }
                if(audioStarted)publishAudioStatus();
                if(audioStarted&&injectFileEndpointLoss&&!fileEndpointLossInjected&&frames>=20){audioPipe.requestEndpointLossForTest();fileEndpointLossInjected=true;}
                advanceLive();
                if(testGpuFailureFrames>0&&frames>=uint64_t(testGpuFailureFrames)&&liveScheduler){
                    testGpuFailureFrames=0;testGpuFailure=true;
                    veyra::log::warn("engine-test",std::format("simulating a GPU frame-ready timeout; device removal after {} ms",testGpuRemoveMs));
                    if(testGpuRemoveMs>=0){
                        Microsoft::WRL::ComPtr<ID3D12Device5> device;
                        if(SUCCEEDED(ctx.device()->QueryInterface(IID_PPV_ARGS(&device))))
                            std::thread([device,delay=testGpuRemoveMs]{Sleep(DWORD(delay));device->RemoveDevice();veyra::log::warn("engine-test","device removed");}).detach();
                    }
                }
                if((liveScheduler&&liveScheduler->failed())||testGpuFailure){
                    if(!testGpuFailure&&recoverXessPresentation())continue;
                    testGpuFailure=false;
                    bool alive=ctx.reportDeviceFailure("live-presentation-failed");
                    // A GPU hang is noticed here about two seconds before Windows resets the
                    // GPU, and DRED only says which command list stopped once the device is
                    // removed (4070S field log 2026-10-01: every report still read alive).
                    // Wait for that, bounded, and report again.
                    for(int i=0;alive&&i<50;++i){Sleep(100);uint32_t removed=0;alive=ctx.checkDeviceAlive(removed);}
                    if(!alive)ctx.reportDeviceFailure("live-presentation-failed-after-reset");
                    gpuFailureAwaitingRemoval=alive;
                    {std::lock_guard lock(mutex_);snapshot_.gpuFailed=true;}
                    status(alive?L"视频队列或呈现失败；GPU 未报告设备移除，请查看诊断":L"GPU 设备已移除或驱动已重置；请稍后重新连接，可切换 NR 运行库后重试",true);break;
                }
                const float gain=muted_?0.0f:volume_.load();audio.setGain(gain);
                const float captureGain=captureAudioMonitoring_?gain:0.0f;
                if(physicalCapture)captureSource.recoverAudio(captureGain,unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                captureSource.setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                captureSource.setVerticalFlip(options.settings.captureFlipVertical);
                if(physicalCapture){const bool available=captureSource.setAudioGain(captureGain);const auto audioState=captureSource.audioState();std::lock_guard lock(mutex_);snapshot_.audioAvailable=available;snapshot_.captureAudio=audioState;snapshot_.audioInputChannels=audioState.inputChannels;snapshot_.audioOutputChannels=audioState.outputChannels;}
#ifdef VEYRA_ENABLE_REMOTEPLAY
                if(remote){remote->setAudioGain(gain);remote->setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                    const auto state=remote->audioState();const auto session=remote->sessionSnapshot();const auto rates=remote->rates();
                    std::lock_guard lock(mutex_);snapshot_.audioAvailable=state.available;snapshot_.captureAudio=state;snapshot_.remotePlayState=int(session.state);snapshot_.remotePlaySkipped=remote->skipped();snapshot_.remoteReceivedFps=rates.receivedFps;snapshot_.remoteDecodedFps=rates.decodedFps;snapshot_.remoteRatesReady=rates.ready;snapshot_.remoteReceived=rates.received;snapshot_.remoteDecoded=rates.decoded;snapshot_.remoteIngressDropped=rates.ingressDropped;}
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                if(moon){moon->setAudioGain(gain);moon->setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                    const auto state=moon->audioState();
                    std::lock_guard lock(mutex_);snapshot_.audioAvailable=state.available;snapshot_.captureAudio=state;}
#endif
#ifdef VEYRA_ENABLE_XBOX
                if(xb){xb->setAudioGain(gain);xb->setAudioSync(unsigned(options.settings.audioSync),options.settings.audioOffsetMs);
                    const auto state=xb->audioState();
                    std::lock_guard lock(mutex_);snapshot_.audioAvailable=state.available;snapshot_.captureAudio=state;}
#endif
                // Save the latest processed real frame before a settings transaction
                // invalidates it (live rendering can be one batch behind processing).
                std::wstring save;EnhancementSettings requested;std::optional<ChainRuntimeOrder> requestedOrder;
                {std::lock_guard lock(mutex_);requested=desired_;requestedOrder=desiredNodeOrder_;if(hasOutput)save.swap(savePath_);}
                if(!save.empty()){try{sink::RgbaImage result;const auto e=std::filesystem::path(save).extension().wstring();
                    const auto saved=[this](const std::wstring& path,const std::wstring& message){
                        {std::lock_guard lock(mutex_);snapshot_.savedFramePath=path;}
                        // PushFPS: a frame taken to read the text on it (ui/PushOcr.h, "pushfps-read-frame") is not a
                        // screenshot anyone asked for: it is read and deleted, and nothing is said about a file.
                        if(std::filesystem::path(path).filename().wstring().rfind(L"pushfps-read-",0)!=0)status(message);
                    };
                    drainLivePresentation();
                    if(graph->hdrOutput()){auto hdrPath=std::filesystem::path(save);hdrPath.replace_extension(L".jxr");if(sink::saveHdrScreenshot(hdrPath.wstring(),ctx,ring,graph->videoFrameResource(out.videoSlot)))saved(hdrPath.wstring(),L"HDR截图已保存："+hdrPath.wstring());else status(L"HDR截图保存失败，请查看日志",false);}else if(!sink::readRgba8(ctx,ring,graph->videoFrameResource(out.videoSlot),result)||!sink::saveImage(save,result,e==L".jpg"||e==L".jpeg",isImage?sink::ImageAlpha::Preserve:sink::ImageAlpha::Opaque))status(L"保存失败（目标文件可能已存在），播放已保留",false);else{saved(save,L"图片已保存："+save);veyra::log::info("image-save",std::format("saved extent={}x{} revision={}",gd.workWidth,gd.workHeight,options.settings.revision));}}
                    catch(const std::exception& e){veyra::log::warn("image-save",std::format("save exception; retaining session: {}",e.what()));status(L"保存异常，播放已保留；可再次保存",false);}}
                if(isImage)requested.multiplier=1;
                if(requested.revision==options.settings.revision&&requested!=options.settings){
                    options.settings.audioSync=requested.audioSync;options.settings.audioOffsetMs=requested.audioOffsetMs;
                    captureSource.setAudioSync(unsigned(requested.audioSync),requested.audioOffsetMs);
                    // Audio ingress is negotiated when the capture graph is
                    // built: record it now and tell the user a reconnect applies
                    // it instead of pretending it is already live.
                    if(requested.captureAudio!=options.settings.captureAudio){
                        options.settings.captureAudio=requested.captureAudio;
                        captureSource.setAudioIngress(unsigned(requested.captureAudio));
                        status(L"采集音频模式已记录；重新连接采集卡后生效",false);
                    }
                    // The manual capture flip is applied per sample on the
                    // DirectShow callback thread, so it is a live edit.
                    if(requested.captureFlipVertical!=options.settings.captureFlipVertical){
                        options.settings.captureFlipVertical=requested.captureFlipVertical;
                        captureSource.setVerticalFlip(requested.captureFlipVertical);
                        status(requested.captureFlipVertical?L"采集画面已上下翻转（仅影响本机采集画面）":L"采集画面方向已恢复",false);
                    }
                    // The video-pin allocator is created while the graph is
                    // built: record the mode now and let the reconnect below
                    // (or the next connect) apply it.
                    if(requested.captureBuffer!=options.settings.captureBuffer){
                        options.settings.captureBuffer=requested.captureBuffer;
                        captureSource.setBufferMode(unsigned(requested.captureBuffer));
                        status(L"设备缓冲模式已记录；重新连接采集卡后生效",false);
                    }
                    std::lock_guard lock(mutex_);snapshot_.applied=options.snapshot();snapshot_.applying=desired_!=snapshot_.applied;
                    veyra::log::info("settings",std::format("Audio applied videoRevision={} mode={} offsetMs={} (video history retained)",requested.revision,unsigned(requested.audioSync),requested.audioOffsetMs));
                }
                const auto previous=options.snapshot();const auto previousDesc=gd;const auto previousOrder=options.nodeOrder;bool transaction=false;
                if(requested.revision!=previous.revision){
                    holdFileAudio();
                    finishReset(diagnostics::ResetOutcome::Cancelled);
                    resetStart=resetStageStart=Clock::now();
                    resetRecord=diagnostics::FrameFlowMetrics::ResetRecord{};
                    resetRecord->sessionId=runSessionId;resetRecord->settingsRevision=requested.revision;
                    resetRecord->reason=static_cast<uint8_t>(pipeline::ResetReason::Settings);
                    if(frameFlow)frameFlow->resetLifecycle(*resetRecord);
                    drainLivePresentation();
                    // Rebuilding the video graph must not tear down a healthy
                    // capture audio endpoint; only the new video mapping is
                    // invalidated here. Audio transport reset is reserved for
                    // an actual pause/stop or input discontinuity.
                    if(physicalCapture)captureSource.videoReset(false);
#ifdef VEYRA_ENABLE_REMOTEPLAY
                    if(remote)remote->videoReset(false);
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                    if(moon)moon->videoReset(false);
#endif
#ifdef VEYRA_ENABLE_XBOX
                    if(xb)xb->videoReset(false);
#endif

                    // A drain may outlive several slider notifications. Build
                    // only the latest pending configuration at this boundary.
                    {std::lock_guard lock(mutex_);requested=desired_;requestedOrder=desiredNodeOrder_;}
                    if(requested.revision==previous.revision){finishReset(diagnostics::ResetOutcome::Cancelled);continue;}
                    resetRecord->settingsRevision=requested.revision;
                    auto next=PlayerOptions::from(requested,requestedOrder,&options);auto nextDesc=gd;
                    const bool nvidiaAdapter=ctx.adapter().isNvidia;
                    describeStages(stageRequest(next),next.snapshot(),nextDesc);
                    nextDesc.hdrOutput=requested.useHdrPreview(nextDesc.hdrInput,displayHdrActive());
                    // Rebuild decision.
                    //  - requiresGraphRebuild(): everything derivable from the
                    //    settings (stages, order, sizes inputs, master switches,
                    //    LUT reference). Verified against the legacy
                    //    field-by-field expression over six settings smoke cases
                    //    (master, settings, fg-only, view, output-cap, rollback)
                    //    with zero disagreements before the legacy list was
                    //    removed.
                    //  - the rest cannot come from the settings alone: the
                    //    effective HDR output depends on the display, the
                    //    extents come from the resolution plan, and a non-NVIDIA
                    //    adapter resolves requested effects differently than the
                    //    settings record.
                    bool rebuild=engine::requiresGraphRebuild(previous,requested)||previousOrder!=requestedOrder;
                    if(gd.hdrOutput!=nextDesc.hdrOutput||
                       (!nvidiaAdapter&&nvidiaOnlyStagesRequested(next.nr,next.sr,next.fg,next.settings,amdNrAdapter))||
                       gd.enableNr!=nextDesc.enableNr||gd.enableFg!=nextDesc.enableFg||
                       gd.nrBeforeSr!=nextDesc.nrBeforeSr||
                       gd.workWidth!=nextDesc.workWidth||gd.workHeight!=nextDesc.workHeight||
                       gd.nrWidth!=nextDesc.nrWidth||gd.nrHeight!=nextDesc.nrHeight||
                       gd.flowWidth!=nextDesc.flowWidth||gd.flowHeight!=nextDesc.flowHeight||
                       gd.dualSr!=nextDesc.dualSr||gd.dualSrQuality!=nextDesc.dualSrQuality||gd.firstSrWidth!=nextDesc.firstSrWidth||gd.firstSrHeight!=nextDesc.firstSrHeight||
                       gd.srInputWidth!=nextDesc.srInputWidth||gd.srInputHeight!=nextDesc.srInputHeight||
                       gd.srOutputWidth!=nextDesc.srOutputWidth||gd.srOutputHeight!=nextDesc.srOutputHeight||
                       // PushFPS: PushFlow's motion size (a preference, not a field of the settings) sizes its network.
                       gd.pushFlowMotion!=nextDesc.pushFlowMotion||gd.pushFlowEncoderCache!=nextDesc.pushFlowEncoderCache||gd.pushFlowGuard!=nextDesc.pushFlowGuard||gd.pushFlowPredict!=nextDesc.pushFlowPredict||gd.pushFlowDual!=nextDesc.pushFlowDual||
                       gd.hudStill!=nextDesc.hudStill||gd.crosshairHold!=nextDesc.crosshairHold)rebuild=true;
                    bool accepted=ring.drainQueue();out={};hasOutput=false;
                    resetRecord->rebuilt=rebuild;
                    markResetStage(diagnostics::ResetStage::Drain);
                    if(stop_)break;
                    if(!accepted){finishReset(diagnostics::ResetOutcome::Failed);status(L"设置切换排空失败，已停止",true);break;}
                    backendRecoveryWarning.clear();
                    const bool preserveWorkingFg=previous.multiplier>1&&requested.multiplier>1&&
                        (previous.frameGenerationBackend!=requested.frameGenerationBackend||previous.multiplier!=requested.multiplier||previous.vfgQuality!=requested.vfgQuality||previous.vfgAutoRegulate!=requested.vfgAutoRegulate);
                    const bool preserveWorkingNr=previous.nr&&requested.nr&&previous.nrRuntime!=requested.nrRuntime;
                    if(accepted&&rebuild){
                        if(!presenter.prepareGraphChange()){finishReset(diagnostics::ResetOutcome::Failed);status(L"设置切换呈现排空失败，已停止",true);break;}
                        bool reused=false;
                        const bool mayRetain=recentCacheAllowed&&!isCapture&&!isImage&&
                            RecentGraphCache::eligible(gd)&&RecentGraphCache::effectsOff(nextDesc);
                        if(mayRetain&&recentGraphCache.retain(graph,RecentGraphCache::key(previous,previousOrder,gd),graphBytes)){
                            graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,nullptr);
                            graphBytes=0;
                        }else{
                            graph->shutdown();
                            const auto cachedBytes=recentGraphCache.bytes();
                            auto cached=RecentGraphCache::effectsOff(nextDesc)?std::unique_ptr<pipeline::EnhanceGraph>{}:
                                recentGraphCache.take(RecentGraphCache::key(requested,requestedOrder,nextDesc));
                            if(cached){graph=std::move(cached);graphBytes=cachedBytes;reused=true;}
                            else{
                                if(!RecentGraphCache::effectsOff(nextDesc))recentGraphCache.evict("new-enhancement-key");
                                graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,recentGraphCache.hasCachedGraph()?nullptr:&coreCache);
                            }
                        }
                        markResetStage(diagnostics::ResetStage::Destroy);
                        accepted=reused?(graph->applySettings(requested)&&openPreparedPresenter(next)):
                            initializePreview(nextDesc,next,preserveWorkingFg,preserveWorkingNr);
                        markResetStage(diagnostics::ResetStage::Create);
                        if(stop_){veyra::log::info("engine","settings rebuild cancelled; skipping rollback on exit");break;}
                        if(!accepted){
                            if(!presenter.prepareGraphChange()){status(L"设置恢复呈现排空失败，已停止",true);break;}
                            graph->shutdown();recentGraphCache.evict("build-rollback");
                            graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,&coreCache);graphBytes=0;
                            if(!gpu->configureQueue(gd,!isCapture&&!isImage)||!graph->initialize(gd)||!openPreparedPresenter(options)){if(!stop_)status(L"设置失败且旧资源恢复失败，已停止",true);break;}
                        }
                    }else if(accepted)accepted=graph->applySettings(requested);
                    if(rebuild)publishFrameGenerationCapabilities();
                    if(accepted){
                        if(xessPresentationRecovery){backendRecoveryWarning=L"XeSS 呈现失败，已关闭补帧并恢复播放；错误码见日志";xessPresentationRecovery=false;}
                        if(!backendRecoveryWarning.empty()){
                            std::lock_guard lock(mutex_);desired_.rejectVideoRequest(requested,next.snapshot());snapshot_.desired=desired_;snapshot_.rejectedRevision=requested.revision;snapshot_.backendWarning=backendRecoveryWarning;
                        }
                        options=next;gd=nextDesc;transaction=true;pendingSettingsAck=true;reset=true;
                        resetRecord->epoch=0;
                        if(!nvidiaAdapter&&nvidiaOnlyStagesRequested(next.nr,next.sr,next.fg,next.settings,amdNrAdapter))veyra::log::warn("capability",std::format("non-NVIDIA adapter disabled requested settings revision={} nr={} sr={} fgBackend={} flowBackend={}",requested.revision,next.nr,next.sr,frameGenerationBackendName(requested.frameGenerationBackend),opticalFlowBackendName(requested.opticalFlowBackend)));
                    }
                    else {
                        finishReset(diagnostics::ResetOutcome::RolledBack);
                        std::lock_guard lock(mutex_);if(desired_.revision==requested.revision)desiredNodeOrder_=previousOrder;desired_.rejectVideoRequest(requested,previous);snapshot_.desired=desired_;snapshot_.rejectedRevision=requested.revision;snapshot_.applying=desired_!=previous;snapshot_.status=L"设置应用失败，已恢复上一套参数";snapshot_.backendWarning=requested.nrRuntime!=previous.nrRuntime?L"NR运行版本切换失败，已恢复上一套参数":requested.frameGenerationBackend==FrameGenerationBackend::XeSS?L"XeSS 未能启用，已恢复上一套参数":requested.frameGenerationBackend==FrameGenerationBackend::AmdFrc?L"AMD FRC 未能启用（需要 AMD 显卡和驱动自带的 AMF 运行库），已恢复上一套参数":requested.frameGenerationBackend==FrameGenerationBackend::PushFlow?L"PushFlow 未能启用（需要 DirectX 12 显卡和 PushFlow 运行组件），已恢复上一套参数":
                            requested.frameGenerationBackend==FrameGenerationBackend::Fsr4?L"FSR 4 ML 未能启用（需要支持的 RX 9000 和驱动），已恢复上一套参数":fsrFrameGeneration(requested.frameGenerationBackend)?L"FSR 3.1 帧生成未能启用，已恢复上一套参数":L"后端切换失败，已恢复上一套参数";}
                }
                // Live uniform update. The revision identifies the graph *shape*
                // (NR/SR/FG/resolution and the colour master switch); colour
                // parameters keep the same revision on purpose, so they must be
                // pushed into the running graph here - no rebuild, no history
                // reset. Without this the panel only took effect after an
                // unrelated rebuild (toggling NR): the "sliders do nothing" report.
                if(requested.revision==previous.revision&&!(requested==previous)){
                    const bool videoChanged=!requested.sameActiveVideoParameters(previous);
                    // applySettings updates descriptors and resets NR history.
                    // A stored-only edit must not call it, even while paused.
                    if(!videoChanged||graph->applySettings(requested)){
                        options=PlayerOptions::from(requested,requestedOrder,&options);
                        {std::lock_guard lock(mutex_);snapshot_.applied=options.snapshot();snapshot_.applying=desired_!=snapshot_.applied;}
                        veyra::log::info("settings",std::format("{} revision={} colourEnabled={} exposure={:.2f} contrast={:.2f} temperature={:.2f}",videoChanged?"live parameter update":"stored inactive/non-video parameters; GPU untouched",requested.revision,requested.color.enabled?1:0,requested.color.exposure,requested.color.contrast,requested.color.temperature));
                        // Colour lives inside the ingest dispatch, so a paused
                        // frame has no process() call to upload the new tables or
                        // re-run the chain: remember that the cached frame must
                        // be re-rendered before the next present.
                        if(videoChanged&&(paused_||isImage))refreshPausedFrame_=true;
                    }else{
                        std::lock_guard lock(mutex_);if(desired_.revision==requested.revision)desiredNodeOrder_=previousOrder;desired_.rejectVideoRequest(requested,previous);snapshot_.desired=desired_;snapshot_.applying=desired_!=previous;snapshot_.status=L"这套参数需要重建管线，已回到上一套数值";
                    }
                }
                if(stop_)break;
                int track=-1;double trackPosition=0;
                {std::lock_guard lock(mutex_);if(pendingAudioSession_==snapshot_.sessionId)track=pendingAudioTrack_;pendingAudioTrack_=-1;trackPosition=snapshot_.position;}
                bool switchedAudio=false;
                if(track>=0&&audioStarted&&track!=audioPipe.selectedTrack()){
                    const double clock=audio.mediaTimeMs();if(std::isfinite(clock))trackPosition=clock/1000;
                    holdFileAudio();audioPipe.stopThread();
                    const bool changed=audioPipe.selectTrack(track);
                    audioPipe.setPaused(paused_);audioPipe.startThread(&audio,true,std::max(0.0,trackPosition*1000));
                    switchedAudio=true;
                    {std::lock_guard lock(mutex_);snapshot_.selectedAudioTrack=audioPipe.selectedTrack();snapshot_.audioInputChannels=audioPipe.pcmFormat().channels;
                        if(!changed)snapshot_.backendWarning=L"音轨切换失败，已保留原音轨";
                        if(seekSeconds_.load()<0){snapshot_.seekTarget=trackPosition;++snapshot_.seekRequested;seekSeconds_=trackPosition;}}
                    log::info("audio-track",std::format("requested={} selected={} changed={} positionSeconds={:.3f}",track,audioPipe.selectedTrack(),changed,trackPosition));
                    bufferingGate.rearm(gateNow());   // 换音轨后缓冲会先清空再填，别当成断流
                }
                if(!isImage&&!isCapture&&playbackRate!=requestedPlaybackRate_.load()){
                    playbackRate=requestedPlaybackRate_.load();audioPipe.setPlaybackRate(playbackRate);
                    playbackSpeedLastWall={};cadence.reset();
                }
                double seek;{std::lock_guard lock(mutex_);seek=seekSeconds_.exchange(-1);if(seek>=0)activeSeekId=snapshot_.seekRequested;}
                if (const auto session=source.sharedSession();session&&session->timeshiftEnabled()) {
                    const bool evicted=!paused_&&session->takeTimeshiftOverrun();
                    if (seek>=0||evicted) {
                        const auto window=session->stats();
                        if (window.timeshiftEndSeconds>window.timeshiftStartSeconds) {
                            const double edge=std::max(window.timeshiftStartSeconds,
                                window.timeshiftEndSeconds-std::max(0.25,session->plan().startSeconds));
                            seek=evicted&&seek<0?window.timeshiftStartSeconds:std::clamp(seek,window.timeshiftStartSeconds,edge);
                        } else seek=-1;
                    }
                }
                if(seek>=0&&!isImage&&!isCapture){
                    seekStarted=Clock::now();seekDecoded=0;
                    holdFileAudio();fileAudioAlignPending=true;
                    drainLivePresentation();
                    if(!ring.drainQueue()){status(L"跳转失败",true);break;}
                    if(!activeSource->seek({static_cast<int64_t>(seek*1000000),1000000})){
                        const auto session=source.sharedSession();
                        if(!session||!session->timeshiftEnabled()){status(L"跳转失败",true);break;}
                        // The live window can lose its last keyframe at the memory cap.
                        // Keep the receiver alive and let the next keyframe recover it.
                        audioRebuffering=false;
                        continue;
                    }
                    seekDemuxDone=Clock::now();
                    veyra::log::info("seek-latency",std::format("request={} targetSeconds={:.3f} drainAndDemuxMs={:.3f}",activeSeekId,seek,elapsedMs(seekStarted)));
                    initialFileFramePending=false;av_frame_free(&cachedFrame);out={};hasOutput=false;
                    discardBefore=seek*1000;seekPreviewPending=true;reset=true;pendingResetCause=pipeline::ResetReason::Seek;anchorMs=discardBefore;anchor=Clock::now();lastAudioClockMs=discardBefore;audioClockExhausted=false;audioRebuffering=false;if(audioStarted){audioPipe.setPaused(paused_);if(!switchedAudio||std::abs(seek-trackPosition)>.001)audioPipe.requestSeek(discardBefore);}
                    bufferingGate.rearm(gateNow());   // 跳转后同理：先清空再填
                }
                if(!transaction&&((paused_&&!seekPreviewPending)||(isImage&&hasOutput))){
                    // A parameter change while paused (or on a still image) only
                    // reaches the picture if the cached source frame is pushed
                    // through the graph again: the grade is fused into the ingest
                    // dispatch, so nothing else would upload the new tables.
                    // NR inference reuse is a realtime-preview strategy only: the
                    // paused picture must be a fully inferred frame, so a reused
                    // last frame is re-rendered once when the pause begins.
                    if(!wasPaused&&graph->nrReuseActive()){
                        const bool reusedLast=graph->nrReuseLastFrameReused();
                        if(reusedLast)refreshPausedFrame_=true;
                        veyra::log::info("nr-reuse",std::format("pause began lastFrameReused={}{}",reusedLast,reusedLast?"; re-rendering it with full inference":""));
                    }
                    if(refreshPausedFrame_){
                        refreshPausedFrame_=false;
                        if(cachedFrame){
                            pipeline::EnhanceGraph::FrameOutputs refreshed;
                            const double refreshPtsMs=cachedPacket.pts.toDouble()*1000.0;
                            if(graph->process(cachedFrame,refreshPtsMs,true,refreshed,cachedPacket.sequence,&cachedPacket.colorInfo,&cachedPacket.hardwareSurface,false,{},0,true,{},cachedPacket.doviEl,&cachedPacket.doviP7)){
                                out=refreshed;
                                hasOutput=true;
                                // Custom: the still frame is re-presented below, so
                                // keep its Dolby Vision level 1 alongside it.
                                presenter.setFrameDovi(cachedPacket.dovi);
                                {std::lock_guard lock(mutex_);++snapshot_.pausedFrameRefreshes;}
                                veyra::log::info("settings",std::format("paused frame re-rendered with the new parameters ptsMs={:.3f}",refreshPtsMs));
                            }else{
                                veyra::log::warn("settings","paused frame re-render failed; keeping the previous output");
                            }
                        }
                    }
                    drainLivePresentation();
                    if(!wasPaused){holdFileAudio();if(physicalCapture)captureSource.videoReset();
#ifdef VEYRA_ENABLE_REMOTEPLAY
                    if(remote)remote->videoReset();
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                    if(moon)moon->videoReset();
#endif
#ifdef VEYRA_ENABLE_XBOX
                    if(xb)xb->videoReset();
#endif
}
                    presenter.cancelReflexInput();
                    if(audioStarted)audioPipe.setPaused(true);wasPaused=true;
                    // The real frame is the batch's last, or with PushFlow 2's Predict its first.
                    const auto* shownReal=hasOutput&&out.batch.count?&out.batch.frames[out.fgPredict?0:out.batch.count-1]:nullptr;
                    const bool referencesValid=shownReal&&shownReal->lease&&shownReal->lease->referencesValid;
                    if(hasOutput&&!presenter.present(ctx,ring,*graph,out.videoSlot,false,referencesValid,comparisonMode_,comparisonBase_,comparisonSplit_,out.batch.identity,previewView(),-1,true)){if(recoverXessPresentation())continue;status(L"画面呈现失败",true);break;}
                    if(hasOutput&&graph->resolveGeneration(out))completeReset(out.batch.identity);
                    // Poll live view/size changes at 50 ms; unchanged flip
                    // buffers are retained without commands or another Present.
                    std::this_thread::sleep_for(std::chrono::milliseconds(refreshPausedFrame_?1:50));continue;
                }
                if(wasPaused&&!paused_){holdFileAudio();audioRebuffering=false;if(audioStarted)audioPipe.setPaused(false);anchor=Clock::now();anchorMs=out.ptsMs;reset=true;pendingResetCause=pipeline::ResetReason::PauseResume;wasPaused=false;}
                // Backpressure before reading the capacity-one source mailbox:
                // when a lease frees we consume the newest available sample.
                if(liveScheduler&&!transaction){
                    const auto enhancementPending=[&]{
                        const bool fgRunning=options.fg;
                        if(presentationEffective.enabled&&!fgRunning&&(isCapture||!fileAwaitingVideo)&&liveScheduler->occupancy()>=1)return true;
                        // Explicit VSync, live, no generation: throttle only before the
                        // read. A frame read while the display queue is full would wait
                        // there a refresh; waiting first lets the mailbox hand over a
                        // newer frame instead (latency-min B3).
                        if(isCapture&&presentationPaced&&!fgRunning&&(liveScheduler->occupancy()>=1||!presenter.presentationReady()))return true;
                        // Live sources: never stack a second frame behind one the GPU
                        // is still enhancing. When NR/SR cost more than one source
                        // interval, a second queued frame doubled capture-to-present
                        // latency (3 NR layers at 1440p60: 49 ms for 20 ms of GPU
                        // work); waiting and then taking the newest mailbox sample
                        // keeps it at one GPU pass. No effect while the GPU keeps up.
                        return isCapture&&!(fgRunning&&presentSinkFrameGeneration(options.settings.frameGenerationBackend)&&(xessStackedReads||xessPresentAfterReady))&&!pendingCompletions.empty();
                    };
                    const auto leaseWaitStart=Clock::now();
                    while((liveScheduler->occupancy()>=2||!graph->nextFrameSlotAvailable()||enhancementPending())&&!stop_&&(!paused_||seekPreviewPending)&&!liveScheduler->failed()){
                        networkTick();
                        advanceLive();if(seekSeconds_>=0)break;
                        if(liveScheduler->occupancy()==0&&!graph->nextFrameSlotAvailable()&&elapsedMs(leaseWaitStart)>2000){status(L"等待输出纹理释放超时",true);stop_=true;break;}
                        if(liveScheduler->occupancy()>=2||!graph->nextFrameSlotAvailable()||enhancementPending()){
                            // Only the display queue is outstanding: wake on its latency object
                            // (acquiring it) instead of a 1 ms poll.
                            if(isCapture&&presentationPaced&&liveScheduler->occupancy()==0&&pendingCompletions.empty()&&graph->nextFrameSlotAvailable())presenter.waitPresentationReady(1);
                            else waitLive();
                        }
                        std::lock_guard lock(mutex_);if(desired_.revision!=options.settings.revision)break;
                    }
                    if(stop_||seekSeconds_>=0||(paused_&&!seekPreviewPending)||liveScheduler->failed()||liveScheduler->occupancy()>=2||!graph->nextFrameSlotAvailable()||enhancementPending())continue;
                }
                if(graph->autoNrPoolReady()&&frameFlow&&!transaction&&!paused_){
                    const auto now=host100ns();
                    if(autoNrRevision!=options.settings.revision||autoNrControl.level()!=graph->autoNrLevel()){
                        autoNrControl.reset(now,graph->autoNrLevel());autoNrRevision=options.settings.revision;
                    }
                    if(reset)autoNrControl.discardObservations(now);
                    const auto timing=frameFlow->snapshot(now).enhancementProcessing;
                    const double transportFps=activeSource->info().averageFps*playbackRate;
                    const double budget=std::isfinite(transportFps)&&transportFps>0?800.0/transportFps:0;
                    const auto next=autoNrControl.observe(now,timing.p95,timing.samples,budget);
                    if(now>=autoNrLogAt){
                        veyra::log::info("nr-auto",std::format("level={} budgetMs={:.3f} p95Ms={:.3f} samples={} reason=observe",
                            AutoNrController::percent(graph->autoNrLevel()),budget,timing.p95.value_or(0),timing.samples));
                        autoNrLogAt=now+10000000;
                    }
                    if(next){
                        const auto started=Clock::now();
                        // Finish submitted pictures in order. Cancel would drop
                        // real frames and conceal the switch gap.
                        while(liveScheduler&&liveScheduler->occupancy()&&!stop_&&!paused_&&seekSeconds_<0&&!liveScheduler->failed()){
                            advanceLive();if(liveScheduler->occupancy())waitLive();
                        }
                        if(stop_||paused_||seekSeconds_>=0)continue;
                        if((liveScheduler&&liveScheduler->failed())||!ring.drainQueue()){
                            status(L"自动NR切档排空失败",true);break;
                        }
                        pollCompletions();pendingCompletions.clear();out={};hasOutput=false;
                        if(!graph->selectAutoNrLevel(*next)){
                            veyra::log::error("nr-auto","normal playback switch refused after draining presentation leases");
                            status(L"自动NR切档失败",true);break;
                        }
                        autoNrControl.discardObservations(host100ns());
                        veyra::log::info("nr-auto",std::format("level={} budgetMs={:.3f} p95Ms={:.3f} reason={} boundaryMs={:.3f} cancelledJobs={}",
                            AutoNrController::percent(*next),budget,timing.p95.value_or(0),timing.p95.value_or(0)>budget?"over-budget":"sustained-headroom",
                            elapsedMs(started),presentationCancelledJobs.load()));
                    }
                }
                // NR inference reuse, Auto: a level change is a scheduling choice
                // inside the graph, so nothing drains or rebuilds (AutoNrReuseController).
                if(graph->nrReuseAutomatic()&&frameFlow&&!transaction&&!paused_){
                    const auto now=host100ns();
                    if(nrReuseRevision!=options.settings.revision||nrReuseControl.level()!=graph->nrReuseLevel()){
                        nrReuseControl.reset(now,graph->nrReuseLevel());nrReuseRevision=options.settings.revision;
                    }
                    if(reset)nrReuseControl.discardObservations(now);
                    const auto flow=frameFlow->snapshot(now);
                    std::optional<double> nrMs;
                    for(auto stage:{diagnostics::GpuStage::NrLayer0,diagnostics::GpuStage::NrLayer1,diagnostics::GpuStage::NrLayer2,diagnostics::GpuStage::NrLayer3}){
                        const auto& a=flow.gpuTiming[size_t(stage)];
                        // Reused frames add zero-length samples, so the mean is per
                        // source frame; the P95 is the cost of one inference.
                        if(a.samples&&a.p95&&std::isfinite(*a.p95))nrMs=nrMs.value_or(0)+*a.p95;
                    }
                    const double transportFps=activeSource->info().averageFps*playbackRate;
                    const double budget=std::isfinite(transportFps)&&transportFps>0?800.0/transportFps:0;
                    const auto& timing=flow.enhancementProcessing;
                    if(const auto next=nrReuseControl.observe(now,timing.mean,timing.samples,nrMs,budget)){
                        graph->setNrReuseLevel(*next);
                        veyra::log::info("nr-reuse",std::format("auto level={} framesPerReuse={} meanMs={:.3f} nrMs={:.3f} budgetMs={:.3f} samples={}",
                            *next,pipeline::NrReuseScheduler::framesPerReuse(*next),timing.mean.value_or(0),nrMs.value_or(0),budget,timing.samples));
                    }else if(now>=nrReuseLogAt){
                        veyra::log::info("nr-reuse",std::format("auto observe level={} meanMs={:.3f} nrMs={:.3f} budgetMs={:.3f} samples={} reused={}",
                            graph->nrReuseLevel(),timing.mean.value_or(0),nrMs.value_or(0),budget,timing.samples,graph->metrics().nrReuseFrames));
                        nrReuseLogAt=now+100000000;
                    }
                }
                // Wait before selecting the latest sample, not after enhancement.
                // A driver Sleep beyond this (once per accepted live source; the GPU
                // already finished the last one here) is a stall, see ReflexSession.
                const auto reflexStallUs=isCapture?uint64_t(std::max(6000.0,0.6e6/std::clamp(activeSource->info().averageFps,10.0,500.0))):0;
                if(!presenter.beginSourceInput(reflexStallUs)){status(L"XeSS input timing failed",true);break;}
                const auto decodeStart=Clock::now();
                loopTrace.mark("controlAndSchedule");
                if(injectSourceGap&&frames>=12){
                    if(!sourceGapUntil){sourceGapUntil=Clock::now()+std::chrono::milliseconds(400);veyra::log::info("capture-test","inject 400ms Waiting before next source read");}
                    if(Clock::now()<*sourceGapUntil){advanceLive();publishWaitingProgress();waitLive();continue;}
                }
                pipeline::FramePacket pkt;const AVFrame* frame=imageFrame;
                if(cachedFrame&&((initialRemoteFramePending||initialFileFramePending)||(transaction&&(!isCapture||paused_)))){frame=cachedFrame;pkt=cachedPacket;initialRemoteFramePending=false;initialFileFramePending=false;}
                else if(!isImage){
                    auto rs=physicalCapture?captureSource.tryRead(pkt,&frame):activeSource->read(pkt,&frame);
                    // Keep the accepted transaction and rollback state alive until
                    // the next real capture sample arrives. Never bind old PTS to now.
                    while(transaction&&isCapture&&rs==source::SourceReadStatus::Waiting&&!stop_){
                        if(paused_&&cachedFrame){frame=cachedFrame;pkt=cachedPacket;rs=source::SourceReadStatus::Frame;break;}
                        advanceLive();publishWaitingProgress();waitLive();rs=physicalCapture?captureSource.tryRead(pkt,&frame):activeSource->read(pkt,&frame);
                    }
                    if(stop_)break;
                    if(rs==source::SourceReadStatus::Waiting){if(isScreen){std::lock_guard lock(mutex_);snapshot_.sourceNotice=screenSource.status();}if(isFrameInput){std::lock_guard lock(mutex_);snapshot_.sourceNotice=frameInputSource.status();}advanceLive();publishWaitingProgress();waitLive();continue;}
                    if(rs==source::SourceReadStatus::Eos){
                        fileInputEnded=true;
                        while(liveScheduler&&liveScheduler->occupancy()&&!stop_&&(!paused_||seekPreviewPending)&&!liveScheduler->failed()){advanceLive();if(liveScheduler->occupancy())waitLive();}
                        if(stop_)break;
                        if(liveScheduler&&liveScheduler->failed()){status(L"视频尾帧呈现失败，请查看诊断",true);break;}
                        if(paused_)continue;
                        collectTimings();seekPreviewPending=false;status(L"视频已播放完毕");paused_=true;
                        publishWaitingProgress(true);{std::lock_guard lock(mutex_);snapshot_.transport=TransportState::Ended;}
                        continue;
                    }
                    if(rs!=source::SourceReadStatus::Frame||pkt.pts.isUnknown()){
                        if(physicalCapture){
                            drainLivePresentation();if(!ring.drainQueue()){status(L"采集恢复时GPU排空失败",true);break;}
                            captureSource.videoReset();av_frame_free(&cachedFrame);hasOutput=false;out={};
                            captureRecovering=true;captureRetries=0;captureRetryAt=Clock::now()+std::chrono::milliseconds(500);
                            {std::lock_guard lock(mutex_);snapshot_.captureRecovering=true;snapshot_.captureFps=0;}
                            status(captureSource.errorMessage().empty()?L"采集信号中断，等待原设备恢复":captureSource.errorMessage());continue;
                        }
#ifdef VEYRA_ENABLE_REMOTEPLAY
                        if(remote){const auto recovery=remote->recoveryStatus();status(recovery.message.empty()?L"PS5 串流异常，请检查主机状态后重新连接。":recovery.message,true);break;}
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                        if(moon){const auto message=moon->stats().message;status(message.empty()?L"串流中断，请检查主机和网络后重新连接。":message,true);break;}
#endif
#ifdef VEYRA_ENABLE_XBOX
                        if(xb){
                            const auto failure=xb->stats();
                            if(failure.reconnectable && xboxRequest && !stop_){
                                xboxReconnectBudget.disconnected();
                                drainLivePresentation();
                                if(!ring.drainQueue()){status(L"Xbox 重连时 GPU 排空失败",true);break;}
                                xb->videoReset();av_frame_free(&cachedFrame);out={};hasOutput=false;
                                bool recovered=false;
                                while(!stop_ && xboxReconnectBudget.take()){
                                    const auto attempt=xboxReconnectBudget.attempts();
                                    status(std::format(L"Xbox 串流中断（{}），正在重连 {}/3…",std::wstring(failure.disconnectReason.begin(),failure.disconnectReason.end()),attempt));
                                    veyra::log::warn("xbox-reconnect",std::format("attempt={} reason={}",attempt,failure.disconnectReason));
                                    for(unsigned wait=0;wait<attempt*10&&!stop_;++wait)std::this_thread::sleep_for(std::chrono::milliseconds(100));
                                    if(stop_)break;
                                    if(!xb->connect(*xboxRequest))continue;
                                    const auto deadline=Clock::now()+std::chrono::seconds(20);
                                    while(!stop_&&Clock::now()<deadline){
                                        const AVFrame* first=nullptr;
                                        const auto result=xb->read(cachedPacket,&first);
                                        if(result==source::SourceReadStatus::Frame){cachedFrame=av_frame_clone(first);recovered=cachedFrame!=nullptr;break;}
                                        if(result==source::SourceReadStatus::Error)break;
                                        std::this_thread::sleep_for(std::chrono::milliseconds(2));
                                    }
                                    if(recovered)break;
                                    xb->close();
                                }
                                if(recovered){
                                    initialRemoteFramePending=true;reset=true;pendingResetCause=pipeline::ResetReason::SourceSwitch;
                                    status(L"Xbox 已重新连接");veyra::log::info("xbox-reconnect","first decoded frame received; reset all graph history");
                                    continue;
                                }
                                if(stop_)break;
                                status(L"Xbox 重连失败："+xb->stats().message,true);break;
                            }
                            status(failure.message.empty()?L"Xbox 串流中断，请重新连接。":failure.message,true);break;
                        }
#endif
                        status(isScreen?screenSource.status():isFrameInput?frameInputSource.status():isCapture?L"采集信号中断，请检查设备连接或格式":source.errorMessage().empty()?L"视频解码或时间戳错误":source.errorMessage(),true);break;}
                }
                if(isScreen){std::lock_guard lock(mutex_);snapshot_.sourceNotice=screenSource.status();}
                if(isFrameInput){std::lock_guard lock(mutex_);snapshot_.sourceNotice=frameInputSource.status();}
                const bool nativeCapture=physicalCapture&&activeSource->info().videoDecodePath=="decklink";
                if((isStream||isScreen||isFrameInput||nativeCapture)&&frame&&(uint32_t(frame->width)!=width||uint32_t(frame->height)!=height||(isScreen&&gd.hdrInput!=activeSource->info().color.isHdrPath())||
                    (nativeCapture&&!source::decklink::sameColor(captureGraphColor,activeSource->info().color)))){
                    drainLivePresentation();if(!ring.drainQueue()){status(L"串流尺寸切换排空失败",true);break;}
                    width=uint32_t(frame->width);height=uint32_t(frame->height);
                    describeStages(stageRequest(options),options.snapshot(),gd);
                    gd.hdrInput=!isImage&&activeSource->info().color.isHdrPath();gd.hdrOutput=options.settings.useHdrPreview(gd.hdrInput,displayHdrActive());
                    const auto resizeSourceColor=activeSource->info().color;
                    const unsigned resizeMastering=hdrMetadataNits(resizeSourceColor.hdrMasteringPeakNits);
                    const unsigned resizeCll=hdrMetadataNits(resizeSourceColor.hdrMaxCllNits);
                    const unsigned resizeFall=hdrMetadataNits(resizeSourceColor.hdrMaxFallNits);
                    if(nativeCapture){
                        captureGraphColor=activeSource->info().color;gd.rgbInput=captureGraphColor.pixelFormat==pipeline::SourcePixelFormat::Bgra8;
                        gd.yuy2Input=false;gd.packedInput=pipeline::packedInputCode(captureGraphColor.pixelFormat);gd.captureBitDepth=ingressBitDepth(captureGraphColor.pixelFormat);
                    }
                    // Window capture publishes the same geometry used to rebuild
                    // the graph, rather than retaining its opening DAR.
                    if(isScreen||isFrameInput||nativeCapture){
                        std::lock_guard lock(mutex_);snapshot_.sourceWidth=width;snapshot_.sourceHeight=height;snapshot_.sourceHdr=gd.hdrInput;snapshot_.sourceMasteringPeakNits=resizeMastering;snapshot_.sourceMaxCllNits=resizeCll;snapshot_.sourceMaxFallNits=resizeFall;snapshot_.sourceDisplayAspect=activeSource->info().displayAspect;
                    }
                    if(!presenter.prepareGraphChange()){status(L"输入尺寸切换呈现排空失败",true);break;}
                    graph->shutdown();recentGraphCache.evict("source-resize");
                    graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,&coreCache);graphBytes=0;out={};hasOutput=false;
                    if(!graph->initialize(gd)||!openPreparedPresenter(options)){if(!stop_)status(L"串流尺寸切换失败",true);break;}
                    reset=true;pendingResetCause=pipeline::ResetReason::Resize;
                }
                if(vramRecoverStep){
                    // Video memory watchdog (see watchVram): rebuild between frames, measure later.
                    const int step=vramRecoverStep;vramRecoverStep=0;
                    drainLivePresentation();if(!ring.drainQueue()){status(L"显存回收时排空失败",true);break;}
                    recentGraphCache.evict("memory-recovery");
                    uint64_t budget=0;ctx.videoMemoryInfo(budget,vramRecoverBefore);
                    veyra::log::warn("vram-watch",std::format("rebuilding the {} to release video memory (usage {} MiB)",step==1?"presentation swapchain":"processing graph and swapchain",vramRecoverBefore>>20));
                    presenter.close();
                    if(step==2){graph->shutdown();graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,&coreCache);graphBytes=0;out={};hasOutput=false;}
                    if(step==1&&testLeakReleases)testLeak.clear();
                    if((step==2&&!graph->initialize(gd))||!openPreparedPresenter(options,step==2)){if(!stop_)status(L"显存回收后重建失败，请重新打开片源",true);break;}
                    reset=true;pendingResetCause=pipeline::ResetReason::Resize;
                    vramRecoverDone=step;vramRecoverCheckAt=Clock::now()+std::chrono::seconds(3);
                }
                const bool rereadCached=transaction&&frame==cachedFrame;
                if(testReplayAsCard&&testReplayDropEvery>1&&!rereadCached){
                    if(pkt.sequence%testReplayDropEvery==0){
                        testReplayDropPending=true;
                        veyra::log::info("capture-replay-drop",std::format("source={} (test-only missed mailbox input)",pkt.sequence));
                        continue;
                    }
                    if(testReplayDropPending){pkt.flags|=static_cast<pipeline::FrameFlags>(pipeline::FrameFlagBits::Drop);testReplayDropPending=false;}
                }
                if(!isImage&&!isCapture&&seekSeconds_>=0)continue;
                const bool halfRate=isCapture&&options.settings.content==ContentRate::Capture60To30&&
                    CaptureHalfRate::supported(activeSource->info().averageFps);
                const bool dedupActive=isCapture&&!isImage&&!legacyCadence&&dedupContent(options.settings.content);
                // The callback compares whole pictures only while dedup or the 60->30 phase needs them.
                if(physicalCapture)captureSource.setPictureCompare(dedupActive||halfRate);
                const int64_t driverPts100ns=pkt.pts.isUnknown()?0:pkt.pts.to100ns();
                const auto capturePeriod=liveSourceInterval100ns(pipeline::Rational::unknown(),activeSource->info().averageFps);
                bool captureClockCorrected=false;
                int64_t dedupHoldInterval100ns=0;
                if(physicalCapture&&!nativeCapture&&!captureSource.compressedVideo()&&!rereadCached&&
                   CaptureHalfRate::supported(activeSource->info().averageFps)&&!pkt.pts.isUnknown()&&pkt.arrivalHost100ns>0){
                    const bool wasCorrecting=capturePreviewClock.correcting();
                    const auto flagsWithoutDrop=pkt.flags&~static_cast<pipeline::FrameFlags>(pipeline::FrameFlagBits::Drop);
                    const auto clock=capturePreviewClock.observe(pkt.sequence,driverPts100ns,pkt.arrivalHost100ns,capturePeriod,
                        pipeline::breaksHistory(flagsWithoutDrop)||pipeline::hasFrameFlag(pkt.flags,pipeline::FrameFlagBits::Open));
                    captureClockCorrected=clock.corrected;
                    if(clock.discontinuity)pkt.flags|=static_cast<pipeline::FrameFlags>(pipeline::FrameFlagBits::Discontinuity);
                    if(wasCorrecting!=clock.corrected)
                        veyra::log::info("capture-preview-clock",std::format("source={} corrected={} driverPts100ns={} previewPts100ns={} nominalPeriod100ns={} (video scheduling only)",pkt.sequence,clock.corrected,driverPts100ns,clock.pts,capturePeriod));
                    if(clock.corrected){
                        pkt.pts={clock.pts,10000000};
                        pkt.duration={capturePeriod,10000000};
                    }
                }
                // Drop is a late capacity-one mailbox reader, not a source clock
                // boundary. Resetting the half-rate sampler here accepted each
                // dropped packet as a new first frame, defeating 60->30 under load.
                const bool cadenceBoundary=presentationGenerationResetRequired(reset,pkt.flags);
                if(cadenceBoundary)captureSampler.reset();
                const int64_t samplePts100ns=captureClockCorrected?pkt.pts.to100ns():driverPts100ns;
                if(dedupActive&&!rereadCached&&!pkt.pts.isUnknown()){
                    const auto interval=capturePeriod;
                    pipeline::PictureReference::Result picture;
                    const auto compareStart=Clock::now();
                    const bool pictured=pipeline::captureFramePicture(frame,enginePictures,gd.packedInput==6||gd.packedInput==7,picture);
                    if(pictured&&picture.repeat){dedupRepeatMax8=std::max(dedupRepeatMax8,picture.max8);dedupRepeatMaxOver=std::max(dedupRepeatMaxOver,picture.over);}
                    else if(pictured&&picture.over)dedupNewMinOver=std::min(dedupNewMinOver,picture.over);
                    const bool boundary=cadenceBoundary||dedupRevision!=options.settings.revision;
                    dedupRevision=options.settings.revision;
                    const auto content=options.settings.content;
                    const int64_t hint=content==ContentRate::Fps30?333333:content==ContentRate::Fps50?200000:content==ContentRate::Fps60?166667:0;
                    const auto* capturedPicture=pipeline::captureUploadFrame(frame);
                    const auto pictureSequence=capturedPicture&&capturedPicture->pictureValid?pkt.sequence:0;
                    const auto decision=contentDedup.observe(pictured?&picture.id:nullptr,pkt.pts.to100ns(),interval,boundary,hint,pictureSequence);
                    const double dedupUs=elapsedMs(compareStart)*1000;
                    if(veyra::log::verboseFrameLogs())veyra::log::info("content-dedup-frame",std::format("source={} pts100ns={} keep={} reason={} picture={:x} withinBand={} over={} maxDiff={} contentPts100ns={} intervalMs={:.3f} cpuUs={:.1f}",
                        pkt.sequence,pkt.pts.to100ns(),decision.keep,decision.reason,pictured?picture.id:0,picture.repeat,picture.over,picture.max8,decision.contentPts,decision.interval/1e4,dedupUs));
                    if(!decision.keep){std::lock_guard lock(mutex_);++snapshot_.captureRateSkipped;continue;}
                    dedupHoldInterval100ns=decision.holdInterval;
                    int64_t contentPts=decision.contentPts,contentInterval=decision.interval;
                    // Frame generation shows a real frame one content interval after it
                    // arrives, which is the room the repair uses; without it there is none.
                    if(options.settings.pacingRepair&&options.fg&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend)){
                        const bool restart=boundary||decision.holdInterval>0;
                        const auto repaired=pacingRepair.apply(pkt.pts.to100ns(),contentPts,capturePeriod,restart);
                        contentPts=repaired.pts;
                        if(pacingHaveLast&&!restart&&contentPts>pacingLastPts)contentInterval=contentPts-pacingLastPts;
                        const auto now100=host100ns();
                        if(now100>=nextPacingLog){nextPacingLog=now100+50000000;const auto& st=pacingRepair.stats();
                            veyra::log::info("push-pacing-repair",std::format("revision={} frames={} repaired={} restarts={} variable={} maxLateMs={:.2f} maxEarlyMs={:.2f} contentFps={:.2f}",
                                options.settings.revision,st.frames,st.repaired,st.restarts,st.variable,st.maxLate/1e4,st.maxEarly/1e4,contentDedup.contentFps()));}
                        {std::lock_guard lock(mutex_);snapshot_.pacingFrames=pacingRepair.stats().frames;snapshot_.pacingRepaired=pacingRepair.stats().repaired;}
                    }else pacingRepair.reset();
                    pacingLastPts=contentPts;pacingHaveLast=true;
                    pkt.pts={contentPts,10000000};
                    if(contentInterval>0)pkt.duration={contentInterval,10000000};
                }else if(halfRate&&!rereadCached){
                    // 60->30: every second sample on the effective capture clock; a due
                    // repeat of the last kept picture waits for the next new picture.
                    // Only a number the capture callback already computed is used, so the
                    // engine thread never compares a whole picture for this.
                    const auto interval=capturePeriod;
                    const auto* upload=pipeline::captureUploadFrame(frame);
                    const uint64_t* picture=upload&&upload->pictureValid?&upload->pictureId:nullptr;
                    const auto shifts=captureSampler.shifts();
                    if(!pkt.pts.isUnknown()&&!captureSampler.accept(pkt.pts.to100ns(),interval,false,picture,pkt.sequence)){
                        std::lock_guard lock(mutex_);++snapshot_.captureRateSkipped;continue;
                    }
                    if(captureSampler.shifts()!=shifts||(picture&&captureSampler.gridKept()%600==0))
                        veyra::log::info("capture-rate",std::format("60->30 phase: shifts={} keptOnGrid={} secondCopiesKept={} repeatsSkipped={} repeatsHeld={} (a 30 fps game moves onto first copies; below 30 a due repeat waits for the next picture; 60 fps content never repeats)",
                            captureSampler.shifts(),captureSampler.gridKept(),captureSampler.secondCopiesKept(),captureSampler.repeatsSkipped(),captureSampler.repeatsHeld()));
                    pkt.duration={interval*2,10000000};
                }
                if(!halfRate)captureSampler.reset();
                // PushFPS ground-truth quality test: every second frame is kept back while it runs;
                // frame generation makes that moment and PushQualityProbe compares it with the original.
                if(!rereadCached&&!pkt.pts.isUnknown()&&quality_->running()&&quality_->withhold(frame,pkt.pts.to100ns(),gd.packedInput!=0)){
                    std::lock_guard lock(mutex_);++snapshot_.captureRateSkipped;continue;
                }
                if(isCapture&&!rereadCached&&veyra::log::verboseFrameLogs())
                    veyra::log::info("cadence-input",std::format("source={} driverPts100ns={} samplePts100ns={} pts100ns={} clockCorrected={} dedup={} halfRate={}",pkt.sequence,driverPts100ns,samplePts100ns,pkt.pts.isUnknown()?0:pkt.pts.to100ns(),captureClockCorrected,dedupActive,halfRate));
                if(isImage)pkt.sequence=1;
#ifdef VEYRA_ENABLE_XBOX
                if(xb&&!rereadCached)xboxReconnectBudget.decoded(monotonic100ns());
#endif
                if(!rereadCached)++sourceFrames;
                const double decodeMs=elapsedMs(decodeStart);decodeTimes.add(decodeMs);
                loopTrace.mark("read");
                double pts=isImage?0:pkt.pts.toDouble()*1000;
                if(isCapture&&frames==0){anchor=Clock::now();anchorMs=pts;}
                if(seekPreviewPending)++seekDecoded;
                if(pts+0.1<discardBefore)continue;
                auto retainCandidate=[&](){
                    if(frame==cachedFrame)return true;
                    AVFrame* owned=av_frame_clone(frame);
                    if(!owned)return false;
                    av_frame_free(&cachedFrame);cachedFrame=owned;cachedPacket=pkt;
                    // The enhancement layer is a borrowed pointer whose owner
                    // (MediaFileSource::elFrame_) frees it on the next pairing or on
                    // open failure; a cached packet can outlive that. A replay of the
                    // cached candidate renders the base layer for one frame instead
                    // of dereferencing a freed frame.
                    cachedPacket.doviEl=nullptr;
                    frame=cachedFrame;
                    return true;
                };
                // Realtime preview candidates: decode stays ordered and
                // reference-lossless; an expired candidate loses only its
                // enhancement/display opportunity (plan §4.3). The open/seek
                // anchor, paused seek preview and settings replay never drop.
                if(!isCapture&&!isImage&&!transaction&&!fileAwaitingVideo&&!seekPreviewPending){
                    const double previewIntervalMs=double(liveSourceInterval100ns(pkt.duration,activeSource->info().averageFps))/10000.0;
                    bool previewSourceFailed=false;
                    while(!stop_&&previewCandidateExpired(nowMs(),pts,previewIntervalMs)){
                        // read() can clear the decoder's borrowed AVFrame even
                        // on EOS/EAGAIN. Own this candidate before looking ahead.
                        if(!retainCandidate()){previewSourceFailed=true;break;}
                        pipeline::FramePacket next;const AVFrame* raw=nullptr;
                        const auto rs=activeSource->read(next,&raw);
                        if(rs==source::SourceReadStatus::Eos)break; // final decoded candidate is kept
                        if(rs==source::SourceReadStatus::Waiting)break; // network buffering: nothing newer yet, keep this candidate
                        if(rs!=source::SourceReadStatus::Frame||next.pts.isUnknown()){previewSourceFailed=true;break;}
                        const double nextPts=next.pts.toDouble()*1000;
                        if(nextPts+0.1<discardBefore)continue; // post-seek decode residue keeps dropping
                        pkt=next;frame=raw;
                        pts=nextPts;
                        ++previewSkippedTotal;++previewSkippedSinceSubmit;previewSkipSinceProcess=true;
                    }
                    if(previewSourceFailed){status(source.errorMessage().empty()?L"视频读取或候选帧保存失败":source.errorMessage(),true);break;}
                }
                if(!retainCandidate()){status(L"无法保存解码帧，已停止播放",true);break;}
                if(testReplayAsCard||(testArrivalJitterMs>0&&isScreen)){
                    double sum=0;for(int i=0;i<12;++i){testArrivalSeed=testArrivalSeed*1664525u+1013904223u;sum+=double(testArrivalSeed>>8)/double(1u<<24);}
                    // A card's clock: 800 ppm slow against the host, as in the field log.
                    if(testReplayAsCard&&!testCardStart){testCardStart=host100ns();testCardFirstPtsMs=pkt.pts.toDouble()*1000;}
                    const auto line=testReplayAsCard?testCardStart+int64_t((pkt.pts.toDouble()*1000-testCardFirstPtsMs)*10000*1.0008):pkt.arrivalHost100ns;
                    const auto until=line+int64_t(std::max(0.0,sum-3)*testArrivalJitterMs*10000);
                    while(host100ns()<until){advanceLive();std::this_thread::yield();}
                    pkt.arrivalHost100ns=host100ns();
                }
                const auto processStart=Clock::now();
                const auto captureArrival=pkt.arrivalHost100ns?pkt.arrivalHost100ns:host100ns();
                // A PS5 callback is a compressed AU, not a decoded video frame.
                // Its decode baseline must not consume the entire FG lookahead
                // budget. Still measure full ingress latency from captureArrival.
                const auto liveInputReady=isStream&&pkt.decodedHost100ns>0?pkt.decodedHost100ns:captureArrival;
                const auto sourceArrival=pkt.arrivalHost100ns?pkt.arrivalHost100ns:std::chrono::duration_cast<std::chrono::nanoseconds>(decodeStart.time_since_epoch()).count()/100;
                // A skipped preview candidate breaks the temporal span the
                // motion/NR/FG history was built on: the next processed frame
                // is an explicit history reset (plan §4.4). It is a SOFT
                // break: metrics windows, completion predictions and reset
                // lifecycle records continue (only hard resets — open/seek/
                // pause/discontinuity/settings — reopen them).
                const bool hardFrameReset=reset||pipeline::breaksHistory(pkt.flags&~static_cast<pipeline::FrameFlags>(pipeline::FrameFlagBits::Drop));
                // A bounded preview skip (at most two dropped candidates, no
                // source discontinuity) keeps NR/FG/XeSS history: the graph's
                // A is still the last PROCESSED frame with its real PTS, so
                // motion, generated-frame PTS and temporal blending stay on
                // the true timeline, merely spanning 2-3 source periods.
                // Clearing history here made 25% of presented real frames
                // reset frames under load (review 2026-09-22): XeSS skipped
                // generation, NR reseeded, DLSS lost the whole group. Larger
                // skips still reset. VEYRA_TEST_PREVIEW_SKIP_RESET restores
                // the unconditional reset for A/B runs.
                static const bool skipAlwaysResets=GetEnvironmentVariableW(L"VEYRA_TEST_PREVIEW_SKIP_RESET",nullptr,0)>0;
                // Retain temporal history across a skip when the gap to the
                // last processed frame is short enough that optical flow can
                // still track it. Two earlier criteria were wrong:
                //   - the count bound (<=2) used previewSkippedSinceSubmit,
                //     which is cleared on SUBMIT, not on process, so skips
                //     accumulated across frames that were processed but not
                //     submitted and tripped the bound spuriously;
                //   - a count says nothing about the actual temporal gap.
                // Measured 2026-09-22 on a user report of NR flicker under
                // load: when the scheduler falls behind it skips 4-10
                // candidates per second, so the bound never held, every burst
                // forced kReset=1 into the NR feature, and the denoiser
                // re-converged several times a second - visible as flicker at
                // exactly the drop rate. A gap this small is just a briefly
                // lower frame rate; it is not new content.
                // Capture drops land here too. Drop means the mailbox discarded
                // stale frames because WE were slow; the content is continuous
                // and the next frame is simply further along - the same
                // situation as a preview skip. It is already excluded from
                // hardFrameReset above and from the presentation reset policy,
                // but it still reached temporalBreak below, so every capture
                // drop reset NR and handed the XeSS/FSR provider reset=1. That
                // re-warm at the capture drop rate is the flicker reported for
                // live capture (2026-09-22). Real breaks still arrive as Seek,
                // Cut, Discontinuity, Resize, PauseResume or DeviceLost.
                constexpr double kRetainHistoryGapMs=250.0;
                const auto flagsWithoutDrop=pkt.flags&~static_cast<pipeline::FrameFlags>(pipeline::FrameFlagBits::Drop);
                const bool captureDropped=pipeline::hasFrameFlag(pkt.flags,pipeline::FrameFlagBits::Drop);
                const bool gapCandidate=previewSkipSinceProcess||captureDropped;
                const double skipGapMs=gapCandidate&&std::isfinite(lastProcessedPtsMs)?pts-lastProcessedPtsMs:0.0;
                const bool boundedSkip=gapCandidate&&!skipAlwaysResets&&
                    std::isfinite(lastProcessedPtsMs)&&skipGapMs>0&&skipGapMs<=kRetainHistoryGapMs&&
                    !pipeline::breaksHistory(flagsWithoutDrop);
                if(boundedSkip){++previewSkipRetained;
                    if(host100ns()>=nextPreviewSkipLog){nextPreviewSkipLog=host100ns()+10000000;
                        veyra::log::info("preview-skip",std::format("retained history across a {:.1f} ms gap source={} retainedTotal={} skippedTotal={} (bounded skip; no NR/FG/XeSS reset)",skipGapMs,pkt.sequence,previewSkipRetained,previewSkippedTotal));}
                }
                const bool temporalBreak=pipeline::breaksHistory(flagsWithoutDrop)||(gapCandidate&&!boundedSkip);
                const bool previewOnlyReset=!hardFrameReset&&temporalBreak;
                if(hardFrameReset)++metricsWindowEpoch;
                const bool historyReset=hardFrameReset||temporalBreak;
                if(historyReset){++historyResets;liveArrival.reset();}
                if(presentationGenerationResetRequired(reset,pkt.flags))++presentationGeneration;
                // A mailbox Drop must reset SR/NR/flow/FG history, but draining
                // the two-batch presenter here discarded completed real frames.
                if(liveScheduler&&presentationDrainRequired(reset,pkt.flags))drainLivePresentation();
                const bool injectedReject=transaction&&!options.nr&&GetEnvironmentVariableW(L"VEYRA_TEST_REJECT_NR_DISABLE",nullptr,0)>0;
                if(injectedReject)veyra::log::error("settings-test","test-only reject NR-disable transaction before graph process; no driver failure");
                pipeline::EnhanceGraph::FgAdmission admitFg;
                // This capture pair's FG decision, for LiveFgRejectionHold.
                std::optional<pipeline::EnhanceGraph::FgDecision> capturePairDecision;
                const auto logAdmission=[&](const pipeline::FrameBatch& batch,int64_t now,int64_t deadline,double elapsed,double blit,bool admitted,bool warmingHistory,const char* timeline,int64_t firstDeadline=0,double queuedMs=0){
                    if(admitted)++fgAdmittedPairs;else ++fgRejectedPairs;
                    // Keep the first rejection even if the periodic sample just
                    // logged a success. Both channels remain rate bounded.
                    if(now<nextFgAdmissionLog&&(admitted||now<nextFgRejectionLog))return;
                    nextFgAdmissionLog=now+10000000;if(!admitted)nextFgRejectionLog=now+10000000;
                    veyra::log::info("live-fg-admission",std::format("timeline={} revision={} source={} multiplier={} requestedMultiplier={} admitted={} admittedPairs={} rejectedPairs={} remainingDeadlineMs={:.3f} firstDeadlineMs={:.3f} queuedGpuMs={:.3f} predictedMs={:.3f} elapsedMs={:.3f} blitGpuP95Ms={:.3f} presentCpuP95Ms={:.3f} warmingHistory={} (CPU Present is backpressure, not added GPU cost; firstDeadlineMs=-1 when unused)",timeline,batch.identity.settingsRevision,batch.identity.sourceFrameId,previewFgMultiplier,options.fgMultiplier,admitted,fgAdmittedPairs,fgRejectedPairs,double(deadline-now)/10000,firstDeadline?double(firstDeadline-now)/10000:-1,queuedMs,fgBudget.predicted(now,warmingHistory).value_or(-1),elapsed,blit,livePresent.p95(),warmingHistory));
                };
                if(fgBudgetRevision!=options.settings.revision||hardFrameReset){fgBudget.reset();vfgOverload.reset();vfgCostSettling.reset();vfgChosenFgMs=vfgFastFgMs=0;liveArrival.reset();pairLatency.reset();deadlineMargin.reset();fgRejectionHold.reset();fgBudgetRevision=options.settings.revision;displayFgGate.reset();}
                previewFgMultiplier=options.fgMultiplier;
                // An output cap used to only drop candidates at present time, so
                // the GPU still generated frames that were thrown away: at 6X on
                // a 100 Hz panel we generated ~360/s, submitted ~276/s, and the
                // panel could show at most 100 (measured 2026-09-22). Derive the
                // smallest multiplier whose output still reaches the cap and use
                // that instead. Only ever lowers, never raises, the multiplier the
                // user asked for; the present-time cap below stays as the residual
                // after this integer rounding.
                // PushFPS: the rate of new pictures, not the transport. A 30 FPS game in a
                // 60 Hz capture signal makes pairs 33 ms apart once duplicates are removed;
                // dividing the cap by the 60 Hz transport ran 120 FPS targets at 2X (60 FPS).
                // Unknown while dedup is still measuring (0): no reduction until then.
                const double pushContentFps=isImage?0.0:dedupActive?contentDedup.contentFps():
                    activeSource->info().averageFps*(halfRate?0.5:1.0);
                const bool pushAdaptive=options.fg&&options.settings.fgAdaptive&&!isImage&&options.fgMultiplier>2&&
                    !presentSinkFrameGeneration(options.settings.frameGenerationBackend);
                if(pushAdaptive!=pushAdaptiveWas){pushAdaptiveGate.reset();pushAdaptiveWas=pushAdaptive;}
                if(pushAdaptive){
                    // Target: the output cap when one is set, otherwise the display refresh.
                    const double refresh=displayFgTestHz>0?displayFgTestHz:presenter.displayRefreshHz();
                    const double target=presentationEffective.outputRate==OutputRateMode::Custom&&std::isfinite(presentationEffective.customFps)&&
                        presentationEffective.customFps>0?presentationEffective.customFps:refresh;
                    if(pushContentFps>0.01&&target>0.01){
                        bool changed=false;
                        const auto now100=host100ns();
                        previewFgMultiplier=pushAdaptiveGate.update(pushAdaptiveFgMultiplier(options.settings.frameGenerationBackend,options.fgMultiplier,pushContentFps,target),now100,&changed);
                        if(changed||now100>=nextPushAdaptiveLog){nextPushAdaptiveLog=now100+50000000;
                            veyra::log::info("push-adaptive-fg",std::format("revision={} backend={} ceiling={}X chosen={}X contentFps={:.2f} targetFps={:.2f} outputFps={:.2f} changed={}",
                                options.settings.revision,frameGenerationBackendName(options.settings.frameGenerationBackend),options.fgMultiplier,previewFgMultiplier,pushContentFps,target,pushContentFps*previewFgMultiplier,changed));}
                    }else if(pushAdaptiveGate.valid())previewFgMultiplier=pushAdaptiveGate.applied();
                }
                if(!pushAdaptive&&options.fg&&previewFgMultiplier>2&&presentationEffective.outputRate==OutputRateMode::Custom&&
                   !presentSinkFrameGeneration(options.settings.frameGenerationBackend)){
                    const double sourceFps=pushContentFps;
                    const double cap=presentationEffective.customFps;
                    if(sourceFps>0.01&&std::isfinite(cap)&&cap>0.0){
                        const auto needed=unsigned(std::ceil(cap/sourceFps-1e-6));
                        previewFgMultiplier=std::clamp(needed,2u,options.fgMultiplier);
                    }
                }
                // Live output hint: the panel cannot show more than one new picture
                // per refresh, so suggest a multiplier that fits (DisplayFgBudget.h).
                // The multiplier stays the user's choice (2026-10-14: hint, never
                // an automatic reduction). Tearing shows partial frames by choice.
                {
                    const bool hinted=isCapture&&!isImage&&options.fg&&options.fgMultiplier>1&&
                        presentationEffective.display!=DisplaySync::Tearing;
                    double contentFps=0,refreshHz=0;
                    // The monitor refresh is reported for EVERY source, not only
                    // capture ones: the automatic multiplier needs a target rate when
                    // the output cap is 关闭 (2026-10-24). It used to stay 0 for files
                    // because the hint below is capture-only.
                    if(!isImage)refreshHz=displayFgTestHz>0?displayFgTestHz:presenter.displayRefreshHz();
                    if(hinted){
                        // Content rate: 60->30 halves the transport; dedup uses its
                        // measured cadence and suggests nothing until it has one.
                        contentFps=dedupActive?contentDedup.contentFps():activeSource->info().averageFps*(halfRate?.5:1.0);
                        if(contentFps>0&&refreshHz>0&&displayFgGate.update(displayFgSuggestion(options.settings.frameGenerationBackend,options.fgMultiplier,contentFps,refreshHz,presentationVsync(presentationEffective)),host100ns())){
                            const auto hint=displayFgGate.applied();
                            veyra::log::info("display-fg-hint",std::format("revision={} backend={} requested={}X suggestion={} outputFps={:.3f} contentFps={:.3f} refreshHz={:.3f}{} dedup={} halfRate={} display={} (hint only: the multiplier is never changed automatically)",
                                options.settings.revision,frameGenerationBackendName(options.settings.frameGenerationBackend),options.fgMultiplier,hint==0?std::string("none"):hint==1?std::string("off"):std::format("{}X",hint),contentFps*options.fgMultiplier,contentFps,refreshHz,displayFgTestHz>0?" (test override)":"",dedupActive,halfRate,unsigned(presentationEffective.display)));
                        }
                    }else displayFgGate.reset();
                    std::lock_guard lock(mutex_);
                    snapshot_.displayFgSuggestion=hinted&&displayFgGate.valid()?displayFgGate.applied():0u;
                    snapshot_.displayFgRefreshHz=refreshHz;snapshot_.displayFgContentFps=contentFps;
                }
                {std::lock_guard lock(mutex_);snapshot_.previewFgMultiplier=previewFgMultiplier;}
                // A deduplicated packet spans the last kept frame. After OUR
                // mailbox miss that duration includes missing inputs, so it must
                // not stretch the next pair's scheduling phase and cause another
                // miss. The A/B timestamps used by interpolation stay untouched.
                const auto phaseDuration=dedupHoldInterval100ns>0?
                    pipeline::Rational{dedupHoldInterval100ns,10000000}:gapCandidate&&dedupActive?
                    pipeline::Rational{contentDedup.intervalHint(capturePeriod),10000000}:pkt.duration;
                const auto liveInterval=cardTiming?
                    // A span across frames WE skipped is not the source cadence. Using it
                    // stretched the next pair's presentation over the gap, which made
                    // the mailbox drop again: one background hiccup locked live capture
                    // at ~10 pairs/s (field log 2026-10-04, 60 -> 22 fps until refocus).
                    capturePairInterval100ns(phaseDuration,activeSource->info().averageFps,lastProcessedPtsMs,pts,historyReset||gapCandidate||dedupHoldInterval100ns>0):
                    livePhaseInterval100ns(pkt.duration,activeSource->info().averageFps/(isScreen&&halfRate?2:1),isScreen);
                const auto processingAllowance=isCapture&&options.fg&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend)?
                    fgBudget.processingAllowance(host100ns(),liveInterval):0;
                // Present-sink providers own subframe pacing after receiving B.
                // Graph FG needs the A/B presentation phase; provider FG does not.
                const auto legacyPairDelay=presentSinkFrameGeneration(options.settings.frameGenerationBackend)?0:liveInterval+processingAllowance;
                // Dedup corrects the content PTS, but the kept callbacks can still arrive
                // 17/33 ms apart for a 40 fps game. Map both times through the capture clock.
                const bool smoothAnchor=pairAnchoredLive&&options.fg&&!isStream&&!legacyLivePacing&&
                    !presentSinkFrameGeneration(options.settings.frameGenerationBackend);
                const bool smoothTransportAnchor=smoothAnchor&&!dedupActive;
                const bool smoothContentAnchor=smoothAnchor&&dedupActive&&cardTiming&&!pkt.pts.isUnknown();
                const auto transportInterval=smoothContentAnchor?
                    liveSourceInterval100ns(pipeline::Rational::unknown(),activeSource->info().averageFps):0;
                const bool marginPair=adaptiveCapturePhase&&options.fg&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend);
                const int64_t pairExtra=marginPair?deadlineMargin.extra():0;
                // Room for the generated frames' own interpolation past interval + base cost.
                // Deduplicated pairs keep only their content-clock allowance: it already
                // covered the FG cost (auto + VFG high/high+low, 2026-11-13: no GPU-late
                // generated frames before this change), so their bound stays as it was;
                // the FG allowance is for 60->30 and transport pairs.
                const int64_t fgPhaseAllowance=marginPair&&!smoothContentAnchor?fgBudget.phaseAllowance(host100ns(),liveInterval):0;
                // PushFlow 2's Predict (opt-in): the real frame is shown first and the generated frames are
                // forecasts after it, so the pair waits only for its own processing, never a frame interval.
                // It steps aside while the quality test, a benchmark window or the optimiser measures in-between frames.
                if(graph)graph->setPushFlowPredictPaused(quality_->running()||pushBenchmarkProbe().active()||pushflow2::predictPaused());
                const bool predictPair=isCapture&&options.fg&&graph&&graph->pushFlowPredicting();
                const auto pairDelay=predictPair?processingAllowance+pairExtra:marginPair?
                    pairLatency.select(host100ns(),legacyPairDelay,liveInterval,previewFgMultiplier,std::max(transportInterval/2,fgPhaseAllowance))+pairExtra:legacyPairDelay;
                std::optional<int64_t> pairPresentAnchor;
                const auto presentAnchorFor=[&](int64_t source){
                    if(!pairPresentAnchor){
                        if(smoothContentAnchor)
                            pairPresentAnchor=liveArrival.contentAnchor(source,samplePts100ns,liveInputReady,transportInterval);
                        else
                            pairPresentAnchor=smoothTransportAnchor?liveArrival.anchor(source,liveInputReady,liveInterval):liveInputReady;
                    }
                    return *pairPresentAnchor;
                };
                // DLSS can reseed after a skipped pair. XeSS
                // owns generation inside its presenter and has no graph admission.
                if(isCapture&&!rereadCached&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend)){
                    const auto presentP95=livePresentGpu.p95();
                    admitFg=[&,presentP95](const pipeline::FrameBatch& batch,bool warmingHistory){
                        // Physical capture and PS5 delivery clocks are not
                        // guaranteed to match the host clock. Anchor each new
                        // input pair before enhancement, so a 59.94-vs-60Hz
                        // mismatch cannot accumulate into a stale deadline.
                        // Never extend it based on processing/ready completion.
                        // Admission asks whether this pair's own frames can make
                        // it, so it keeps the callback; LiveArrivalSmoother moves
                        // only the presentation anchor set below.
                        if(pairAnchoredLive)liveTimeline.resetPair(batch.identity.epoch,batch.b100ns,liveInputReady,pairDelay);
                        else if(!liveTimeline.anchored(batch.identity.epoch))liveTimeline.reset(batch.identity.epoch,batch.b100ns,liveInputReady,liveSourceInterval100ns(pkt.duration,activeSource->info().averageFps));
                        const auto interval=liveInterval;
                        const auto a=(historyReset||batch.b100ns<=batch.a100ns||batch.b100ns-batch.a100ns>10000000)?batch.b100ns-interval:batch.a100ns;
                        // With Predict the group must be done for its first forecast, which follows the real frame.
                        const auto firstForecast=predictPair?pushflow::predict::pts(a,batch.b100ns,1,previewFgMultiplier):0;
                        const auto lastGenerated=firstForecast>0?firstForecast:pipeline::FrameBatch::interpolate(a,batch.b100ns,previewFgMultiplier-1,previewFgMultiplier);
                        const auto now=host100ns(),deadline=liveTimeline.deadline(lastGenerated);
                        const double elapsed=elapsedMs(processStart);
                        const bool admitted=!vfgCostSettling.holding(now)&&fgBudget.admit(now,deadline,elapsed,presentP95,warmingHistory);
                        logAdmission(batch,now,deadline,elapsed,presentP95,admitted,warmingHistory,pairAnchoredLive?(isStream?"decoded-pair":"capture-pair"):"continuous");
                        auto decision=admitted?pipeline::EnhanceGraph::FgDecision::Evaluate:pipeline::EnhanceGraph::FgDecision::Skip;
                        // Both transport and deduplicated content anchors have a mapped host deadline.
                        // 30 FPS console content in a 60 Hz capture feed uses the latter.
                        // Keep the existing user switch, warmup guard and deadline checks.
                        if((smoothTransportAnchor||smoothContentAnchor)&&options.settings.vfgAutoRegulate&&previewFgMultiplier==2&&!warmingHistory&&graph->vfgFastReady()){
                            const double base=fgBudget.baseCost(now).value_or(0),progress=std::clamp(elapsed,0.0,base),blit=std::max(0.0,presentP95);
                            if(!admitted){
                                if(double(deadline-now)/10000+10>=std::max(0.0,base+vfgFastFgMs-progress)+blit)decision=pipeline::EnhanceGraph::FgDecision::FastForBudget;
                            }else if(vfgChosenFgMs>0&&presentationEffective.display!=DisplaySync::Tearing&&!presenter.vrrSync()){
                                const auto grid=presenter.refreshGrid();
                                // A time too high would never be corrected without running the
                                // model: after 4 s without it, try where 30% less would make it.
                                // 1 ms keeps clear of the refresh edge: the faster model costs nothing there.
                                const double chosen=now-vfgChosenAt>=40000000?vfgChosenFgMs*.7:vfgChosenFgMs;
                                const auto ready=now+int64_t((std::max(0.0,base+chosen-progress)+blit+1)*10000);
                                if(now-grid.lastVblank100ns<10000000&&liveFramesShareRefresh(ready,presentAnchorFor(batch.b100ns)+pairDelay,grid.lastVblank100ns,grid.period100ns,grid.latch100ns))decision=pipeline::EnhanceGraph::FgDecision::Fast;
                            }
                            if(decision==pipeline::EnhanceGraph::FgDecision::Fast)++vfgFastPairs;
                            else if(decision==pipeline::EnhanceGraph::FgDecision::FastForBudget)++vfgFastBudgetPairs;
                            if(now>=nextVfgFastLog&&(vfgFastPairs||vfgFastBudgetPairs)){
                                nextVfgFastLog=now+10000000;
                                veyra::log::info("vfg-fast",std::format("revision={} refreshPairs={} budgetPairs={} chosenPairs={} chosenFgMs={:.2f} fastFgMs={:.2f} latchMs={:.2f} contentClock={} (session totals: pairs run with the next faster model because the chosen one would miss the refresh or the budget, and pairs run with the chosen one)",options.settings.revision,vfgFastPairs,vfgFastBudgetPairs,vfgChosenPairs,vfgChosenFgMs,vfgFastFgMs,presenter.refreshGrid().latch100ns/10000,smoothContentAnchor));
                            }
                        }
                        capturePairDecision=decision;
                        return decision;
                    };
                }
                // File playback checks both the first output and whole-group
                // deadlines against the audio clock, including older queued
                // GPU work. The real frame retains its original media PTS.
                double queuedGpuMs=0;
                if(!isCapture&&!isImage&&!rereadCached&&!transaction&&options.fg&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend)){
                    {
                        const auto start=std::chrono::duration_cast<std::chrono::nanoseconds>(processStart.time_since_epoch()).count()/100;
                        int64_t finish=0;
                        for(const auto& previous:pendingCompletions){
                            if(previous->output.gpuComplete())continue;
                            const auto began=std::chrono::duration_cast<std::chrono::nanoseconds>(previous->processStart.time_since_epoch()).count()/100;
                            auto cost=previous->output.fgEvaluated?fgBudget.predicted(start,previous->output.historyReset||previous->output.fgRecovery):fgBudget.baseCost(start);
                            if(vfgMeasuredReducedQueue&&options.settings.frameGenerationBackend==FrameGenerationBackend::Vfg&&previous->output.fgReduced){
                                const auto first=frameFlow->snapshot(start).gpuTiming[size_t(diagnostics::GpuStage::Fg1)].p95;
                                const auto measured=vfgQueuedGroupCost(cost,fgBudget.baseCost(start),first,true,previous->output.fgEvaluated,previous->output.historyReset||previous->output.fgRecovery);
                                if(cost&&measured&&*measured<*cost&&start>=nextVfgQueueLog){nextVfgQueueLog=start+10000000;
                                    veyra::log::info("vfg-queue-budget",std::format("source={} queuedReduced=2X requested={} fullEstimateMs={:.3f} singleEstimateMs={:.3f} (base plus measured first interpolation; deadlines unchanged)",previous->output.batch.identity.sourceFrameId,options.fgMultiplier,*cost,*measured));}
                                cost=measured;
                            }
                            finish=std::max({finish,began,previous->predictedGpuStart100ns})+int64_t(cost.value_or(0)*10000);
                        }
                        queuedGpuMs=double(std::max<int64_t>(0,finish-start))/10000;
                    }
                    admitFg=[&,historyReset,queuedGpuMs](const pipeline::FrameBatch& batch,bool warmingHistory){
                        if(fileAwaitingVideo)return pipeline::EnhanceGraph::FgDecision::Evaluate; // Bounded startup lookahead; audio has not started.
                        const auto interval=liveSourceInterval100ns(pkt.duration,activeSource->info().averageFps);
                        const auto a=(historyReset||batch.b100ns<=batch.a100ns||batch.b100ns-batch.a100ns>10000000)?batch.b100ns-interval:batch.a100ns;
                        const auto lastGenerated=pipeline::FrameBatch::interpolate(a,batch.b100ns,previewFgMultiplier-1,previewFgMultiplier);
                        const auto now=host100ns();
                        const auto media=int64_t(nowMs()*10000.0);
                        const auto firstPts=pipeline::FrameBatch::interpolate(a,batch.b100ns,1,previewFgMultiplier);
                        const auto firstDeadline=now+int64_t((firstPts-media)/playbackRate),deadline=now+int64_t((lastGenerated-media)/playbackRate);
                        const auto first=frameFlow->snapshot(now).gpuTiming[size_t(diagnostics::GpuStage::Fg1)].p95;
                        const auto elapsed=elapsedMs(processStart),blit=livePresentGpu.p95();
                        const auto outputInterval=int64_t(interval/playbackRate)/previewFgMultiplier;
                        bool retainedFits=true;
                        if(vfgRetainOverload&&options.settings.frameGenerationBackend==FrameGenerationBackend::Vfg&&!warmingHistory){
                            const auto base=fgBudget.baseCost(now),whole=fgBudget.predicted(now,false);
                            // Only replace the missing FG component; a fresh full
                            // sample still uses the original shared admission.
                            if(base&&whole&&*whole<=*base+0.000001){
                                const auto retained=vfgOverload.severeTotal(base,first,double(interval)/10000/playbackRate);
                                if(retained){
                                    retainedFits=VfgOverloadEstimate::fits(*retained,*base,double(deadline-now)/10000,double(outputInterval)/10000,elapsed,queuedGpuMs,blit);
                                    if(!retainedFits&&now>=nextVfgOverloadLog){nextVfgOverloadLog=now+10000000;
                                        veyra::log::info("vfg-overload-budget",std::format("source={} requested={} fullCostExpired=1 retainedTotalEstimateMs={:.3f} currentFirstGpuP95Ms={:.3f} (retained estimate, not new GPU sample; deadlines unchanged)",batch.identity.sourceFrameId,options.fgMultiplier,*retained,*first));}
                                }
                            }
                        }
                        const auto originalAdmission=fgBudget.admitFile(now,firstDeadline,deadline,outputInterval,elapsed,blit,first,warmingHistory,queuedGpuMs,options.settings.fgStrictAdmission);
                        const bool overloadProbe=originalAdmission&&!retainedFits&&vfgOverload.allowProbe(now);
                        if(overloadProbe)veyra::log::info("vfg-overload-probe",std::format("source={} requested={} probeIntervalMs=30000 (one full group using original admission; no deadline extension)",batch.identity.sourceFrameId,options.fgMultiplier));
                        const auto admitted=originalAdmission&&(retainedFits||overloadProbe);
                        logAdmission(batch,now,deadline,elapsed,blit,admitted,warmingHistory,"file-audio",firstDeadline,queuedGpuMs);
                        if(admitted)return pipeline::EnhanceGraph::FgDecision::Evaluate;
                        // Over budget for the full group: emit a presentable 2X
                        // midpoint instead of a whole-group hole.
                        // ON by default. Measured 2026-09-22, same slot,
                        // interleaved, 2 reps (tests/.../b10/gaps-ab-*), 100 Hz
                        // panel, per DXGI GetFrameStatistics:
                        //   native 6X   displayed 100.3/s both ways,
                        //               intervals >16.67 ms  34 -> 0
                        //   video SR 6X displayed 100.7/s both ways,
                        //               intervals >16.67 ms 150 -> 90,
                        //               gpuReadyP95 25.5 -> 22.7 ms
                        // It submits ~10 fewer frames per second, but every one
                        // of those was discarded before scanout (notDisplayed
                        // 192 vs 183), and refreshesWithoutNewFrame is 0 either
                        // way. Judge this by displayed frames and interval
                        // evenness, never by submitted frames: at 6X on a
                        // 100 Hz panel submission oversupplies by ~3x, so a
                        // submitted-frame count says nothing about what is seen.
                        // VEYRA_TEST_FG_NO_REDUCED=1 disables it for A/B runs.
                        static const bool reducedGroups=GetEnvironmentVariableW(L"VEYRA_TEST_FG_NO_REDUCED",nullptr,0)==0;
                        if(reducedGroups&&!warmingHistory&&previewFgMultiplier>2){
                            const auto midpoint=now+int64_t((pipeline::FrameBatch::interpolate(a,batch.b100ns,1,2)-media)/playbackRate);
                            if(fgBudget.canAdmitReduced(now,midpoint,int64_t(interval/playbackRate)/2,elapsed,blit,first,queuedGpuMs)){
                                ++fgReducedPairs;
                                if(now>=nextFgReducedLog){nextFgReducedLog=now+10000000;
                                    veyra::log::info("live-fg-admission",std::format("timeline=file-audio revision={} source={} reduced=2X requestedMultiplier={} reducedPairs={} remainingMidpointMs={:.3f} predictedFullMs={:.3f} (history kept; presentable midpoint instead of whole-group hole)",batch.identity.settingsRevision,batch.identity.sourceFrameId,options.fgMultiplier,fgReducedPairs,double(midpoint-now)/10000,fgBudget.predicted(now,false).value_or(-1)));}
                                return pipeline::EnhanceGraph::FgDecision::Reduced;
                            }
                        }
                        if(!warmingHistory&&fgBudget.canAdmit(now,deadline,elapsed,blit,true,queuedGpuMs))
                            return pipeline::EnhanceGraph::FgDecision::Seed;
                        return pipeline::EnhanceGraph::FgDecision::Skip;
                    };
                }
                uint64_t processWaitBase=0,processSubmitBase=0;double processWaitMsBase=0,processSlotWaitMs=0;
                if(resetRecord&&resetRecord->epoch==0)resetStageStart=Clock::now();
                // Bounded integration-test delay on the owner thread. It
                // exercises missed deadlines and recovery without changing
                // settings/history or inventing GPU execution timestamps.
                wchar_t testWork[16]{};
                const auto currentReflexFrame=(!paused_&&!isImage)?presenter.beginReflex():0;
                if(!isImage&&GetEnvironmentVariableW(L"VEYRA_TEST_VIDEO_WORK_MS",testWork,16))std::this_thread::sleep_for(std::chrono::milliseconds(std::clamp(_wtoi(testWork),0,150)));
                loopTrace.mark("prepare");
                if(!presenter.beginSourceProcessing()){status(L"XeSS processing timing failed",true);break;}
                bool processed=false;{
                    processWaitBase=ring.cpuWaitCount();processWaitMsBase=ring.cpuWaitMilliseconds();processSubmitBase=ring.submitCount();
                    processingGraph=true;
                    {OnExit processingDone{[&]{processingGraph=false;}};
                    // The first checkpoint: a frame due before the graph's first one.
                    if(!historyReset)presentDuringProcess();
                    processed=!injectedReject&&graph->process(frame,pts,historyReset,out,pkt.sequence,&pkt.colorInfo,&pkt.hardwareSurface,comparisonMode_!=0||recordings_.wantsRawFrames(),admitFg,previewFgMultiplier,(paused_||isImage)&&transaction,presentDuringProcess,pkt.doviEl,&pkt.doviP7);}
                    presenter.endReflex(currentReflexFrame);
                    processSlotWaitMs=ring.cpuWaitMilliseconds()-processWaitMsBase;
                }
                loopTrace.mark("graphSubmit");
                previewSkipSinceProcess=false;
                if(processed)lastProcessedPtsMs=pts;
                if(!processed){
                    const auto failedComponent=graph->failedBackend();
                    if(!transaction){
                        auto reduced=options.snapshot();
                        if(SUCCEEDED(ctx.device()->GetDeviceRemovedReason())&&disableFailedBackend(reduced,failedComponent)){
                            const auto attempted=options.snapshot();
                            drainLivePresentation();
                            if(!ring.drainQueue()||!ring.discardRecording()){status(L"增强故障恢复排空失败",true);break;}
                            if(!presenter.prepareGraphChange()){status(L"增强故障恢复排空失败",true);break;}
                            out={};hasOutput=false;graph->shutdown();
                            {std::lock_guard lock(mutex_);reduced.revision=++nextRevision_;}
                            options=PlayerOptions::from(reduced,options.nodeOrder,&options);
                            describeStages(stageRequest(options),options.snapshot(),gd);
                            if(!initializePreview(gd,options)){if(!stop_)status(L"增强故障后的基础图重建失败",true);break;}
                            publishFrameGenerationCapabilities();
                            const bool mlToFsr3=failedComponent==FailedBackend::Fg&&attempted.frameGenerationBackend==FrameGenerationBackend::Fsr4&&
                                options.settings.frameGenerationBackend==FrameGenerationBackend::Fsr;
                            backendRecoveryWarning=(mlToFsr3?std::wstring(L"FSR 4 ML 运行失败，已改用 FSR 3.1；错误码见日志"):
                                std::wstring(backendFailureName(failedComponent))+L"运行失败，已关闭对应效果；错误码见日志")+(backendRecoveryWarning.empty()?L"":L"；"+backendRecoveryWarning);
                            {std::lock_guard lock(mutex_);desired_.rejectVideoRequest(attempted,options.snapshot());snapshot_.desired=desired_;snapshot_.applied=options.snapshot();snapshot_.rejectedRevision=attempted.revision;snapshot_.applying=desired_!=snapshot_.applied;snapshot_.backendWarning=backendRecoveryWarning;}
                            veyra::log::warn("backend-recovery",std::format("runtime component={} disabled; rebuilt revision={} nr={} sr={} multiplier={}; retry next source frame",unsigned(failedComponent),options.settings.revision,options.nr,options.sr,options.snapshot().multiplier));
                            finishReset(diagnostics::ResetOutcome::Failed);reset=true;pendingResetCause=pipeline::ResetReason::Settings;
                            holdFileAudio();fileAudioAlignPending=true;
                            continue;
                        }
                    }
                    if(transaction){
                        if(!ring.drainQueue()||!presenter.prepareGraphChange()){status(L"设置恢复呈现排空失败，已停止",true);break;}
                        out={};graph->shutdown();recentGraphCache.evict("process-rollback");
                        graph=std::make_unique<pipeline::EnhanceGraph>(ctx,ring,&coreCache);graphBytes=0;options=PlayerOptions::from(previous,previousOrder);
                        gd=previousDesc;
                        if(graph->initialize(gd)&&openPreparedPresenter(options)&&graph->process(frame,pts,true,out,pkt.sequence,&pkt.colorInfo,&pkt.hardwareSurface,comparisonMode_!=0||recordings_.wantsRawFrames(),{},0,false,{},pkt.doviEl,&pkt.doviP7)){
                            publishFrameGenerationCapabilities();
                            finishReset(diagnostics::ResetOutcome::RolledBack);
                            std::lock_guard lock(mutex_);if(desired_.revision==requested.revision)desiredNodeOrder_=previousOrder;desired_.rejectVideoRequest(requested,previous);snapshot_.desired=desired_;snapshot_.rejectedRevision=requested.revision;snapshot_.applying=desired_!=previous;snapshot_.status=L"参数执行失败，已整套回滚";transaction=false;
                        }else{if(!stop_)status(L"参数回滚失败，已停止",true);break;}
                    }else{
                        // Custom: a bare "failed; see the log" leaves the user with
                        // nothing to do. Name the likely cause and the action that
                        // actually recovers it, per backend.
                        std::wstring advice;
                        switch(failedComponent){
                        case FailedBackend::Infrastructure:
                            advice=L"。常见原因是硬件解码器分配内存失败（4K 片源居多）：关闭后重开播放器可恢复；"
                                   L"若反复出现，可在 设置→播放 把解码改成「软件」";
                            break;
                        case FailedBackend::VideoHdr:
                            advice=L"。RTX Video HDR 未能启动：可在设置里关闭该效果，或更新 NVIDIA 驱动";
                            break;
                        case FailedBackend::OpticalFlow:
                            advice=L"。光流后端不可用：可在设置里改用 AMD FidelityFX 或关闭相关效果";
                            break;
                        default:
                            advice=L"；详细原因见日志";
                            break;
                        }
                        status(std::wstring(backendFailureName(failedComponent))+L"执行失败"+advice,true);
                        break;
                    }
                }
                if(veyra::log::verboseFrameLogs())veyra::log::info("source-identity",std::format("source={} totalRead={} graphProcessed={} cached={} revision={} nvofStandalone={}",pkt.sequence,sourceFrames,frames+1,rereadCached,options.settings.revision,gd.enableNvofStandalone));
                // Custom: hand this source frame's Dolby Vision level 1 to the
                // presenter, which will show this batch next. The value only
                // moves the highlight curve, and only when the follow switch is
                // on; an invalid value leaves the static curve untouched.
                presenter.setFrameDovi(pkt.dovi);
                presenter.sourceProcessed(out.batch.identity);
                if(out.fgReduced||previewFgMultiplier!=options.fgMultiplier){std::lock_guard lock(mutex_);snapshot_.previewFgMultiplier=out.fgReduced?2u:previewFgMultiplier;}
                reset=false;hasOutput=true;
                const auto processDone=Clock::now();
                if(physicalCapture&&veyra::log::verboseFrameLogs())veyra::log::info("capture-graph-sample",std::format("source={} epoch={} revision={} arrival={} start={} submitted={} slotWaitMs={:.6f}",pkt.sequence,out.batch.identity.epoch,out.batch.identity.settingsRevision,captureArrival,std::chrono::duration_cast<std::chrono::nanoseconds>(processStart.time_since_epoch()).count()/100,std::chrono::duration_cast<std::chrono::nanoseconds>(processDone.time_since_epoch()).count()/100,processSlotWaitMs));
                // The restored graph's first frame has empty temporal history.
                // It is the failed transaction's rollback warmup, not another
                // successful user reset that may overwrite the failure record.
                const bool restoredWarmup=rollbackWarmupPending&&
                    (pendingResetCause==pipeline::ResetReason::None||pendingResetCause==pipeline::ResetReason::Settings);
                rollbackWarmupPending=false;
                if(!resetRecord&&out.historyReset&&!previewOnlyReset&&!restoredWarmup){
                    resetStart=processStart;resetStageStart=processStart;
                    resetRecord=diagnostics::FrameFlowMetrics::ResetRecord{};resetRecord->sessionId=runSessionId;resetRecord->settingsRevision=out.batch.identity.settingsRevision;resetRecord->epoch=out.batch.identity.epoch;resetRecord->sourceFrameId=out.batch.identity.sourceFrameId;resetRecord->reason=static_cast<uint8_t>(diagnostics::resetCause(pkt.flags,pendingResetCause,out.detectedReset));
                    resetRecord->stageMs[size_t(diagnostics::ResetStage::Drain)]=0.0;resetRecord->stageMs[size_t(diagnostics::ResetStage::Destroy)]=0.0;resetRecord->stageMs[size_t(diagnostics::ResetStage::Create)]=0.0;
                    resetRecord->rebuilt=false;markResetStage(diagnostics::ResetStage::Warmup);
                    if(frameFlow)frameFlow->resetLifecycle(*resetRecord);
                }
                if(resetRecord&&resetRecord->epoch==0){
                    resetRecord->epoch=out.batch.identity.epoch;resetRecord->sourceFrameId=out.batch.identity.sourceFrameId;
                    markResetStage(diagnostics::ResetStage::Warmup);
                }
                pendingResetCause=pipeline::ResetReason::None;
                if(!frameFlow||metricsRevision!=options.settings.revision||metricsEpoch!=metricsWindowEpoch){
                    const bool settingsChanged=metricsRevision!=options.settings.revision;
                    metricsRevision=options.settings.revision;metricsEpoch=metricsWindowEpoch;statsStart=Clock::now();statsSourceBase=sourceFrames-uint64_t(!rereadCached);
                    slotWaitBase=processWaitBase;slotWaitMsBase=processWaitMsBase;submitBase=processSubmitBase;
                    captureAges.clear();scheduleWaits.clear();processTimes.clear();presentTimes.clear();decodeTimes.clear();gpuReadyTimes.clear();for(auto& window:gpuStageTimes)window.clear();lastGpuSampleEnd={};presentEntryDeviation.clear();presentReturnDeviation.clear();submissionTimes.clear();submitted=expired=0;
                    // Admission predictions and the XeSS gate must not carry
                    // samples across a settings revision (new backend/dimensions);
                    // soft preview-skip history breaks do NOT reopen them.
                    if(settingsChanged)xessSubmissions.reset(presenter.generation(),presenter.xessPresentedCount(),presenter.xessGeneratedCount());
                    playbackSpeedLastWall={};
                    if(liveScheduler){liveStats={};liveSubmissions.clear();liveAges.clear();liveWaits.clear();livePresent.clear();livePresentGpu.clear();liveReady.clear();}
                    if(settingsChanged||!completionRates)completionRates=std::make_shared<FrameCompletionRates>(host100ns());
                    frameFlow=std::shared_ptr<FrameFlowWindow>(new FrameFlowWindow(runSessionId,out.batch.identity,host100ns(),completionRates),[](FrameFlowWindow* window){logFrameFlow(window->snapshot(monotonic100ns()),"closed");delete window;});
                    if(resetRecord)frameFlow->resetLifecycle(*resetRecord);else if(lastResetRecord)frameFlow->resetLifecycle(*lastResetRecord);
                    frameFlow->update([&](auto& m){m.counters.settingsResets+=uint64_t(settingsChanged);});
                    captureFlowBase=captureFlowLast;
                    // The published totals belong to the window that counted them. A UI poll between
                    // this switch and the next publish must not pair the new window with the previous
                    // revision's counts ("disabled revision cannot retain prior generated-frame count").
                    {std::lock_guard lock(mutex_);rateSkippedBase=snapshot_.captureRateSkipped;activeFlow_=frameFlow;snapshot_.metrics.sourceFrames=snapshot_.metrics.validGenerated=snapshot_.metrics.submitted=snapshot_.metrics.expired=0;}
                    veyra::log::info("metrics",std::format("reset session={} appliedRevision={} epoch={} sourceBase={}",runSessionId,metricsRevision,metricsEpoch,statsSourceBase));
                }
                // Published after the metrics window switch above: a snapshot that already reports
                // the new revision never carries the previous revision's totals. The publish of
                // this frame's metrics can be a while later.
                if(transaction||pendingSettingsAck){std::lock_guard lock(mutex_);snapshot_.applied=options.snapshot();snapshot_.applying=desired_!=snapshot_.applied;pendingSettingsAck=false;snapshot_.status=std::format(L"输入 {}×{} / 底图 {}×{} / NR {}×{} / 光流 {}×{} / FG与输出 {}×{} | {}",width,height,gd.workWidth,gd.workHeight,gd.nrWidth,gd.nrHeight,gd.flowWidth,gd.flowHeight,gd.workWidth,gd.workHeight,gd.nrBeforeSr?L"低延迟 · NR先行后超分":gd.nrWidth<gd.workWidth?L"实时内部处理并回填":L"原生NR（性能成本较高）");veyra::log::info("display-color",std::format("hdrInput={} hdrOutput={} forceSdrPreview={}",gd.hdrInput,gd.hdrOutput,options.settings.forceSdrPreview));veyra::log::info("settings",std::format("Applied revision={} sourcePtsMs={} fgBackend={} flowBackend={} multiplier={} (source kept open)",options.settings.revision,pts,frameGenerationBackendName(options.settings.frameGenerationBackend),opticalFlowBackendName(options.settings.opticalFlowBackend),options.snapshot().multiplier));}
                const double processMs=std::chrono::duration<double,std::milli>(processDone-processStart).count();
                frameFlow->advanceHistory(out.batch.identity);
                frameFlow->update([&](auto& m){m.counters.historyResets+=uint64_t(out.historyReset);m.counters.captureDropResets+=uint64_t(pipeline::hasFrameFlag(pkt.flags,pipeline::FrameFlagBits::Drop));});
                const auto lineage=lineageTracker.observe(out.batch,sourceArrival,pkt.arrivalHost100ns>0,rereadCached||isImage);
                if(lineage&&out.hasGenerated){
                    frameFlow->pairArrived(*lineage);
                    if(veyra::log::verboseFrameLogs())veyra::log::info("frame-lineage",std::format("batch={} epoch={} revision={} sourceA={} sourceB={} ptsA={} ptsB={} arrivalA={} arrivalB={} captureCallbacks={}",out.batch.batchId,out.batch.identity.epoch,out.batch.identity.settingsRevision,lineage->a.identity.sourceFrameId,lineage->b.identity.sourceFrameId,lineage->a.pts100ns,lineage->b.pts100ns,lineage->a.host100ns,lineage->b.host100ns,lineage->a.captureCallback&&lineage->b.captureCallback));
                }
                processTimes.add(processMs);
                traceFrame(diagnostics::TraceKind::Submitted,out.batch.identity,out.batch.batchId,std::max(out.videoFenceValue,out.genFenceValue),out.batch.b100ns,out.fgSkippedBeforeEval,out.fgEvaluated,processMs);
                frameFlow->cpu(diagnostics::CpuStage::Decode,decodeMs,host100ns());
                if(isStream&&pkt.decodedHost100ns>0&&!rereadCached)frameFlow->cpu(diagnostics::CpuStage::DecodedQueue,std::max(0.0,double(std::chrono::duration_cast<std::chrono::nanoseconds>(decodeStart.time_since_epoch()).count()/100-pkt.decodedHost100ns)/10000),host100ns());
                frameFlow->update([&](auto& m){m.lastSubmit100ns=host100ns();});
                frameFlow->cpu(diagnostics::CpuStage::Submit,processMs,host100ns());
                frameFlow->cpu(diagnostics::CpuStage::SlotWait,processSlotWaitMs,host100ns());
                frameFlow->update([&](auto& m){m.latest.frame=out.batch.identity;m.latest.batchId=out.batch.batchId;m.latest.readyFence=std::max(out.videoFenceValue,out.genFenceValue);m.counters.sourceAccepted+=!rereadCached;++m.counters.realSubmitted;m.counters.previewSkippedBeforeGraph+=previewSkippedSinceSubmit;m.counters.fgCandidate+=out.fgCandidates;m.counters.fgEvaluated+=out.fgEvaluated;m.counters.fgSkippedForReset+=out.fgSkippedForReset;m.counters.fgSkippedBeforeEval+=out.fgSkippedBeforeEval;m.counters.fgReduced+=uint64_t(out.fgReduced);if(out.fgSkippedBeforeEval||out.fgBudgetSeed)m.lastFgRejected100ns=host100ns();if(!out.hasGenerated)m.counters.fgWarmup+=out.fgEvaluated;});
                previewSkippedSinceSubmit=0;
                if(transaction||frames==0){
                    std::lock_guard lock(mutex_);snapshot_.captureHalfRate=halfRate;
                    veyra::log::info("capture-rate",std::format("revision={} requested60To30={} active={} transportFps={} originalPtsPreserved={}",options.settings.revision,options.settings.content==ContentRate::Capture60To30,halfRate,isCapture?activeSource->info().averageFps:0,!captureClockCorrected));
                }
                const bool pairPacing=pairAnchoredLive&&options.fg;
                // File replay has no device pacing and still needs its PTS clock.
                // Physical and screen capture without FG present as soon as ready.
                const bool paceSourcePts=livePacesSourcePts(options.fg,physicalCapture,isScreen);
                if(isCapture&&!rereadCached&&(isStream||pairPacing||!liveTimeline.anchored(out.batch.identity.epoch,paceSourcePts))){
                    const auto duration100ns=liveSourceInterval100ns(pkt.duration,activeSource->info().averageFps);
                    if(!liveTimeline.anchored(out.batch.identity.epoch,paceSourcePts)||(pairPacing&&frames==0))veyra::log::info("capture-timeline",std::format("interval100ns={} packetDurationKnown={} packetDurationPositive={} nominalFps={} FG={} pacing={}",duration100ns,!pkt.duration.isUnknown(),pkt.duration.num>0,activeSource->info().averageFps,options.fg,pairPacing?(isRemote?"decoded-pair":"capture-pair"):paceSourcePts?"source-pts":"capture-ready"));
                    if(pairPacing||isStream){
                        // LiveFgRejectionHold: after a second of FG rejections the real frame goes
                        // out when ready. Admission above still used the FG phase.
                        bool fgHeld=false;
                        if(marginPair&&capturePairDecision){
                            const bool wasHeld=fgRejectionHold.held();
                            const bool admittedPair=*capturePairDecision!=pipeline::EnhanceGraph::FgDecision::Skip;
                            fgHeld=fgRejectionHold.observe(host100ns(),admittedPair);
                            fgHeldPairs+=fgHeld;fgHeldProbes+=fgHeld&&admittedPair;
                            if(wasHeld!=fgRejectionHold.held())
                                veyra::log::info("live-fg-hold",std::format("revision={} held={} source={} heldPairs={} heldProbes={} (FG rejected for {:.0f} s: real frames shown when ready instead of on the FG phase; pairs admitted while held expire their generated frames; {} admitted pairs in a row resume)",
                                    options.settings.revision,fgRejectionHold.held(),out.batch.identity.sourceFrameId,fgHeldPairs,fgHeldProbes,double(LiveFgRejectionHold::kHold100ns)/1e7,LiveFgRejectionHold::kResumePairs));
                        }
                        // Keep the smoother learning while held.
                        const auto smoothedAnchor=presentAnchorFor(out.batch.b100ns);
                        const auto presentAnchor=fgHeld?liveInputReady:smoothedAnchor;
                        liveGeneratedGrace=liveGeneratedGrace100ns(liveInputReady,presentAnchor);
                        liveTimeline.resetPair(out.batch.identity.epoch,out.batch.b100ns,presentAnchor,options.fg&&!fgHeld?pairDelay:0,paceSourcePts);
                        // Predict: when this real frame is due, for the forecasts of the frame before it (above).
                        if(predictPair||out.fgPredict){predictNewestReal100ns_=out.batch.b100ns;predictNewestDue100ns_=liveTimeline.deadline(out.batch.b100ns);}
                        const bool smoothedCapacity=smoothTransportAnchor||smoothContentAnchor;
                        if(smoothedCapacity&&host100ns()>=nextLiveAnchorLog){
                            nextLiveAnchorLog=host100ns()+10000000;
                            veyra::log::info("live-anchor",std::format("revision={} contentClock={} callbackJitterMs={:.3f} clockDriftPpm={:.0f} snaps={} callbackMinusAnchorMs={:.3f} phaseMs={:.3f} deadlineExtraMs={:.3f} fgPhaseAllowanceMs={:.3f} fgHeld={} capacityWaitMs={:.2f} (presentation anchor: source or deduplicated content PTS on the tracked capture clock; fgHeld: real frame shown when ready, phase unused; capacity wait applies under explicit VSync)",options.settings.revision,smoothContentAnchor,liveArrival.jitterMs(),liveArrival.driftPpm(smoothContentAnchor?transportInterval:liveInterval),liveArrival.snaps(),double(liveInputReady-presentAnchor)/10000,double(pairDelay)/10000,double(pairExtra)/10000,double(fgPhaseAllowance)/10000,fgHeld,liveSmoothedCapacityWaitMs(double(liveInterval)/10000/std::max(1u,previewFgMultiplier),fixedCapacityWait?0:liveArrival.jitterMs())));
                        }
                    }
                    else if(!liveTimeline.anchored(out.batch.identity.epoch,paceSourcePts))liveTimeline.reset(out.batch.identity.epoch,out.batch.b100ns,liveInputReady,options.fg?duration100ns:0,paceSourcePts);
                }
                if(!isImage&&!isCapture&&frames==0){anchor=Clock::now();anchorMs=lastAudioClockMs=pts;}
                double frameWaitMs=0,framePresentMs=0;
                double gpuWaitMs=0;
                if(liveScheduler){
                    const auto timeline=liveTimeline;
                    const uint64_t jobGeneration=presentationGeneration.load();
                    auto watch=std::make_shared<CompletionWatch>();watch->output=out;watch->flow=frameFlow;watch->processStart=processStart;watch->real=!rereadCached;
                    watch->predictedGpuStart100ns=std::chrono::duration_cast<std::chrono::nanoseconds>(processStart.time_since_epoch()).count()/100+int64_t(queuedGpuMs*10000);
                    watch->captureArrival=captureArrival;watch->presentationGeneration=jobGeneration;
                    // Learn enough phase for early content-clock deadlines on late capture slots.
                    watch->phaseAnchor=smoothContentAnchor?presentAnchorFor(out.batch.b100ns):captureArrival;
                    watch->reflexFrame=currentReflexFrame;
                    pendingCompletions.push_back(watch);
                    if(physicalCapture&&gpuReadyEvent.handle)for(unsigned i=0;i<out.batch.count;++i){
                        const auto& lease=out.batch.frames[i].lease;
                        if(lease&&lease->readyFenceObject&&lease->readyFence)lease->readyFenceObject->SetEventOnCompletion(lease->readyFence,gpuReadyEvent.handle);
                    }
                    struct LiveStepState {
                        unsigned next=0,handled=0,remaining=0;bool readyReported=false;
                        // A frame this step found still in the GPU: its readiness is then seen
                        // when the fence completes (the loop waits on it), not when we look.
                        std::array<bool,pipeline::FrameBatch::Capacity> seenUnfinished{};
                        Clock::time_point readyStart=Clock::now();std::optional<Clock::time_point> deadlineStart,capacityStart;
                        double capacityWaitMs=0;
                        double readyMs=0,waitMs=0,presentMs=0,ageMs=0;uint64_t count=0,dropped=0;
                        diagnostics::GpuSample blit;
                    };
                    auto step=std::make_shared<LiveStepState>();
                    watch->jobStart=step->readyStart;
                    const bool submitThenPresent=(isCapture&&presenter.xessActive()&&!xessPresentAfterReady)||
                        (physicalCapture&&!options.fg&&presenter.independentQueue()&&!capturePresentAfterReady);
                    for(unsigned i=0;i<out.batch.count;++i)if(out.batch.frames[i].kind!=pipeline::FrameKind::Generated||out.batch.frames[i].validity==pipeline::GenerationValidity::Valid)++step->remaining;
                    const double sourceIntervalMs=double(isCapture?liveInterval:liveSourceInterval100ns(pkt.duration,activeSource->info().averageFps))/10000;
                    const auto baselineReady=pkt.decodedHost100ns>0?pkt.decodedHost100ns:captureArrival;
                    const bool delayEnhanced=options.nr||options.sr||options.fg;
                    // Captures are explicit on purpose (sweep 2026-09-22 B1): this step runs
                    // from the scheduler queue for up to two source frames, so every
                    // by-reference capture below must outlive the scheduler. The guard
                    // that destroys the scheduler is declared immediately before the run
                    // loop, so all of these are declared above it. Adding a reference to a
                    // local declared after that guard is now a compile error instead of a
                    // silent dangling reference.
                    if(!liveScheduler->push([this,&anchor,&anchorMs,&captureSource,&xessSubmissions,&lastFilePresentLateness,&lastFilePresentedMs,&liveSubmissions,&presentationCompletedReal,
#ifdef VEYRA_ENABLE_REMOTEPLAY
                        &remote,
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                        &moon,
#endif
#ifdef VEYRA_ENABLE_XBOX
                        &xb,
#endif
                        &seekDecoded,&seekStarted,&seekDemuxDone,&audio,&audioPipe,&audioStarted,&cadence,&ctx,&fileAudioAlignPending,&fileAwaitingVideo,&fileInputEnded,&generatedDropCap,&generatedDropCapacity,&generatedDropDeadline,&playbackRate,&frameFlow,&graph,&host100ns,&isCapture,&isImage,&liveArrival,&livePresent,&liveScheduler,&nextFgDeadlineLog,&nowMs,&options,&pendingCompletions,&physicalCapture,&processingGraph,&presentEntryDeviation,&presentReturnDeviation,&presentationEffective,&presentationGeneration,&presentationSkippedGenerated,&presenter,&ring,&runSessionId,&seekPreviewPending,&traceFrame,&traceSubframes,watch,step,timeline,captureArrival,baselineReady,delayEnhanced,activeSeekId,lineage,jobGeneration,rereadCached,sourceIntervalMs,submitThenPresent,generatedGrace=liveGeneratedGrace,smoothedCapacity=smoothTransportAnchor||smoothContentAnchor,halfRate,captureClockCorrected,driverPts100ns,flow=frameFlow,&deadlineMargin,marginPair,pairExtra](int64_t now)->LiveGpuScheduler::Step{

                        using State=LiveGpuScheduler::State;auto& batch=watch->output;auto& s=*step;
                        auto updatePending=[&](LiveStepState*){
                            unsigned left=0;for(unsigned i=s.next;i<batch.batch.count;++i)if(batch.batch.frames[i].kind!=pipeline::FrameKind::Generated||batch.batch.frames[i].validity==pipeline::GenerationValidity::Valid)++left;
                            flow->update([&](auto& m){if(left>s.remaining)m.pendingOutputFrames+=left-s.remaining;else m.pendingOutputFrames-=std::min(m.pendingOutputFrames,s.remaining-left);});s.remaining=left;
                        };std::unique_ptr<LiveStepState,decltype(updatePending)> pendingUpdate(&s,updatePending);
                        if(watch->ready&&!s.readyReported){s.readyMs=std::max(0.0,std::chrono::duration<double,std::milli>(watch->readyObserved-s.readyStart).count());s.readyReported=true;flow->cpu(diagnostics::CpuStage::ReadyWait,s.readyMs,host100ns());}
                        if(!isCapture&&fileAwaitingVideo&&!seekPreviewPending&&!fileInputEnded&&
                           (liveScheduler->occupancy()<2||!pendingCompletions.empty()))return {State::Pending,now+2000};
                        if(!isCapture&&audioStarted&&fileAudioAlignPending){
                            if(audioPipe.endpointRecovering())return {State::Pending,now+10000};
                            const double ptsMs=double(batch.batch.b100ns)/10000,media=audio.mediaTimeMs();
                            if(std::isfinite(media)&&media+1<ptsMs&&!std::isfinite(audioPipe.requestSeek(ptsMs)))return {State::Failed};
                            fileAudioAlignPending=false;
                        }
                        while(s.next<batch.batch.count){auto& item=batch.batch.frames[s.next];const bool generated=item.kind==pipeline::FrameKind::Generated;
                            if(stop_||(paused_&&!seekPreviewPending)||seekSeconds_>=0)return {State::Complete};
                            const double itemPtsMs=double(item.pts100ns)/10000;
                            const auto decisionTime=host100ns();
                            // A forecast is never shown once a newer real frame is due: that frame is the truth it stood in for.
                            const bool superseded=generated&&batch.fgPredict&&predictNewestReal100ns_>batch.batch.b100ns&&predictNewestDue100ns_<=timeline.deadline(item.pts100ns);
                            const bool generationExpired=generated&&(superseded||(isCapture?timeline.expired(item.pts100ns,decisionTime,generatedGrace):!fileAwaitingVideo&&previewGeneratedExpired(nowMs(),itemPtsMs)));
                            // XeSS shares the producer queue; native no-FG capture has an explicit GPU-side fence wait.
                            const bool early=submitThenPresent&&!generated&&!watch->ready;
                            if(!watch->frameReadyObserved[s.next]&&item.lease&&item.lease->ready())watch->frameReadyObserved[s.next]=host100ns();
                            const auto readiness=previewFrameReadiness(item,comparisonMode_!=0||!generatedPresentationCurrent(jobGeneration,presentationGeneration.load()),generationExpired,[&]{return early||graph->resolveFrame(batch,s.next);});
                            if(early&&readiness==PreviewFrameReadiness::Ready&&!s.readyReported){watch->presentedBeforeReady=true;s.readyReported=true;}
                            if(traceSubframes&&generated&&(readiness==PreviewFrameReadiness::Expired||readiness==PreviewFrameReadiness::Suppressed))
                                traceFrame(diagnostics::TraceKind::Discarded,item.identity,batch.batch.batchId,item.lease->readyFence,item.pts100ns,item.subframe,unsigned(readiness),isCapture?double(decisionTime-timeline.deadline(item.pts100ns))/10000:nowMs()-itemPtsMs);
                            if(readiness==PreviewFrameReadiness::Pending){
                                if(elapsedMs(s.readyStart)>2000){
                                    ctx.reportDeviceFailure("GPU-frame-ready-timeout",item.lease?item.lease->readyFence:0);
                                    veyra::log::error("capture-present",std::format("GPU frame ready timeout nr={} nrRuntime={} source={} epoch={} revision={} subframe={} dimensions={}x{} nrDimensions={}x{} flowBackend={}",graph->nrEnabled(),nrRuntimeName(options.settings.nrRuntime),item.identity.sourceFrameId,item.identity.epoch,item.identity.settingsRevision,item.subframe,graph->workWidth(),graph->workHeight(),graph->nrWidth(),graph->nrHeight(),opticalFlowBackendName(options.settings.opticalFlowBackend)));
                                    return {State::Failed};
                                }
                                s.seenUnfinished[s.next]=true;
                                return {State::Pending,host100ns()+2000};
                            }
                            if(readiness==PreviewFrameReadiness::Invalid){++s.handled;++s.next;s.deadlineStart.reset();continue;}
                            if(readiness==PreviewFrameReadiness::Suppressed){++presentationSkippedGenerated;++s.next;s.deadlineStart.reset();continue;}
                            if(isCapture&&readiness==PreviewFrameReadiness::Ready&&!s.readyReported){s.readyMs=elapsedMs(s.readyStart);s.readyReported=true;flow->cpu(diagnostics::CpuStage::ReadyWait,s.readyMs,host100ns());}
                            if(generated&&isCapture&&decisionTime>=nextFgDeadlineLog){
                                nextFgDeadlineLog=decisionTime+10000000;
                                const auto ready=watch->frameReadyObserved[s.next];
                                veyra::log::info("fg-deadline",std::format("revision={} batch={} subframe={} expired={} readyObservedLateMs={:.3f} decisionLateMs={:.3f} observedReadyToDecisionMs={:.3f} batchReady={} (CPU fence observations, not scanout; -1 means readiness unknown)",item.identity.settingsRevision,batch.batch.batchId,item.subframe,generationExpired,ready?double(ready-timeline.deadline(item.pts100ns))/10000:-1,double(decisionTime-timeline.deadline(item.pts100ns))/10000,ready?double(decisionTime-ready)/10000:-1,watch->ready.load()));
                                veyra::log::info("fg-drops",std::format("revision={} deadline={} capacity={} cap={} graceMs={:.1f} (session totals of frames dropped before Present, by reason)",item.identity.settingsRevision,generatedDropDeadline,generatedDropCapacity,generatedDropCap,double(generatedGrace)/10000));
                            }
                            if(readiness==PreviewFrameReadiness::Expired){++generatedDropDeadline;predictSuperseded_+=superseded;++s.dropped;++s.handled;++s.next;s.deadlineStart.reset();s.capacityStart.reset();continue;}
                            if(!s.deadlineStart)s.deadlineStart=Clock::now();
                            if(isCapture){if(host100ns()<timeline.deadline(item.pts100ns))return {State::Pending,timeline.deadline(item.pts100ns),timeline.paced()&&!presenter.providerOwnedPresentation()};}
                            else if(!fileAwaitingVideo){
                                if(audioStarted)audioPipe.videoReady(itemPtsMs);
                                if(nowMs()+.25<itemPtsMs)return {State::Pending,now+std::min<int64_t>(10000,int64_t((itemPtsMs-nowMs())*10000/playbackRate))};
                            }
                            const auto optionalNow=host100ns();
                            if(!isCapture&&!fileAwaitingVideo&&options.fg&&!presentSinkFrameGeneration(options.settings.frameGenerationBackend)){
                                const auto interval=std::max<int64_t>(1,int64_t(sourceIntervalMs*10000/playbackRate)/std::max(1u,batch.batch.count));
                                const auto due=cadence.due(optionalNow+int64_t((itemPtsMs-nowMs())*10000/playbackRate),interval,20);
                                if(optionalNow<due)return {State::Pending,due};
                            }
                            int64_t capInterval=0;
                            if(presentationEffective.enabled||presentationEffective.outputRate==OutputRateMode::Custom){
                                const auto interval=std::max<int64_t>(1,int64_t(sourceIntervalMs*10000/playbackRate)/std::max(1u,batch.batch.count));
                                const auto mediaDeadline=isCapture?timeline.cadenceDeadline(item.pts100ns,optionalNow):fileAwaitingVideo?optionalNow:optionalNow+int64_t((itemPtsMs-nowMs())*10000/playbackRate);
                                // Media time is the deadline. The old "even" mode
                                // added a spacing floor on top; it measured as a
                                // no-op because production already lands within
                                // 0.8 ms of media time (b13/pacing-ab).
                                auto due=mediaDeadline;
                                if(presentationEffective.outputRate==OutputRateMode::Custom){
                                    capInterval=std::max<int64_t>(1,int64_t(10000000.0/presentationEffective.customFps));
                                    due=std::max(due,cadence.rateDue(optionalNow,capInterval));
                                }
                                // The cap selects displayed candidates, never
                                // changes processing/FG history or media time.
                                // If the next candidate is due before this
                                // slot, discard this stale display opportunity
                                // instead of accumulating latency.
                                if(capInterval>0&&cadence.rateSkipsCandidate(optionalNow,mediaDeadline,interval,capInterval)){++generatedDropCap;++s.dropped;++s.handled;++s.next;s.deadlineStart.reset();continue;}
                                if(optionalNow<due)return {State::Pending,due};
                            }
                            // Explicit VSync: one present of display capacity per present, so a
                            // frame never waits in DXGI's queue (true when not paced). A generated
                            // frame waits for a bounded interval chosen at the first miss.
                            // A 60->30 / 2X pair can use spare refresh slots if one
                            // full refresh remains for its real frame.
                            if((!legacyVsyncQueue||presentationEffective.enabled||presentationEffective.outputRate==OutputRateMode::Custom)&&!presenter.presentationReady()){
                                if(generated&&!legacyVsyncQueue){
                                    if(!s.capacityStart){
                                        s.capacityStart=Clock::now();
                                        const double interval=sourceIntervalMs/std::max(1u,batch.batch.count);
                                        const double base=smoothedCapacity?liveSmoothedCapacityWaitMs(interval,fixedCapacityWait?0:liveArrival.jitterMs()):2.0;
                                        s.capacityWaitMs=std::min(base,interval/2);
                                        if(halfRate&&batch.batch.count==2&&presentationEffective.display==DisplaySync::Vsync&&
                                           !presenter.vrrSync()&&!capInterval&&!fixedCapacityWait){
                                            const auto grid=presenter.refreshGrid();
                                            const double untilReal=double(timeline.deadline(batch.batch.b100ns)-optionalNow)/10000;
                                            s.capacityWaitMs=liveHalfRateCapacityWaitMs(base,interval,grid.period100ns/10000,untilReal);
                                        }
                                    }
                                    if(elapsedMs(*s.capacityStart)>s.capacityWaitMs){++generatedDropCapacity;++s.dropped;++s.handled;++s.next;s.deadlineStart.reset();s.capacityStart.reset();continue;}
                                }
                                return {State::Pending,optionalNow+2000};
                            }
                            s.capacityStart.reset();
                            const auto waited=elapsedMs(*s.deadlineStart);s.deadlineStart.reset();s.waitMs+=waited;flow->cpu(diagnostics::CpuStage::DeadlineWait,waited,host100ns());
                            const bool deviationValid=!isCapture&&!isImage&&!fileAwaitingVideo&&!paused_;
                            const double entryDeviation=deviationValid?nowMs()-itemPtsMs:0;
                            const auto presentBeginHost=host100ns();
                            const auto begin=Clock::now();const auto before=presenter.submittedCount();
                            presenter.reflexFrame(watch->reflexFrame);
                            presenter.observeHdrCoverage(hdrCoverageObserved_.load());
                            // PushFlow 2's Dual: what recordings and streams take in place of the frame shown
                            // (the real frame before this one; the true in-between frame for the first forecast).
                            auto* const creatorFrame=!generated?batch.creatorReal:(batch.fgPredict&&item.subframe==1?batch.creatorBetween:nullptr);
                            if(creatorFrame){presenter.setNextCaptureCreator(creatorFrame,generated);++(generated?dualBetweenGiven_:dualRealGiven_);}
                            if(!presenter.present(ctx,ring,*graph,item.lease->slot,generated,item.lease->referencesValid,comparisonMode_,comparisonBase_,comparisonSplit_,item.identity,previewView(),item.pts100ns))return {State::Failed};
                            const auto presentEndHost=host100ns();
                            const double returnDeviation=deviationValid?nowMs()-itemPtsMs:0;
                            item.lease->consumerFence=presenter.consumerFenceValue(ring.lastSignaledValue());const bool didPresent=presenter.submittedCount()>before;s.blit=presenter.blitTiming(ctx.fence());
                            const auto elapsed=elapsedMs(begin);s.presentMs+=elapsed;flow->cpu(diagnostics::CpuStage::Present,elapsed,host100ns());
                            // A soft history reset retains this metrics window. Older
                            // session/revision windows must not update its admission cost.
                            if(flow==frameFlow){
                                livePresent.add(elapsed);
                                // DXGI/driver blocking is backpressure, not GPU blit
                                // work. The bounded scheduler retains that pressure.
                            }
                            if(didPresent){
                                cadence.submitted(optionalNow);
                                cadence.rateSubmitted(optionalNow,capInterval);
                                if(physicalCapture&&veyra::log::verboseFrameLogs())veyra::log::info("capture-present-sample",std::format("source={} epoch={} revision={} batch={} subframe={} generated={} arrival={} arrivalA={} ready={} begin={} end={}",item.identity.sourceFrameId,item.identity.epoch,item.identity.settingsRevision,batch.batch.batchId,item.subframe,generated,captureArrival,lineage?lineage->a.host100ns:0,watch->frameReadyObserved[s.next],optionalNow,host100ns()));
                                if(veyra::log::verboseFrameLogs())veyra::log::info("pacing-sample",std::format("mode={} enabled={} sync={} pts={} begin={} end={} ready={} process={} generated={} queue={} lateMs={:.3f} arrival={} deadlinePaced={} duringProcess={}",unsigned(presentationEffective.mode),presentationEffective.enabled,unsigned(presentationEffective.display),item.pts100ns,optionalNow,host100ns(),watch->frameReadyObserved[s.next],std::chrono::duration_cast<std::chrono::nanoseconds>(watch->processStart.time_since_epoch()).count()/100,generated,liveScheduler->occupancy(),isCapture?(timeline.paced()?double(optionalNow-timeline.deadline(item.pts100ns))/10000:0):fileAwaitingVideo?0:nowMs()-itemPtsMs,captureArrival,!isCapture||timeline.paced(),processingGraph));
                                diagnostics::FrameTraceEvent event{presentEndHost,runSessionId,item.identity,batch.batch.batchId,item.lease->consumerFence,item.pts100ns,diagnostics::TraceKind::Present,item.subframe,1,elapsed};
                                event.decodedHost=baselineReady;event.processHost=std::chrono::duration_cast<std::chrono::nanoseconds>(watch->processStart.time_since_epoch()).count()/100;
                                event.readyHost=watch->frameReadyObserved[s.next];event.presentBeginHost=presentBeginHost;event.presentEndHost=presentEndHost;
                                event.entryDeviationMs=entryDeviation;event.returnDeviationMs=returnDeviation;event.queueDepth=unsigned(liveScheduler->occupancy());event.mediaDeviationValid=deviationValid;
                                Logger::instance().recordFrame(event);
                                if(deviationValid){presentEntryDeviation.add(std::abs(entryDeviation));presentReturnDeviation.add(std::abs(returnDeviation));}
                                if(veyra::log::verboseFrameLogs())veyra::log::info("submit",std::format("batch={} epoch={} revision={} subframe={} pts100ns={} host100ns={} fence={} (submission, display unmeasured)",batch.batch.batchId,item.identity.epoch,item.identity.settingsRevision,item.subframe,item.pts100ns,host100ns(),item.lease->consumerFence));
                            }
                            // Cumulative alignment: feed whatever the providers reported
                            // since the last submission. The AMD provider publishes from
                            // its own thread, so a per-call delta can miss an update that
                            // lands just after the call and would then never be counted.
                            {
                                const auto xessPresentedTotal=presenter.xessPresentedCount(),xessGeneratedTotal=presenter.xessGeneratedCount();
                                const auto delta=xessSubmissions.observe(presenter.generation(),xessPresentedTotal,xessGeneratedTotal);
                                if(delta.restarted)veyra::log::info("provider-count-reset",std::format("generation={} presentedTotal={} generatedTotal={} new session baseline=0",presenter.generation(),xessPresentedTotal,xessGeneratedTotal));
                                if(delta.presented||delta.generated)flow->xessSubmitted(delta.presented,delta.generated,host100ns());

                            }
                            if(didPresent&&!isCapture){
                                lastFilePresentedMs=itemPtsMs;lastFilePresentLateness=returnDeviation;
                                {std::lock_guard lock(mutex_);if(snapshot_.sessionId==runSessionId&&snapshot_.applied.revision==item.identity.settingsRevision){
                                    // Split the wait so the log says where the time went:
                                    // drain+demux is the network re-position, the rest is
                                    // decoding from the keyframe up to the target plus the
                                    // first enhanced frame.
                                    if(activeSeekId&&snapshot_.seekPresented!=activeSeekId)veyra::log::info("seek-latency",std::format("request={} firstPresentMs={:.3f} decodedToTarget={} ptsMs={:.3f} afterDemuxMs={:.3f}",activeSeekId,elapsedMs(seekStarted),seekDecoded,itemPtsMs,elapsedMs(seekDemuxDone)));
                                    snapshot_.position=itemPtsMs/1000;snapshot_.lateMs=lastFilePresentLateness;snapshot_.seekPresented=activeSeekId;}}
                                double nextPts=itemPtsMs+sourceIntervalMs;
                                for(unsigned next=s.next+1;next<batch.batch.count;++next){const auto& candidate=batch.batch.frames[next];if(candidate.kind!=pipeline::FrameKind::Generated||(candidate.validity==pipeline::GenerationValidity::Valid&&comparisonMode_==0)){nextPts=double(candidate.pts100ns)/10000;break;}}
                                if(audioStarted){audioPipe.videoPresented(nextPts);audioPipe.setPaused(paused_);}
                                if(fileAwaitingVideo){
                                    veyra::log::info("audio-sync",std::format("file lookahead anchor ptsMs={:.3f} queued={} (continuous audio after bounded prefill)",itemPtsMs,liveScheduler->occupancy()));
                                    // Silent playback keeps one wall-clock origin between
                                    // transport changes; per-frame reanchoring hides lateness.
                                    anchor=Clock::now();anchorMs=itemPtsMs;
                                }
                                fileAwaitingVideo=false;seekPreviewPending=false;
                            }
                            // Real B owns captureArrival. Generated A/B frames and
                            // paused cached frames must not invent input anchors.
                            if(didPresent&&physicalCapture&&!generated&&!rereadCached)captureSource.videoPresented(double(captureClockCorrected?driverPts100ns:item.pts100ns)/10000,host100ns(),captureArrival);
#ifdef VEYRA_ENABLE_REMOTEPLAY
                            // PushFPS 4.1: only a frame the console sent tells the sound sync how long the picture takes.
                            if(didPresent&&remote)remote->videoPresented(double(item.pts100ns)/10000,host100ns(),!generated&&!rereadCached);
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                            if(didPresent&&moon)moon->videoPresented(double(item.pts100ns)/10000,host100ns());
#endif
#ifdef VEYRA_ENABLE_XBOX
                            if(didPresent&&xb)xb->videoPresented(double(item.pts100ns)/10000,host100ns(),!generated&&!rereadCached);
#endif
                            if(didPresent&&!generated&&!rereadCached){
                                const auto returned=host100ns();
                                flow->latency(captureArrival,returned);
                                const double age=double(returned-captureArrival)/10000;
                                if(physicalCapture&&age>=80.0)veyra::log::info("capture-age-stall",std::format("source={} epoch={} revision={} callbackToReturnMs={:.3f} readyObservedAgeMs={:.3f} gpuSpanMs={:.3f} deadlineAgeMs={:.3f} decisionLateMs={:.3f} deadlineWaitMs={:.3f} presentMs={:.3f} (CPU observation includes scheduling; not scanout; -1 means unknown or no paced deadline)",item.identity.sourceFrameId,item.identity.epoch,item.identity.settingsRevision,age,watch->frameReadyObserved[s.next]?double(watch->frameReadyObserved[s.next]-captureArrival)/10000:-1.0,watch->gpuExecutionMs.value_or(-1.0),timeline.paced()?double(timeline.deadline(item.pts100ns)-captureArrival)/10000:-1.0,timeline.paced()?double(optionalNow-timeline.deadline(item.pts100ns))/10000:-1.0,waited,elapsed));
                            }
                            if(didPresent&&!generated&&!rereadCached&&!paused_){
                                const auto stamp=host100ns();const auto stats=flow->snapshot(stamp);
                                const auto color=stats.gpuTiming[size_t(diagnostics::GpuStage::Color)].mean;
                                const auto blit=stats.gpuTiming[size_t(diagnostics::GpuStage::Blit)].mean;
                                std::optional<double> basic;
                                if(color&&blit)basic=*color+*blit+elapsed;
                                const auto estimate=enhancementDelayEstimate(delayEnhanced,isCapture,
                                    isCapture?double(stamp-baselineReady)/10000:lastFilePresentLateness,basic);
                                if(estimate)flow->cpu(diagnostics::CpuStage::EnhancementDelayEstimate,*estimate,stamp);
                            }
                            if(didPresent&&generated&&lineage)flow->generatedLatency(*lineage,host100ns());
                            // Deadline margin: what this generated frame would have had without
                            // the extra. Only readiness seen by the deadline, or a fence this step
                            // saw unfinished (so its completion was seen as it happened); a frame
                            // first looked at after its deadline (the thread was busy) says
                            // nothing about the GPU. Warmup and recovery pairs are not steady.
                            if(didPresent&&generated&&marginPair&&flow==frameFlow&&timeline.paced()&&!batch.historyReset&&!batch.fgRecovery){
                                const auto deadline=timeline.deadline(item.pts100ns),ready=watch->frameReadyObserved[s.next];
                                if(ready>0&&(ready<=deadline||s.seenUnfinished[s.next]))deadlineMargin.observe(host100ns(),deadline,ready,pairExtra);
                            }
                            if(didPresent){++s.handled;++s.count;flow->presented(generated,item.lease->consumerFence,host100ns(),presenter.lastPresentCallHost100ns());if(!generated)++presentationCompletedReal;s.ageMs=double(host100ns()-captureArrival)/10000;
                                if(flow==frameFlow){const auto time=host100ns();liveSubmissions.push_back(time);while(liveSubmissions.size()>1&&time-liveSubmissions.front()>10000000)liveSubmissions.pop_front();}}
                            ++s.next;
                        }
                        return {State::Complete};
                    },[&,watch,step,flow=frameFlow]{
                        const auto& batch=watch->output;const auto& s=*step;
                        flow->update([&](auto& m){m.pendingOutputFrames-=std::min(m.pendingOutputFrames,s.remaining);});
                        if(s.handled<batch.batch.count)++presentationCancelledJobs;
                        if(s.handled<batch.batch.count)traceFrame(diagnostics::TraceKind::Cancelled,batch.batch.identity,batch.batch.batchId,0,batch.batch.b100ns,0,batch.batch.count-s.handled,0);
                        flow->update([&](auto& m){m.counters.cancelledBeforePresent+=batch.batch.count-s.handled;m.gpuReadyWaitMs=s.readyMs;m.deadlineWaitMs=s.waitMs;if(s.count)m.captureArrivalToPresentReturnMs=s.ageMs;m.counters.generatedExpiredAfterEval+=s.dropped;});
                        if(flow!=frameFlow)return;
                        liveStats.submitted+=s.count;liveStats.expired+=s.dropped;
                        if(s.count){liveStats.waitMs=s.waitMs;liveStats.presentMs=s.presentMs;liveStats.ageMs=s.ageMs;liveStats.blit=s.blit;
                            liveAges.add(s.ageMs);liveWaits.add(s.waitMs);liveStats.ageP95=liveAges.p95();liveStats.waitP95=liveWaits.p95();liveStats.presentP95=livePresent.p95();
                            // An early (B1) present learns its GPU-ready time in the completion poll.
                            if(!watch->presentedBeforeReady){liveStats.readyMs=s.readyMs;liveReady.add(s.readyMs);liveStats.readyP95=liveReady.p95();}}
                        liveStats.fps=liveSubmissions.size()>1?double(liveSubmissions.size()-1)*1e7/(liveSubmissions.back()-liveSubmissions.front()):0;
                    })){status(L"视频呈现队列失败",true);break;}
                    frameFlow->update([&](auto& m){m.pendingOutputFrames+=step->remaining;});
                    advanceLive();
                    const auto occupancy=liveScheduler->occupancy();frameFlow->update([&](auto& m){m.counters.presentationBatchHighWater=std::max(m.counters.presentationBatchHighWater,occupancy);});
                    const auto completed=liveStats;
                    frameWaitMs=completed.waitMs;framePresentMs=completed.presentMs;gpuWaitMs=completed.readyMs;submitted=completed.submitted;expired=completed.expired;
                }else{
                    // Images have no media clock, audio or temporal batches.
                    const auto readyStart=Clock::now();
                    while(!stop_&&!graph->resolveGeneration(out)){
                        if(elapsedMs(readyStart)>2000){status(L"图片 GPU 就绪超时",true);stop_=true;break;}
                        deadlineWait.slice(.2);
                    }
                    if(stop_)break;
                    gpuWaitMs=elapsedMs(readyStart);gpuReadyTimes.add(gpuWaitMs);
                    frameFlow->cpu(diagnostics::CpuStage::ReadyWait,gpuWaitMs,host100ns());
                    frameFlow->ready(out.batch.batchId,false,0,0,host100ns());completeReset(out.batch.identity);
                    bool presentFailed=false;
                    for(auto& item:out.batch.frames){
                        if(!item.lease)continue;
                        const auto begin=Clock::now();const auto before=presenter.submittedCount();
                        if(!presenter.present(ctx,ring,*graph,item.lease->slot,false,item.lease->referencesValid,comparisonMode_,comparisonBase_,comparisonSplit_,item.identity,previewView(),item.pts100ns)){presentFailed=true;break;}
                        item.lease->consumerFence=presenter.consumerFenceValue(ring.lastSignaledValue());framePresentMs+=elapsedMs(begin);
                        frameFlow->cpu(diagnostics::CpuStage::Present,elapsedMs(begin),host100ns());
                        if(presenter.submittedCount()>before){++submitted;frameFlow->presented(false,item.lease->consumerFence,host100ns());}
                    }
                    if(presentFailed){status(L"图片呈现失败",true);break;}
                }
                if(!liveScheduler){scheduleWaits.add(frameWaitMs);presentTimes.add(framePresentMs);}
                loopTrace.mark("scheduleAndPresent");
                audioRebuffering=audioStarted&&audioPipe.waitingForVideo();
                const double lateness=isCapture?0:isImage?nowMs()-pts:lastFilePresentLateness;
                // Sample only actual presentations above, not each engine iteration.
                auto captureStats=physicalCapture?captureSource.metrics():source::CaptureMetrics{};
                if(isScreen){const auto screen=screenSource.metrics();captureStats.received=screen.received;captureStats.delivered=screen.delivered;captureStats.dropped=screen.dropped;captureStats.readAgeMs=screen.ageMs;captureStats.frameAgeMs=double(std::max<int64_t>(0,host100ns()-pkt.pts.to100ns()))/10000;}
#ifdef VEYRA_ENABLE_REMOTEPLAY
                if(remote){const auto rp=remote->sessionSnapshot();captureStats.received=rp.video.accessUnits;captureStats.dropped=remote->skipped();captureStats.delivered=sourceFrames;
                    captureStats.readAgeMs=double(std::max<int64_t>(0,host100ns()-pkt.arrivalHost100ns))/10000;
                }
#endif
#ifdef VEYRA_ENABLE_XBOX
                if(xb){captureStats.received=xb->unitsReceived();captureStats.dropped=xb->skipped();captureStats.delivered=sourceFrames;
                    captureStats.readAgeMs=double(std::max<int64_t>(0,host100ns()-pkt.arrivalHost100ns))/10000;
                }
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
                if(moon){captureStats.received=moon->unitsReceived();captureStats.dropped=moon->skipped();captureStats.delivered=sourceFrames;
                    captureStats.readAgeMs=double(std::max<int64_t>(0,host100ns()-pkt.arrivalHost100ns))/10000;
                }
#endif
                loopTrace.mark("captureStats");
                diagnostics::FrameMetrics measured;pipeline::EnhanceGraph::Metrics graphStats;uint64_t slotWaitCount=0,commandSubmits=0;double slotWaitMilliseconds=0;uint32_t slotsInFlight=0;
                {measured=graph->gpuMetrics();graphStats=graph->metrics();measured.gpu[size_t(diagnostics::GpuStage::Blit)]=presenter.blitTiming(ctx.fence(),options.settings.revision,out.batch.identity.epoch);
                 // Present-sink FG backends record their application-side work on
                 // the presenter's list; surface that sample instead of leaving
                 // the stage unmeasured. The in-graph DLSS FG keeps its own.
                 if(graph->xessEnabled())measured.gpu[size_t(diagnostics::GpuStage::FgBatch)]=presenter.fgTiming(ctx.fence(),options.settings.revision,out.batch.identity.epoch);
                 slotWaitCount=ring.cpuWaitCount()-slotWaitBase;slotWaitMilliseconds=ring.cpuWaitMilliseconds()-slotWaitMsBase;commandSubmits=ring.submitCount()-submitBase;slotsInFlight=ring.inFlightCount();
                    loopTrace.mark("gpuStats");
                    collectTimings();
                    loopTrace.mark("tailCollectTimings");
                }
                if(measured.identity.settingsRevision!=options.settings.revision||measured.identity.epoch!=out.batch.identity.epoch){measured={};measured.identity=out.batch.identity;for(auto& sample:measured.gpu)sample.state=diagnostics::SampleState::Pending;}
                if(graph->xessEnabled()){
                    graphStats.fgGeneratedFrames=presenter.xessGeneratedCount();
                }


                for(size_t stage=0;stage<measured.gpu.size();++stage){const auto& sample=measured.gpu[stage];if(sample.state==diagnostics::SampleState::Measured&&sample.milliseconds&&sample.end&&sample.end!=lastGpuSampleEnd[stage]){gpuStageTimes[stage].add(*sample.milliseconds);lastGpuSampleEnd[stage]=sample.end;}}
                measured.resolution=pipeline::ResolutionPlan::make({width,height},options.sr,options.snapshot().nrPolicy,isImage,options.settings.revision,options.settings.srTarget,options.settings.lowLatency&&options.nr,0,runningSrPrescale(options.settings,ctx.adapter().isNvidia,isImage),runningSrOutput(options.settings,ctx.adapter().isNvidia),dualSrRuns(options.settings,ctx.adapter().isNvidia,isImage),options.settings.dualSrTarget);measured.decodeCpuMs=decodeMs;measured.submitCpuMs=std::chrono::duration<double,std::milli>(processDone-processStart).count();measured.gpuWaitCpuMs=gpuWaitMs;measured.deadlineWaitCpuMs=frameWaitMs;measured.presentCpuMs=framePresentMs;measured.queueWatermark=out.batch.count;
                LiveStats completed;if(liveScheduler)completed=liveStats;
                uint64_t skipped=0;{std::lock_guard lock(mutex_);skipped=snapshot_.captureRateSkipped-rateSkippedBase;}
                frameFlow->update([&](auto& m){m.counters.captureReceived=captureStats.received-captureFlowBase.received;m.counters.mailboxOverwritten=captureStats.dropped-captureFlowBase.dropped;m.counters.sourceSkippedBeforeGraph=skipped;m.slotReuseWaitCount=slotWaitCount;m.slotReuseWaitMs=slotWaitMilliseconds;m.counters.commandSlotsInFlight=slotsInFlight;m.counters.commandSlotHighWater=std::max(m.counters.commandSlotHighWater,slotsInFlight);});
                frameFlow->update([&](auto& m){m.slotWaitPerFrameMs=processSlotWaitMs;});
                captureFlowLast=captureStats;
                loopTrace.mark("flowUpdate");
                measured.flow=frameFlow->snapshot(host100ns());
                recorder_->setPresentRateHint(measured.flow.presentSubmitFps);
                secondRecorder_->setPresentRateHint(measured.flow.presentSubmitFps);
                replay_->setPresentRateHint(measured.flow.presentSubmitFps);
                stream_->setPresentRateHint(measured.flow.presentSubmitFps);
                loopTrace.mark("flowSnapshot");
                measured.sourceFrames=measured.flow.counters.sourceAccepted;measured.validGenerated=measured.flow.counters.fgReadyValid;measured.submitted=measured.flow.counters.realPresented+measured.flow.counters.generatedPresented;measured.expired=measured.flow.counters.generatedExpiredAfterEval;
                const double ageP95=liveScheduler?completed.ageP95:captureAges.p95(),waitP95=liveScheduler?completed.waitP95:scheduleWaits.p95(),presentP95=liveScheduler?completed.presentP95:presentTimes.p95();
                // Refresh and VRR state (DisplayStateService, queried on events
                // only) are polled outside the snapshot lock; this never waits.
                presenter.displayRefreshHz();
                ++frames;{std::lock_guard lock(mutex_);snapshot_.metrics=measured;if((frames&31)==0){const auto pf=graph->pushFlowSummary();snapshot_.pushFlowPrecision=pf.precision;snapshot_.pushFlowRebuild=pf.rebuild;snapshot_.pushFlowP50Ms=pf.p50Ms;snapshot_.pushFlowP95Ms=pf.p95Ms;snapshot_.pushFlowMotionWidth=pf.motionWidth;snapshot_.pushFlowMotionHeight=pf.motionHeight;
                    snapshot_.pushFlowEncoderCache=pf.encoderCache;snapshot_.pushFlowEncoderRuns=pf.encoderRuns;snapshot_.pushFlowFeaturesKept=pf.featuresKept;snapshot_.pushFlowFeaturesMade=pf.featuresMade;
                    snapshot_.pushFlowWholeMs=pf.wholeMs;snapshot_.pushFlowSplitMs=pf.splitMs;snapshot_.pushFlowSplitCheckDb=pf.splitCheckDb;
                    snapshot_.pushFlowGuard=pf.guard;snapshot_.pushFlowGuardFrames=pf.guardFrames;snapshot_.pushFlowGuardMended=pf.guardMended;snapshot_.pushFlowGuardHeld=pf.guardHeld;
                    snapshot_.pushFlowPredict=pf.predict;snapshot_.pushFlowPredictFrames=pf.predictFrames;snapshot_.pushFlowPredictCounted=pf.predictCounted;
                    snapshot_.pushFlowPredictMoving=pf.predictMoving;snapshot_.pushFlowPredictHeld=pf.predictHeld;snapshot_.pushFlowPredictSuperseded=predictSuperseded_;
                    snapshot_.pushFlowDual=pf.dual;snapshot_.pushFlowDualReal=dualRealGiven_;snapshot_.pushFlowDualBetween=dualBetweenGiven_;
                    snapshot_.pushFlowMotionPairs=pf.motionPairs;snapshot_.pushFlowAlignedApart=pf.alignedApart;
                    // PushFPS Crosshair Hold: what it holds changes from second to second, so it is read here as well.
                    snapshot_.crosshairHoldState=graph->crosshairHoldState();snapshot_.crosshairHoldPixels=int(graph->crosshairHoldPixels());snapshot_.crosshairHoldFrames=graph->crosshairHoldFrames();
                    // Asked for, and the source is a file: Predict is for live sources only, and says so.
                    if(snapshot_.pushFlowPredict.empty()&&!isCapture&&pushflow2::wanted(pushflow2::Experiment::Predict))snapshot_.pushFlowPredict="not-live";}
                    // Custom (format label): one name for what the source carries,
                    // used by the player bar and the start-up badge. Dolby Vision
                    // first, then the dynamic-metadata HDR formats, then the static
                    // ones. Identification only: every case maps on the static curve.
                    const auto sourceHdrLabel = [&]() -> std::wstring {
                        if (isCapture || isImage || activeSource == nullptr) return {};
                        const auto& si = activeSource->info();
                        if (si.dolbyVision.present) {
                            if (si.dolbyVision.profile == 5) return L"Dolby Vision P5";
                            if (si.dolbyVision.profile == 7) return L"Dolby Vision P7";
                            // Profile 8 carries its base layer's signal in the
                            // compatibility id: 8.1 PQ, 8.2 SDR, 8.4 HLG.
                            if (si.dolbyVision.profile == 8) {
                                if (si.dolbyVision.compatibility == 4) return L"Dolby Vision P8.4";
                                if (si.dolbyVision.compatibility == 2) return L"Dolby Vision P8.2";
                                if (si.dolbyVision.compatibility == 1) return L"Dolby Vision P8.1";
                                return L"Dolby Vision P8";
                            }
                            return L"Dolby Vision";
                        }
                        if (si.hdrVivid.present) return L"HDR Vivid";
                        if (si.hdr10Plus.present) return L"HDR10+";
                        if (si.color.transfer == pipeline::TransferFunction::PQ) return L"HDR10";
                        if (si.color.transfer == pipeline::TransferFunction::HLG) return L"HLG";
                        return L"SDR";
                    }();
                    const std::wstring hdrSource = (gd.hdrInput && !sourceHdrLabel.empty()) ? sourceHdrLabel : L"HDR";
                    snapshot_.sourceHdrLabel=sourceHdrLabel;
                    snapshot_.colorStatus=graph->videoHdrActive()?L"SDR → RTX Video HDR":options.settings.videoHdr.enabled&&!gd.hdrInput?L"SDR → SDR（HDR显示未启用）":gd.hdrOutput?(graph->hdr10Output()?hdrSource+L" → HDR10 / PQ":hdrSource+L" → scRGB / 浮点"):gd.hdrInput?hdrSource+L" → SDR色调映射":L"SDR → SDR";snapshot_.position=(isCapture||isImage?pts:lastFilePresentedMs)/1000;snapshot_.frames=sourceFrames;snapshot_.generated=graphStats.fgGeneratedFrames;snapshot_.lateMs=lateness;snapshot_.lateP95Ms=presentReturnDeviation.p95();
                    snapshot_.videoHdrActive=graph->videoHdrActive();
                    snapshot_.beautyActive=graph->beautyNodesActive();snapshot_.beautyFaces=graph->beautyFaceCount();
                    snapshot_.beautyNotice=graph->beautyNotice();
                    snapshot_.videoHdrStatus=graph->videoHdrActive()?L"预览：SDR 转 HDR 已运行":
                        !options.settings.videoHdr.enabled?L"RTX Video HDR 已关闭":
                        gd.hdrInput?L"原生 HDR 输入，无需 SDR 转 HDR":
                        L"当前为 SDR 预览，HDR 转换未运行";
                    // Measured playback speed: media-PTS advance per wall time
                    // over ~1s windows (1.0 = normal speed), resampled on seek.
                    // A rejected LUT input space must be visible, not only logged
                    // (plan v5.2: never apply a mismatched LUT silently).
                    if(!graph->colorLutNotice().empty())snapshot_.colorStatus+=L"；"+graph->colorLutNotice();
                    if(!graph->antiAliasNotice().empty())snapshot_.colorStatus+=L"；"+graph->antiAliasNotice();
                    const auto speedNow=Clock::now();
                    if(playbackSpeedLastWall==Clock::time_point()||pts+0.5<playbackSpeedLastPts){playbackSpeedLastPts=pts;playbackSpeedLastWall=speedNow;}
                    else if(std::chrono::duration<double>(speedNow-playbackSpeedLastWall).count()>=0.9){
                        const double wallS=std::chrono::duration<double>(speedNow-playbackSpeedLastWall).count();
                        const double mediaS=(pts-playbackSpeedLastPts)/1000.0;
                        if(mediaS>=0)snapshot_.playbackSpeed=mediaS/wallS;
                        playbackSpeedLastPts=pts;playbackSpeedLastWall=speedNow;
                    }
                    snapshot_.previewSkipped=measured.flow.counters.previewSkippedBeforeGraph;
                    snapshot_.fgBudgetLimited=measured.flow.lastFgRejected100ns>0&&host100ns()-measured.flow.lastFgRejected100ns<10000000;
                    snapshot_.xessGenerationSuppressed=graph->xessEnabled()&&presenter.xessGenerationSuppressed();
                    // Reuse the existing snapshot lock, rather than locking once
                    // more for every generated Present.
                    const auto& coverage=presenter.liveCurveCoverage();
                    snapshot_.hdrCoverageValid=coverage.valid;
                    snapshot_.hdrAboveCeilingPercent=coverage.aboveCeilingPercent();
                    snapshot_.hdrInRollOffPercent=coverage.inRollOffPercent();
                    snapshot_.hdrInLiftPercent=coverage.inLiftPercent();
                    snapshot_.displayVrr=gfx::vrrLevel(presenter.displayVrr());snapshot_.presentationVrrSync=presenter.vrrSync();
                    snapshot_.nrActive=graph->nrEnabled()&&graphStats.nrEvaluateCount>0;
                    snapshot_.nrAutoActive=graph->autoNrPoolReady();
                    snapshot_.nrAutoPercent=graph->autoNrPoolReady()?AutoNrController::percent(graph->autoNrLevel()):0;
                    const auto autoExtent=graph->autoNrExtent();snapshot_.nrAutoWidth=autoExtent.width;snapshot_.nrAutoHeight=autoExtent.height;
                    snapshot_.nrAutoStatus=nrAutoStatus;
                    snapshot_.nrReuseActive=graph->nrReuseActive();snapshot_.nrReuseAutomatic=graph->nrReuseAutomatic();
                    snapshot_.nrReuseLevel=graph->nrReuseActive()?graph->nrReuseLevel():0;
                    snapshot_.nrReuseFrames=graphStats.nrReuseFrames;snapshot_.nrReuseUnavailable=graph->nrReuseUnavailable();
                    snapshot_.audioRebuffering=audioRebuffering;
                    snapshot_.audioVideoWaits=audioPipe.videoWaitCount();
                    snapshot_.srActive=gd.enableSr&&graphStats.srEvaluateCount>0;
                    snapshot_.fgActive=options.fg&&(graph->xessEnabled()?presenter.xessActive()&&graphStats.fgGeneratedFrames>0:graph->fgEnabled()&&measured.flow.counters.fgReadyValid>0);
                    if(transaction&&backendRecoveryWarning.empty()&&nvidiaAdapter&&(!graph->xessEnabled()||presenter.xessActive()))snapshot_.backendWarning.clear();
                    snapshot_.flowPerf=graph->actualFlowPerf();snapshot_.contentFps=isCapture&&!legacyCadence&&dedupContent(options.settings.content)&&contentDedup.contentFps()>0?int(std::lround(contentDedup.contentFps())):out.measuredContentRate;
                    snapshot_.nrEvaluated=graphStats.nrEvaluateCount;snapshot_.nvofExecuted=graphStats.nvofExecuteCount;
                    {const auto& shown=presenter.displayLatency();snapshot_.presentToScanoutMs=shown.samples?shown.p50Ms:-1;snapshot_.presentToScanoutP95Ms=shown.samples?shown.p95Ms:-1;snapshot_.compositionMode=shown.compositionMode;}
                    snapshot_.captureReceived=captureStats.received;snapshot_.captureDropped=captureStats.dropped;snapshot_.captureFps=captureStats.callbackFps;snapshot_.captureReadAgeMs=captureStats.readAgeMs;snapshot_.captureAgeMs=liveScheduler?completed.ageMs:captureStats.frameAgeMs;snapshot_.captureAgeP95Ms=ageP95;
                    snapshot_.captureSampledBlack=captureStats.sampledBlack;
                    snapshot_.schedulingWaitP95Ms=waitP95;snapshot_.processCpuP95Ms=processTimes.p95();snapshot_.presentCpuP95Ms=presentP95;
                }
                loopTrace.mark("publishSnapshot");
                const auto gpuP95=[&](diagnostics::GpuStage stage){return gpuStageTimes[size_t(stage)].p95();};
                if(veyra::log::verboseFrameLogs()&&Clock::now()>=nextTimingLog){const auto [retained,overwritten]=Logger::instance().frameTraceSize();
                    veyra::log::info("frame-trace",std::format("retained={} capacity=8192 overwritten={} (records available in diagnostic preview)",retained,overwritten));}
                if(options.settings.multiplier>1&&Clock::now()>=nextTimingLog)
                    veyra::log::info("fg-validity",std::format("revision={} candidate={} valid={} invalid={} providerDisabled={} contentPolicy={} sourceTransportFps={} backend={} (invalid = disabled by the provider; no automatic content-rate/multiplier rewrite)",options.settings.revision,graphStats.fgSubmittedCandidates,graphStats.fgGeneratedFrames,graphStats.fgDisabledFrames,graphStats.fgProviderDisabled,int(options.settings.content),activeSource->info().averageFps,frameGenerationBackendName(options.settings.frameGenerationBackend)));
                if(!isCapture&&Clock::now()>=nextTimingLog){const double playbackSpeedNow=[&]{std::lock_guard lock(mutex_);return snapshot_.playbackSpeed;}();
                // present-deviation / output-queue are folded into the
                // player-timing line below (sweep E5); the separate lines stay
                // available under VEYRA_VERBOSE_FRAME_LOGS for old tooling.
                const auto dashboard=frameFlow->snapshot(host100ns());
                if(veyra::log::verboseFrameLogs()){
                veyra::log::info("present-deviation",std::format("samples={} entryAbsP95Ms={:.3f} returnAbsP95Ms={:.3f} (one sample per actual submission; media-clock deviation, not scanout latency)",presentReturnDeviation.size(),presentEntryDeviation.p95(),presentReturnDeviation.p95()));
                veyra::log::info("output-queue",std::format("pendingFrames={} enhancementProcessingMs={:.3f} extraDelayEstimateMs={:.3f}",dashboard.pendingOutputFrames,dashboard.enhancementProcessing.mean.value_or(-1),dashboard.cpuTiming[size_t(diagnostics::CpuStage::EnhancementDelayEstimate)].mean.value_or(-1)));}
                uint64_t vramBudget=0,vramUsage=0;ctx.videoMemoryInfo(vramBudget,vramUsage);watchVram(vramUsage,vramBudget);
                veyra::log::info("player-timing",std::format("vramMiB={} budgetMiB={} revision={} decodeP95Ms={:.3f} graphSubmitP95Ms={:.3f} gpuReadyP95Ms={:.3f} presentP95Ms={:.3f} gpuColorP95Ms={:.3f} gpuSrP95Ms={:.3f} gpuFlowP95Ms={:.3f} gpuNrP95Ms={:.3f} gpuResidualP95Ms={:.3f} gpuFgBatchP95Ms={:.3f} gpuBlitP95Ms={:.3f} slotWaits={} slotWaitMs={:.3f} commandSubmits={} displaySubmits={} expiredGenerated={} previewSkipped={} playbackSpeed={:.3f} processed={} entryAbsP95Ms={:.3f} returnAbsP95Ms={:.3f} pendingFrames={} enhancementProcessingMs={:.3f}",vramUsage>>20,vramBudget>>20,options.settings.revision,decodeTimes.p95(),processTimes.p95(),liveScheduler?completed.readyP95:gpuReadyTimes.p95(),presentP95,gpuP95(diagnostics::GpuStage::Color),gpuP95(diagnostics::GpuStage::Sr),gpuP95(diagnostics::GpuStage::Flow),gpuP95(diagnostics::GpuStage::Nr),gpuP95(diagnostics::GpuStage::Residual),gpuP95(diagnostics::GpuStage::FgBatch),gpuP95(diagnostics::GpuStage::Blit),slotWaitCount,slotWaitMilliseconds,commandSubmits,submitted,expired,measured.flow.counters.previewSkippedBeforeGraph,playbackSpeedNow,sourceFrames-statsSourceBase,presentEntryDeviation.p95(),presentReturnDeviation.p95(),dashboard.pendingOutputFrames,dashboard.enhancementProcessing.mean.value_or(-1)));nextTimingLog=Clock::now()+std::chrono::seconds(1);}
                if(isCapture&&Clock::now()>=nextTimingLog){
                    logFrameFlow(measured.flow,"active");
                    const auto rates=snapshot();
                    // Adapter memory every second: a long session that slowly runs out of video
                    // memory gets slower in every pass at once (field log 2026-10-01).
                    uint64_t vramBudget=0,vramUsage=0;ctx.videoMemoryInfo(vramBudget,vramUsage);watchVram(vramUsage,vramBudget);
                    veyra::log::info("frame-rate",std::format("revision={} gpuCompletedFps={:.2f} completedReal={} capture60To30={} rateSkipped={} presentSubmitFps={:.2f} windowMs=1000 vramMiB={} budgetMiB={} (not scanout FPS)",options.settings.revision,rates.fps,rates.processedCompleted,rates.captureHalfRate,rates.captureRateSkipped,rates.submissionFps.value_or(0),vramUsage>>20,vramBudget>>20));
                    if(isCapture&&dedupContent(options.settings.content)&&!legacyCadence){
                        const auto& st=contentDedup.stats();
                        veyra::log::info("content-dedup",std::format("revision={} mode={} observed={} kept={} repeats={} held={} blind={} regular={} irregular={} contentFps={:.2f} maxShiftMs={:.2f} repeatMaxDiff={} repeatMaxOver={} newMinOver={} band={} (per second; a repeat has at most about 5 per million components of the whole picture beyond the band of the last new one, dropped before GPU work; kept frames carry content timestamps)",
                            options.settings.revision,int(options.settings.content),st.observed-dedupLogged.observed,st.kept-dedupLogged.kept,st.repeats-dedupLogged.repeats,st.held-dedupLogged.held,st.blind-dedupLogged.blind,
                            st.regular-dedupLogged.regular,st.irregular-dedupLogged.irregular,contentDedup.contentFps(),st.maxShiftMs,dedupRepeatMax8,dedupRepeatMaxOver,dedupNewMinOver==UINT64_MAX?0:dedupNewMinOver,pipeline::PictureReference::kBand8));
                        dedupLogged=st;dedupRepeatMax8=0;dedupRepeatMaxOver=0;dedupNewMinOver=UINT64_MAX;
                    }
                    veyra::log::info("capture-timing",std::format("revision={} received={} processed={} dropped={} callbackFps={:.2f} readAgeMs={:.3f} callbackToPresentReturnP95Ms={:.3f} processCpuP95Ms={:.3f} gpuReadyP95Ms={:.3f} schedulingWaitP95Ms={:.3f} presentCpuP95Ms={:.3f} gpuColorP95Ms={:.3f} gpuSrP95Ms={:.3f} gpuFlowP95Ms={:.3f} gpuNrP95Ms={:.3f} gpuResidualP95Ms={:.3f} gpuFgBatchP95Ms={:.3f} gpuBlitP95Ms={:.3f} slotWaits={} slotWaitMs={:.3f} commandSubmits={} displaySubmits={} expiredGenerated={} nr={} nvof={} generated={} historyResets={} presentationDrains={} presentationCompletedReal={} presentationSkippedGenerated={} presentationCancelledJobs={} singleGpuOwner=1 batchCapacity=2 (not HDMI-to-display latency)",options.settings.revision,captureStats.received,sourceFrames-statsSourceBase,captureStats.dropped,captureStats.callbackFps,captureStats.readAgeMs,ageP95,processTimes.p95(),liveScheduler?completed.readyP95:gpuReadyTimes.p95(),waitP95,presentP95,gpuP95(diagnostics::GpuStage::Color),gpuP95(diagnostics::GpuStage::Sr),gpuP95(diagnostics::GpuStage::Flow),gpuP95(diagnostics::GpuStage::Nr),gpuP95(diagnostics::GpuStage::Residual),gpuP95(diagnostics::GpuStage::FgBatch),gpuP95(diagnostics::GpuStage::Blit),slotWaitCount,slotWaitMilliseconds,commandSubmits,submitted,expired,graphStats.nrEvaluateCount,graphStats.nvofExecuteCount,graphStats.fgGeneratedFrames,historyResets.load(),presentationDrains.load(),presentationCompletedReal.load(),presentationSkippedGenerated.load(),presentationCancelledJobs.load()));
                    nextTimingLog=Clock::now()+std::chrono::seconds(1);
                }
                loopTrace.mark("periodicLogs");
            }
        }while(false);
    }catch(const std::exception& e){
        veyra::log::error("engine",std::format("{} (engine run loop)",e.what()));
        status(L"引擎异常，请查看诊断",true);failed=true;}
    (void)failed;
#ifdef VEYRA_ENABLE_REMOTEPLAY
    {std::lock_guard lock(mutex_);activeRemote_.reset();}
    if(remote)remote->close();
#endif
#ifdef VEYRA_ENABLE_MOONLIGHT
    {std::lock_guard lock(mutex_);activeMoonlight_.reset();}
    if(moon)moon->close();
#endif
#ifdef VEYRA_ENABLE_XBOX
    {std::lock_guard lock(mutex_);activeXbox_.reset();}
    if(xb)xb->close();
#endif
    // Each step is logged: a session that stopped responding after a remote
    // play failure left "graph shutdown complete" as its last line.
    audioPipe.stopThread();audio.shutdown();veyra::log::info("engine","teardown: audio stopped");
    ring.drainQueue();presenter.close();graph->shutdown();recentGraphCache.evict("session-close");
    (void)coreCache.close();
    veyra::log::info("engine","teardown: closing sources");
    captureSource.close();screenSource.close();source.close();av_frame_free(&cachedFrame);av_frame_free(&imageFrame);
    veyra::log::info("engine","teardown: sources closed");
    if(gpuFailureAwaitingRemoval){
        // Usually the drain above already waited for the reset; allow it a little longer.
        uint32_t removed=0;bool alive=ctx.checkDeviceAlive(removed);
        for(int i=0;alive&&i<20;++i){Sleep(100);alive=ctx.checkDeviceAlive(removed);}
        if(!alive)ctx.reportDeviceFailure("live-presentation-failed-at-teardown");
        else veyra::log::warn("gpu-failure","device still not removed at teardown; no DRED report available");
    }
    gpu->shutdown();
    {std::lock_guard lock(mutex_);snapshot_.running=false;snapshot_.audioEndpointRecovering=false;snapshot_.audioRebuffering=false;}
    CoUninitialize();
}
}
