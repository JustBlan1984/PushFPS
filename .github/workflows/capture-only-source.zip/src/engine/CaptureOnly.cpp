// Capture-only builds expose unavailable output APIs to the shared UI bridge.
#include "veyra/engine/LiveRecorder.h"
#include "veyra/engine/VirtualCamera.h"
#include "veyra/engine/MicrophoneCapture.h"
#include "veyra/engine/VideoExportJob.h"
#include "veyra/engine/ExportStreams.h"
#include "veyra/engine/PushLayerSources.h"

namespace veyra::engine {
namespace {
bool unavailable(std::wstring& error) {
    error = L"This feature is unavailable in Capture Card Edition.";
    return false;
}
}
struct LiveRecorder::State {};
LiveRecorder::LiveRecorder(Mode) {}
LiveRecorder::LiveRecorder(bool) {}
LiveRecorder::~LiveRecorder() = default;
bool LiveRecorder::start(const RecordingSettings&, std::wstring& error) { return unavailable(error); }
void LiveRecorder::stop(const std::wstring&) {}
bool LiveRecorder::saveReplay(const std::wstring&, std::wstring& error) { return unavailable(error); }
bool LiveRecorder::active() const { return false; }
RecordingStatus LiveRecorder::status() const { return {}; }
void LiveRecorder::setPresentRateHint(double) {}
void LiveRecorder::sessionEnded(const std::wstring&) {}
void LiveRecorder::waitIdle(uint32_t) {}
bool LiveRecorder::record(ID3D12GraphicsCommandList*, const Frame&) { return false; }
void LiveRecorder::submitted(ID3D12Fence*, uint64_t) {}
void LiveRecorder::discarded() {}
bool LiveRecorder::wantsRawFrames() const { return false; }
uint32_t recordingAutoBitrateMbps(uint32_t, uint32_t, uint32_t, bool, uint32_t) { return 0; }
uint64_t replayMemoryCapBytes() { return 0; }

struct VirtualCamera::State {};
struct VirtualCamera::Worker {};
VirtualCamera::VirtualCamera() {}
VirtualCamera::~VirtualCamera() = default;
bool VirtualCamera::start(uint32_t, std::wstring& error) { return unavailable(error); }
void VirtualCamera::stop() {}
bool VirtualCamera::uninstall(std::wstring& error) { return unavailable(error); }
bool VirtualCamera::installForAllUsers(std::wstring& error) { return unavailable(error); }
void VirtualCamera::sessionEnded() {}
VirtualCameraStatus VirtualCamera::status() const { return {}; }
bool VirtualCamera::needsFrame() const { return false; }
bool VirtualCamera::record(ID3D12GraphicsCommandList*, const Frame&) { return false; }
void VirtualCamera::submitted(ID3D12Fence*, uint64_t) {}
void VirtualCamera::discarded() {}

std::vector<MicrophoneDevice> microphoneDevices() { return {}; }
void attachMicrophone(std::shared_ptr<MicrophoneSink>, const std::wstring&) {}
void detachMicrophone(const MicrophoneSink*) {}
MicrophoneStatus microphoneStatus() { return {}; }

bool exportVideo(const std::wstring&, const std::wstring&, PlayerOptions, bool,
    std::atomic<bool>&, const std::function<void(double,const std::wstring&)>&,
    unsigned, const std::function<bool()>&, const std::function<void(const ExportCounts&)>&,
    ExportResume*, const ExportSegments&, unsigned) { return false; }
bool joinExportSegments(const ExportSegments&, const std::wstring&, bool, std::wstring& error) {
    return unavailable(error);
}

std::vector<PushCameraInfo> pushCameras() { return {}; }
void setPushSources(const std::vector<PushSourceSpec>&, uint32_t) {}
std::vector<PushSourceStatus> pushSourceStatus() { return {}; }
std::shared_ptr<const PushOverlayImage> pushSourceFrame(const std::string&) { return {}; }
uint64_t pushSourceSerial(const std::string&) { return 0; }
void setPushSourceReferenceWidth(uint32_t) {}
}

namespace veyra::engine {
struct ExportStreams::Impl {};
ExportStreams::ExportStreams() {}
ExportStreams::~ExportStreams() = default;
bool ExportStreams::prepare(const std::wstring&, AVFormatContext*, const ExportMediaOptions&,
    int, double, double, std::atomic<bool>&, std::wstring& error) { return unavailable(error); }
bool ExportStreams::writeUntil(double, double, bool, std::wstring& error) { return unavailable(error); }
const ExportMediaInfo& ExportStreams::info() const {
    static const ExportMediaInfo info;
    return info;
}
ExportMediaInfo ExportStreams::probe(const std::wstring&, const ExportMediaOptions&,
    double, double, std::atomic<bool>&) {
    ExportMediaInfo info;
    info.error = L"Video export is unavailable in Capture Card Edition.";
    return info;
}
void ExportStreams::enableWorkerLogging(bool) {}
}
