#include "veyra/engine/LiveRecorder.h"
#include "veyra/engine/VirtualCamera.h"
#include "veyra/engine/MicrophoneCapture.h"
#include <iostream>
using namespace veyra::engine;
int main() {
    std::wstring error;
    RecordingSettings settings;
    for (auto mode : {LiveRecorder::Mode::File, LiveRecorder::Mode::Replay, LiveRecorder::Mode::Stream}) {
        LiveRecorder output(mode);
        if (output.active() || output.start(settings, error) || error.empty() ||
            output.status().active || output.saveReplay(L".", error)) return 1;
    }
    VirtualCamera camera;
    if (camera.start(60, error) || camera.status().active || !microphoneDevices().empty()) return 2;
    std::cout << "Capture-only output APIs remain unavailable\n";
    return 0;
}
