#include "veyra/engine/LiveStream.h"
#include <algorithm>
#include <cctype>
namespace veyra::engine::stream {

// ---- URL helpers --------------------------------------------------------------------------------

namespace {
bool cleanText(std::string_view s) {
    for (unsigned char c : s)
        if (c <= 32 || c == 127) return false;
    return true;
}
std::string lower(std::string_view s) {
    std::string out(s);
    for (char& c : out) c = char((c >= 'A' && c <= 'Z') ? c - 'A' + 'a' : c);
    return out;
}
}  // namespace

bool validServer(std::string_view server) {
    if (server.size() < 9 || server.size() > 512 || !cleanText(server)) return false;
    const std::string l = lower(server.substr(0, 8));
    size_t hostStart;
    if (l.rfind("rtmps://", 0) == 0) hostStart = 8;
    else if (l.rfind("rtmp://", 0) == 0) hostStart = 7;
    else return false;
    const size_t hostEnd = server.find_first_of("/?", hostStart);
    const std::string_view host = server.substr(hostStart, hostEnd == std::string_view::npos ? std::string_view::npos : hostEnd - hostStart);
    return !host.empty() && host.front() != ':' && host.find('@') == std::string_view::npos;
}

std::string joinUrl(std::string_view server, std::string_view key) {
    if (!validServer(server) || key.empty() || key.size() > 512 || !cleanText(key)) return {};
    while (!key.empty() && key.front() == '/') key.remove_prefix(1);
    if (key.empty()) return {};
    std::string url(server);
    while (!url.empty() && url.back() == '/') url.pop_back();
    return url + "/" + std::string(key);
}

std::string twitchTestKey(std::string_view key) {
    std::string out(key);
    if (!out.empty() && out.find('?') == std::string::npos) out += "?bandwidthtest=true";
    return out;
}

std::string redact(std::string_view url) {
    // scheme://host[:port]/app/KEY -> scheme://host[:port]/app/****
    const size_t scheme = url.find("://");
    if (scheme == std::string_view::npos) return "****";
    const size_t pathStart = url.find('/', scheme + 3);
    if (pathStart == std::string_view::npos) return std::string(url);
    const size_t appEnd = url.find('/', pathStart + 1);
    if (appEnd == std::string_view::npos) return std::string(url.substr(0, pathStart + 1)) + "****";
    return std::string(url.substr(0, appEnd + 1)) + "****";
}

const std::vector<Platform>& platforms() {
    // Servers and limits from OBS Studio's rtmp-services (plugins/rtmp-services/data/services.json,
    // GPL-2.0-or-later) where OBS lists the platform; Kick's from Kick's help pages; TikTok and custom
    // servers are pasted by the user (TikTok gives a server per stream).
    static const std::vector<Platform> list = {
        {"twitch", "Twitch",
         {{"US East (N. Virginia)", "rtmp://use10.contribute.live-video.net/app/"},
          {"US East (Ohio)", "rtmp://use20.contribute.live-video.net/app/"},
          {"US West (Oregon)", "rtmp://usw20.contribute.live-video.net/app/"},
          {"Europe (Frankfurt)", "rtmp://euc10.contribute.live-video.net/app/"},
          {"Europe (Ireland)", "rtmp://euw10.contribute.live-video.net/app/"},
          {"Europe (Paris)", "rtmp://euw30.contribute.live-video.net/app/"},
          {"Europe (Stockholm)", "rtmp://eun10.contribute.live-video.net/app/"},
          {"South America (Sao Paulo)", "rtmp://sae10.contribute.live-video.net/app/"},
          {"Asia Pacific (Tokyo)", "rtmp://apn10.contribute.live-video.net/app/"},
          {"Asia Pacific (Seoul)", "rtmp://apn20.contribute.live-video.net/app/"},
          {"Asia Pacific (Singapore)", "rtmp://aps10.contribute.live-video.net/app/"},
          {"Asia Pacific (Sydney)", "rtmp://aps20.contribute.live-video.net/app/"},
          {"Asia Pacific (Mumbai)", "rtmp://aps30.contribute.live-video.net/app/"}},
         6000, 320, false, "dashboard.twitch.tv -> Settings -> Stream"},
        {"youtube", "YouTube",
         {{"Primary (RTMPS)", "rtmps://a.rtmps.youtube.com:443/live2"},
          {"Primary (RTMP)", "rtmp://a.rtmp.youtube.com/live2"}},
         51000, 160, false, "studio.youtube.com -> Go live -> Stream"},
        {"kick", "Kick",
         {{"Kick (RTMPS)", "rtmps://fa723fc1b171.global-contribute.live-video.net:443/app"}},
         8000, 320, true, "kick.com -> Creator Dashboard -> Channel -> Stream URL and Key"},
        {"tiktok", "TikTok", {}, 6000, 192, false, "TikTok LIVE Producer (needs LIVE access) -> Server URL and Stream Key"},
        {"facebook", "Facebook Live", {{"Default", "rtmps://rtmp-api.facebook.com:443/rtmp/"}}, 9000, 128, true, "facebook.com/live/producer -> Streaming software"},
        {"trovo", "Trovo", {{"Default", "rtmp://livepush.trovo.live/live/"}}, 9000, 160, false, "studio.trovo.live -> Stream settings"},
        {"custom", "Custom", {}, 50000, 320, false, ""},
    };
    return list;
}

const Platform* platform(std::string_view id) {
    for (const auto& p : platforms())
        if (id == p.id) return &p;
    return nullptr;
}

const char* stateName(State s) {
    switch (s) {
    case State::Idle: return "idle";
    case State::Connecting: return "connecting";
    case State::Live: return "live";
    case State::Reconnecting: return "reconnecting";
    case State::Failed: return "failed";
    case State::Stopped: return "stopped";
    }
    return "?";
}

// ---- one connection -----------------------------------------------------------------------------


}
